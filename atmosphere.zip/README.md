# Atmosphere

Aplikasi cuaca native Android (Kotlin + Jetpack Compose) dengan peta live.
Package: `com.atmosphere.app` · Min Android 8 (API 26) · Target API 34 → jalan di Android 10.

## Fitur

- Peta yang bisa digeser dan di-zoom (OpenStreetMap, basemap CARTO Voyager)
- Lapisan **Radar** hujan live + animasi 2 jam terakhir (RainViewer)
- Lapisan **Angin**: panah arah angin berwarna menurut kecepatan, mengikuti area peta yang terlihat
- Lapisan **Badai**: penanda petir di titik grid yang sedang badai petir
- Sentuh peta → pin lokasi + panel **prakiraan per jam** (Hari ini / Besok): ikon, suhu, peluang hujan, angin; peringatan potensi badai petir dari kode cuaca + CAPE
- Pencarian kota
- UI flat, minimalis, ikon cuaca digambar sendiri (Canvas), tanpa file gambar

## Cara menjalankan

1. Install Android Studio (Koala 2024.1 atau lebih baru).
2. `File > Open` → pilih folder `atmosphere` ini, tunggu Gradle sync selesai.
3. Colok HP (aktifkan Opsi Pengembang + USB debugging) → tekan **Run**.
4. Untuk APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

## API gratis yang dipakai (tanpa API key)

| Data | Sumber | Catatan |
|---|---|---|
| Prakiraan, angin, CAPE, pencarian kota | Open-Meteo | Gratis untuk non-komersial |
| Radar hujan | RainViewer | Tier gratis: zoom tile maks 7, hanya data lampau (tanpa nowcast), wajib atribusi |
| Nama lokasi dari koordinat | Nominatim (OSM) | Maks ~1 request/detik, cukup untuk pemakaian pribadi |
| Basemap | CARTO + OSM | Atribusi tampil di aplikasi |

Grid angin memakai 20 titik per pembaruan (diminta 0,8 detik setelah peta berhenti digeser).

## Struktur

```
app/src/main/java/com/atmosphere/app/
├─ MainActivity.kt
├─ data/   Models.kt, WeatherApi.kt      ← semua panggilan API
├─ map/    MapLayers.kt                  ← radar, panah angin, penanda badai, pin
└─ ui/     AtmosphereApp.kt, ForecastSheet.kt, WeatherIcons.kt, Glyphs.kt, Theme.kt
```

## Penyesuaian

- Warna radar kosong/aneh → ubah `RADAR_COLOR` di `RadarTileSource` (MapLayers.kt).
- Kepadatan grid angin → parameter `4, 5` (kolom, baris) di `refreshWind` (AtmosphereApp.kt).
- Palet warna → objek `C` di Theme.kt.

## Belum ada

Lokasi GPS saya, notifikasi peringatan, dan jalur siklon tropis (data siklon gratis perlu sumber lain, mis. GDACS/NOAA).
