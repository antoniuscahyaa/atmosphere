# Atmosphere

Aplikasi cuaca native Android (Kotlin + Jetpack Compose) dengan peta live.
Package: `com.atmosphere.app` · Min Android 8 (API 26) · Target API 34 → jalan di Android 10.

## Fitur

- Peta yang bisa digeser dan di-zoom (OpenStreetMap, basemap OSM standar)
- Lapisan **Radar** hujan live + animasi 2 jam terakhir (RainViewer)
- Lapisan **Angin**: panah arah angin berwarna menurut kecepatan, mengikuti area peta yang terlihat
- Lapisan **Badai**: penanda petir di titik grid yang sedang badai petir
- Sentuh peta → pin lokasi + panel **prakiraan per jam** (Hari ini / Besok): ikon, suhu, peluang hujan, angin; peringatan potensi badai petir dari kode cuaca + CAPE
- Lapisan **Peringatan**: poligon peringatan dini cuaca BMKG (CAP), warna menurut tingkat keparahan
- Lapisan **Gempa**: gempa terbaru BMKG (M5+ dan gempa terbaru), lingkaran berwarna menurut magnitudo
- Lapisan **Api**: titik panas 24 jam terakhir (NASA FIRMS, VIIRS), perlu zoom ≥ 5 dan key gratis
- Panel prakiraan juga menampilkan **kualitas udara** (AQI AS, PM2.5/PM10) dan **tinggi gelombang** (hanya di laut)
- Pencarian kota
- UI flat, minimalis, ikon cuaca digambar sendiri (Canvas), tanpa file gambar

## Cara menjalankan

1. Install Android Studio (Koala 2024.1 atau lebih baru).
2. `File > Open` → pilih folder `atmosphere` ini, tunggu Gradle sync selesai.
3. Colok HP (aktifkan Opsi Pengembang + USB debugging) → tekan **Run**.
4. Untuk APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

## Mengisi API key NASA FIRMS (lapisan "Api")

Hanya lapisan Api yang butuh key. Daftar gratis di https://firms.modaps.eosdis.nasa.gov/api/map_key/ (key dikirim ke email), lalu:

- **Lokal**: tambah baris ini di `local.properties` (file ini otomatis di-ignore git):
  ```
  FIRMS_MAP_KEY=kunci_anda
  ```
- **CI / GitHub Actions**: buat secret `FIRMS_MAP_KEY` dan teruskan sebagai environment variable pada langkah build.

Tanpa key, app tetap jalan; chip Api hanya menampilkan pesan "Key NASA FIRMS belum diisi". Key tertanam di APK, jadi pakai key khusus app ini.

## API gratis yang dipakai (tanpa API key kecuali FIRMS)

| Data | Sumber | Catatan |
|---|---|---|
| Prakiraan, angin, CAPE, pencarian kota | Open-Meteo | Gratis untuk non-komersial |
| Radar hujan | RainViewer | Tier gratis: zoom tile maks 7, hanya data lampau (tanpa nowcast), wajib atribusi |
| Nama lokasi dari koordinat | Nominatim (OSM) | Maks ~1 request/detik, cukup untuk pemakaian pribadi |
| Basemap | OpenStreetMap (tile.openstreetmap.org) | Atribusi tampil; untuk pemakaian ramai pertimbangkan penyedia tile sendiri |
| Kualitas udara | Open-Meteo Air Quality | AQI AS, PM2.5, PM10 |
| Gelombang laut | Open-Meteo Marine | Kosong untuk lokasi daratan |
| Gempa | BMKG Data Terbuka (`data.bmkg.go.id`) | `gempaterkini.json`, `autogempa.json`; cantumkan BMKG sebagai sumber |
| Peringatan dini cuaca | BMKG (`bmkg.go.id/alerts/nowcast/id`, CAP) | Gagal satu CAP tidak menggagalkan yang lain |
| Titik api | NASA FIRMS (butuh `FIRMS_MAP_KEY`) | VIIRS S-NPP NRT, 1 hari, maks 800 titik |

Grid angin memakai 20 titik per pembaruan (diminta 0,8 detik setelah peta berhenti digeser).

## Struktur

```
app/src/main/java/com/atmosphere/app/
├─ MainActivity.kt
├─ data/   Models.kt, WeatherApi.kt      ← semua panggilan API
├─ map/    MapLayers.kt                  ← radar, panah angin, penanda badai, pin, gempa/api/peringatan
└─ ui/     AtmosphereApp.kt, ForecastSheet.kt, WeatherIcons.kt, Glyphs.kt, Theme.kt
```

## Penyesuaian

- Warna radar kosong/aneh → ubah `RADAR_COLOR` di `RadarTileSource` (MapLayers.kt).
- Kepadatan grid angin → parameter `4, 5` (kolom, baris) di `refreshWind` (AtmosphereApp.kt).
- Palet warna → objek `C` di Theme.kt.

## Belum ada

Lokasi GPS saya, notifikasi peringatan, ketuk gempa/peringatan untuk detail, dan jalur siklon tropis (data siklon gratis perlu sumber lain, mis. GDACS/NOAA).
