package com.atmosphere.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun SearchGlyph(color: Color, sz: Dp = 20.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        drawCircle(color, s * 0.32f, Offset(s * 0.42f, s * 0.42f), style = Stroke(width = s * 0.12f))
        drawLine(color, Offset(s * 0.66f, s * 0.66f), Offset(s * 0.9f, s * 0.9f), strokeWidth = s * 0.13f, cap = StrokeCap.Round)
    }
}

@Composable
fun CloseGlyph(color: Color, sz: Dp = 14.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        drawLine(color, Offset(s * 0.1f, s * 0.1f), Offset(s * 0.9f, s * 0.9f), strokeWidth = s * 0.16f, cap = StrokeCap.Round)
        drawLine(color, Offset(s * 0.9f, s * 0.1f), Offset(s * 0.1f, s * 0.9f), strokeWidth = s * 0.16f, cap = StrokeCap.Round)
    }
}

@Composable
fun PlayGlyph(color: Color, sz: Dp = 14.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val p = Path().apply {
            moveTo(s * 0.2f, s * 0.08f)
            lineTo(s * 0.92f, s * 0.5f)
            lineTo(s * 0.2f, s * 0.92f)
            close()
        }
        drawPath(p, color)
    }
}

@Composable
fun PauseGlyph(color: Color, sz: Dp = 14.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        drawRoundRect(color, Offset(s * 0.12f, s * 0.08f), Size(s * 0.27f, s * 0.84f), CornerRadius(s * 0.08f))
        drawRoundRect(color, Offset(s * 0.61f, s * 0.08f), Size(s * 0.27f, s * 0.84f), CornerRadius(s * 0.08f))
    }
}

@Composable
fun WindGlyph(color: Color, sz: Dp = 18.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val w = s * 0.12f
        drawLine(color, Offset(s * 0.1f, s * 0.32f), Offset(s * 0.68f, s * 0.32f), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(color, Offset(s * 0.1f, s * 0.52f), Offset(s * 0.88f, s * 0.52f), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(color, Offset(s * 0.1f, s * 0.72f), Offset(s * 0.55f, s * 0.72f), strokeWidth = w, cap = StrokeCap.Round)
    }
}

@Composable
fun BoltGlyph(color: Color, sz: Dp = 18.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        bolt(s * 0.5f, s * 0.5f, s * 0.95f, color)
    }
}

@Composable
fun DropGlyph(color: Color, sz: Dp = 10.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val p = Path().apply {
            moveTo(s * 0.5f, s * 0.02f)
            lineTo(s * 0.86f, s * 0.58f)
            lineTo(s * 0.14f, s * 0.58f)
            close()
        }
        drawPath(p, color)
        drawCircle(color, s * 0.36f, Offset(s * 0.5f, s * 0.64f))
    }
}

/** Panah menunjuk ke arah [toDeg] (0 = utara/atas, searah jarum jam). */
@Composable
fun WindArrow(toDeg: Float, color: Color, sz: Dp = 12.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        rotate(toDeg) {
            drawLine(color, Offset(s * 0.5f, s * 0.92f), Offset(s * 0.5f, s * 0.3f), strokeWidth = s * 0.16f, cap = StrokeCap.Round)
            val head = Path().apply {
                moveTo(s * 0.5f, s * 0.04f)
                lineTo(s * 0.86f, s * 0.46f)
                lineTo(s * 0.14f, s * 0.46f)
                close()
            }
            drawPath(head, color)
        }
    }
}
