package com.atmosphere.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun SearchGlyph(color: Color, sz: Dp = 20.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        drawCircle(color, s * 0.32f, Offset(s * 0.42f, s * 0.42f), style = Stroke(width = s * 0.12f))
        drawLine(color, Offset(s * 0.66f, s * 0.66f), Offset(s * 0.9f, s * 0.9f), strokeWidth = s * 0.13f, cap = StrokeCap.Round)
    }
}

@Composable
fun CloseGlyph(color: Color, sz: Dp = 14.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        drawLine(color, Offset(s * 0.1f, s * 0.1f), Offset(s * 0.9f, s * 0.9f), strokeWidth = s * 0.16f, cap = StrokeCap.Round)
        drawLine(color, Offset(s * 0.9f, s * 0.1f), Offset(s * 0.1f, s * 0.9f), strokeWidth = s * 0.16f, cap = StrokeCap.Round)
    }
}

@Composable
fun PlayGlyph(color: Color, sz: Dp = 14.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val p = Path().apply {
            moveTo(s * 0.2f, s * 0.08f)
            lineTo(s * 0.92f, s * 0.5f)
            lineTo(s * 0.2f, s * 0.92f)
            close()
        }
        drawPath(p, color)
    }
}

@Composable
fun PauseGlyph(color: Color, sz: Dp = 14.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        drawRoundRect(color, Offset(s * 0.12f, s * 0.08f), Size(s * 0.27f, s * 0.84f), CornerRadius(s * 0.08f))
        drawRoundRect(color, Offset(s * 0.61f, s * 0.08f), Size(s * 0.27f, s * 0.84f), CornerRadius(s * 0.08f))
    }
}

@Composable
fun WindGlyph(color: Color, sz: Dp = 18.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val w = s * 0.12f
        drawLine(color, Offset(s * 0.1f, s * 0.32f), Offset(s * 0.68f, s * 0.32f), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(color, Offset(s * 0.1f, s * 0.52f), Offset(s * 0.88f, s * 0.52f), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(color, Offset(s * 0.1f, s * 0.72f), Offset(s * 0.55f, s * 0.72f), strokeWidth = w, cap = StrokeCap.Round)
    }
}

@Composable
fun BoltGlyph(color: Color, sz: Dp = 18.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        bolt(s * 0.5f, s * 0.5f, s * 0.95f, color)
    }
}

@Composable
fun DropGlyph(color: Color, sz: Dp = 10.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val p = Path().apply {
            moveTo(s * 0.5f, s * 0.02f)
            lineTo(s * 0.86f, s * 0.58f)
            lineTo(s * 0.14f, s * 0.58f)
            close()
        }
        drawPath(p, color)
        drawCircle(color, s * 0.36f, Offset(s * 0.5f, s * 0.64f))
    }
}

/** Panah menunjuk ke arah [toDeg] (0 = utara/atas, searah jarum jam). */
@Composable
fun WindArrow(toDeg: Float, color: Color, sz: Dp = 12.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        rotate(toDeg) {
            drawLine(color, Offset(s * 0.5f, s * 0.92f), Offset(s * 0.5f, s * 0.3f), strokeWidth = s * 0.16f, cap = StrokeCap.Round)
            val head = Path().apply {
                moveTo(s * 0.5f, s * 0.04f)
                lineTo(s * 0.86f, s * 0.46f)
                lineTo(s * 0.14f, s * 0.46f)
                close()
            }
            drawPath(head, color)
        }
    }
}

@Composable
fun AlertGlyph(color: Color, sz: Dp = 18.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val p = Path().apply {
            moveTo(s * 0.5f, s * 0.08f)
            lineTo(s * 0.95f, s * 0.88f)
            lineTo(s * 0.05f, s * 0.88f)
            close()
        }
        drawPath(p, color)
        // tanda seru: dibuat "lubang" memakai warna transparan tidak mungkin, jadi pakai garis putih/gelap kontras
        val mark = if (color == Color.White) Color(0xFFD98E00) else Color.White
        drawLine(mark, Offset(s * 0.5f, s * 0.36f), Offset(s * 0.5f, s * 0.60f), strokeWidth = s * 0.11f, cap = StrokeCap.Round)
        drawCircle(mark, s * 0.06f, Offset(s * 0.5f, s * 0.75f))
    }
}

@Composable
fun QuakeGlyph(color: Color, sz: Dp = 18.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val p = Path().apply {
            moveTo(s * 0.05f, s * 0.55f)
            lineTo(s * 0.27f, s * 0.55f)
            lineTo(s * 0.38f, s * 0.2f)
            lineTo(s * 0.55f, s * 0.85f)
            lineTo(s * 0.67f, s * 0.4f)
            lineTo(s * 0.74f, s * 0.55f)
            lineTo(s * 0.95f, s * 0.55f)
        }
        drawPath(p, color, style = Stroke(width = s * 0.11f, cap = StrokeCap.Round))
    }
}

@Composable
fun FlameGlyph(color: Color, sz: Dp = 18.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val p = Path().apply {
            moveTo(s * 0.52f, s * 0.04f)
            cubicTo(s * 0.55f, s * 0.30f, s * 0.88f, s * 0.42f, s * 0.82f, s * 0.68f)
            cubicTo(s * 0.78f, s * 0.90f, s * 0.60f, s * 0.96f, s * 0.50f, s * 0.96f)
            cubicTo(s * 0.30f, s * 0.96f, s * 0.14f, s * 0.82f, s * 0.18f, s * 0.60f)
            cubicTo(s * 0.20f, s * 0.46f, s * 0.30f, s * 0.38f, s * 0.34f, s * 0.26f)
            cubicTo(s * 0.44f, s * 0.34f, s * 0.46f, s * 0.40f, s * 0.46f, s * 0.46f)
            cubicTo(s * 0.52f, s * 0.34f, s * 0.52f, s * 0.20f, s * 0.52f, s * 0.04f)
            close()
        }
        drawPath(p, color)
    }
}

@Composable
fun LocateGlyph(color: Color, sz: Dp = 22.dp) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        val w = s * 0.09f
        drawCircle(color, s * 0.27f, Offset(s * 0.5f, s * 0.5f), style = Stroke(width = w))
        drawCircle(color, s * 0.11f, Offset(s * 0.5f, s * 0.5f))
        drawLine(color, Offset(s * 0.5f, s * 0.04f), Offset(s * 0.5f, s * 0.16f), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(color, Offset(s * 0.5f, s * 0.84f), Offset(s * 0.5f, s * 0.96f), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(color, Offset(s * 0.04f, s * 0.5f), Offset(s * 0.16f, s * 0.5f), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(color, Offset(s * 0.84f, s * 0.5f), Offset(s * 0.96f, s * 0.5f), strokeWidth = w, cap = StrokeCap.Round)
    }
}
