package com.atmosphere.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp

/** Palet flat & berwarna. */
object C {
    val Bg = Color(0xFFF4F7FB)
    val Ink = Color(0xFF14213D)
    val Muted = Color(0xFF6B7A90)
    val Chip = Color(0xFFEDF2FA)
    val Blue = Color(0xFF3A86FF)
    val Sun = Color(0xFFFFB703)
    val Gold = Color(0xFFD98E00)
    val Orange = Color(0xFFFB5607)
    val Pink = Color(0xFFFF006E)
    val Purple = Color(0xFF8338EC)
    val Teal = Color(0xFF2EC4B6)
}

@Composable
fun AtmosphereTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = C.Blue,
            onPrimary = Color.White,
            background = C.Bg,
            surface = Color.White,
            onSurface = C.Ink,
        ),
        content = content,
    )
}

@Composable
fun Txt(
    text: String,
    size: Int = 14,
    color: Color = C.Ink,
    bold: Boolean = false,
    modifier: Modifier = Modifier,
    maxLines: Int = Int.MAX_VALUE,
    align: TextAlign? = null,
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        textAlign = align,
    )
}
