package com.atmosphere.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.IOException
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Semua sumber data gratis & tanpa API key:
 *  - Open-Meteo        : prakiraan cuaca, angin, CAPE (potensi badai), geocoding
 *  - RainViewer        : tile radar hujan
 *  - Nominatim (OSM)   : nama lokasi dari koordinat (reverse geocoding)
 *  - Open-Meteo AQ     : kualitas udara (AQI, PM2.5, PM10)
 *  - Open-Meteo Marine : tinggi gelombang
 *  - BMKG Data Terbuka : gempa terkini + peringatan dini cuaca (CAP)
 * Satu-satunya yang butuh key: NASA FIRMS (titik api), key gratis -> lihat BuildConfig.FIRMS_MAP_KEY.
 */
object WeatherApi {
    private const val UA = "Atmosphere/1.0 (com.atmosphere.app)"
    private const val FORECAST = "https://api.open-meteo.com/v1/forecast"

    private fun f(v: Double) = String.format(Locale.US, "%.4f", v)

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun JSONArray.d(i: Int): Double = if (isNull(i)) 0.0 else optDouble(i, 0.0)
    private fun JSONArray.n(i: Int): Int = if (isNull(i)) 0 else optInt(i, 0)

    /** Prakiraan per jam untuk hari ini + besok di zona waktu lokasi. */
    suspend fun forecast(lat: Double, lon: Double): Forecast {
        val url = "$FORECAST?latitude=${f(lat)}&longitude=${f(lon)}" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,is_day,precipitation," +
            "weather_code,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m" +
            "&hourly=temperature_2m,precipitation_probability,precipitation,weather_code," +
            "wind_speed_10m,wind_direction_10m,wind_gusts_10m,is_day,cape,uv_index" +
            "&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max" +
            "&timezone=auto&forecast_days=2"
        val j = JSONObject(get(url))

        val c = j.getJSONObject("current")
        val t = c.getString("time")
        val now = Now(
            date = t.substring(0, 10),
            hour = t.substring(11, 13).toInt(),
            temp = c.optDouble("temperature_2m", 0.0),
            feels = c.optDouble("apparent_temperature", 0.0),
            humidity = c.optInt("relative_humidity_2m", 0),
            code = c.optInt("weather_code", 0),
            isDay = c.optInt("is_day", 1) == 1,
            rain = c.optDouble("precipitation", 0.0),
            pressure = c.optDouble("pressure_msl", 0.0),
            wind = c.optDouble("wind_speed_10m", 0.0),
            windDir = c.optDouble("wind_direction_10m", 0.0),
            gust = c.optDouble("wind_gusts_10m", 0.0),
        )

        val h = j.getJSONObject("hourly")
        val times = h.getJSONArray("time")
        val temp = h.getJSONArray("temperature_2m")
        val prob = h.getJSONArray("precipitation_probability")
        val rain = h.getJSONArray("precipitation")
        val code = h.getJSONArray("weather_code")
        val ws = h.getJSONArray("wind_speed_10m")
        val wd = h.getJSONArray("wind_direction_10m")
        val wg = h.getJSONArray("wind_gusts_10m")
        val day = h.getJSONArray("is_day")
        val cape = h.getJSONArray("cape")
        val uv = h.getJSONArray("uv_index")
        val hours = List(times.length()) { i ->
            val ts = times.getString(i)
            Hour(
                date = ts.substring(0, 10),
                hour = ts.substring(11, 13).toInt(),
                temp = temp.d(i),
                code = code.n(i),
                isDay = day.n(i) == 1,
                rainProb = prob.n(i),
                rain = rain.d(i),
                wind = ws.d(i),
                windDir = wd.d(i),
                gust = wg.d(i),
                cape = cape.d(i),
                uv = uv.d(i),
            )
        }

        val dj = j.getJSONObject("daily")
        val dt = dj.getJSONArray("time")
        val dmax = dj.getJSONArray("temperature_2m_max")
        val dmin = dj.getJSONArray("temperature_2m_min")
        val sr = dj.getJSONArray("sunrise")
        val ss = dj.getJSONArray("sunset")
        val duv = dj.getJSONArray("uv_index_max")
        val days = List(dt.length()) { i ->
            Day(dt.getString(i), dmax.d(i), dmin.d(i), sr.getString(i), ss.getString(i), duv.d(i))
        }
        return Forecast(now, days, hours)
    }

    /**
     * Grid angin untuk area yang sedang terlihat di peta.
     * Satu request Open-Meteo untuk banyak koordinat sekaligus.
     */
    suspend fun windGrid(
        south: Double, north: Double, west: Double, east: Double,
        cols: Int, rows: Int,
    ): List<WindPoint> {
        val s = south.coerceIn(-80.0, 80.0)
        val n = north.coerceIn(-80.0, 80.0)
        val lats = ArrayList<Double>()
        val lons = ArrayList<Double>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                lats += s + (r + 0.5) / rows * (n - s)
                val lon = west + (c + 0.5) / cols * (east - west)
                lons += ((lon + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
            }
        }
        val url = "$FORECAST?latitude=${lats.joinToString(",") { f(it) }}" +
            "&longitude=${lons.joinToString(",") { f(it) }}" +
            "&current=wind_speed_10m,wind_direction_10m,weather_code&timezone=auto"
        val txt = get(url).trim()
        val arr = if (txt.startsWith("[")) JSONArray(txt) else JSONArray().put(JSONObject(txt))
        val out = ArrayList<WindPoint>()
        for (i in 0 until minOf(arr.length(), lats.size)) {
            val cur = arr.getJSONObject(i).optJSONObject("current") ?: continue
            out += WindPoint(
                lat = lats[i],
                lon = lons[i],
                speed = cur.optDouble("wind_speed_10m", 0.0),
                dir = cur.optDouble("wind_direction_10m", 0.0),
                code = cur.optInt("weather_code", 0),
            )
        }
        return out
    }

    /** Frame radar hujan terbaru dari RainViewer. */
    suspend fun radar(): RadarData {
        val j = JSONObject(get("https://api.rainviewer.com/public/weather-maps.json"))
        val past = j.getJSONObject("radar").getJSONArray("past")
        val frames = List(past.length()) { i ->
            val o = past.getJSONObject(i)
            RadarFrame(o.getLong("time"), o.getString("path"))
        }
        return RadarData(j.getString("host"), frames)
    }

    suspend fun search(q: String): List<Place> {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            "${URLEncoder.encode(q, "UTF-8")}&count=6&language=id&format=json"
        val r = JSONObject(get(url)).optJSONArray("results") ?: return emptyList()
        return List(r.length()) { i ->
            val o = r.getJSONObject(i)
            Place(
                name = o.optString("name"),
                detail = listOf(o.optString("admin1"), o.optString("country"))
                    .filter { it.isNotBlank() }
                    .joinToString(", "),
                lat = o.getDouble("latitude"),
                lon = o.getDouble("longitude"),
            )
        }
    }

    /** Nama tempat dari koordinat; null jika gagal (mis. di tengah laut). */
    suspend fun reverseName(lat: Double, lon: Double): String? = try {
        val j = JSONObject(
            get(
                "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10" +
                    "&accept-language=id&lat=${f(lat)}&lon=${f(lon)}"
            )
        )
        val a = j.optJSONObject("address")
        val main = listOf("village", "town", "city", "municipality", "county", "state_district", "state")
            .firstNotNullOfOrNull { k -> a?.optString(k)?.takeIf { it.isNotBlank() } }
        val country = a?.optString("country").orEmpty()
        listOfNotNull(main, country.takeIf { it.isNotBlank() })
            .joinToString(", ")
            .ifBlank { null }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    // ------------------------------------------------------------------
    // Kualitas udara & gelombang (Open-Meteo, tanpa key)
    // ------------------------------------------------------------------

    suspend fun airQuality(lat: Double, lon: Double): AirQuality? = try {
        val url = "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${f(lat)}&longitude=${f(lon)}" +
            "&current=us_aqi,pm2_5,pm10&hourly=us_aqi,pm2_5&timezone=auto&forecast_days=2"
        val j = JSONObject(get(url))
        val c = j.getJSONObject("current")
        val t = c.getString("time")
        val h = j.getJSONObject("hourly")
        val times = h.getJSONArray("time")
        val aqi = h.getJSONArray("us_aqi")
        val pm = h.getJSONArray("pm2_5")
        AirQuality(
            aqi = c.optInt("us_aqi", -1),
            pm25 = c.optDouble("pm2_5", 0.0),
            pm10 = c.optDouble("pm10", 0.0),
            date = t.substring(0, 10),
            hour = t.substring(11, 13).toInt(),
            hours = List(times.length()) { i ->
                val ts = times.getString(i)
                AirHour(ts.substring(0, 10), ts.substring(11, 13).toInt(), aqi.n(i), pm.d(i))
            },
        ).takeIf { it.aqi >= 0 }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    /** null jika lokasi di daratan (API mengembalikan error / data kosong). */
    suspend fun marine(lat: Double, lon: Double): Marine? = try {
        val url = "https://marine-api.open-meteo.com/v1/marine?latitude=${f(lat)}&longitude=${f(lon)}" +
            "&current=wave_height,wave_period,wave_direction" +
            "&hourly=wave_height,wave_period,wave_direction&timezone=auto&forecast_days=2"
        val j = JSONObject(get(url))
        val c = j.getJSONObject("current")
        if (c.isNull("wave_height")) null else {
            val h = j.getJSONObject("hourly")
            val times = h.getJSONArray("time")
            val wh = h.getJSONArray("wave_height")
            val wp = h.getJSONArray("wave_period")
            val wd = h.getJSONArray("wave_direction")
            Marine(
                height = c.optDouble("wave_height", 0.0),
                period = c.optDouble("wave_period", 0.0),
                dir = c.optDouble("wave_direction", 0.0),
                hours = List(times.length()) { i ->
                    val ts = times.getString(i)
                    WaveHour(ts.substring(0, 10), ts.substring(11, 13).toInt(), wh.d(i), wp.d(i), wd.d(i))
                },
            )
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    // ------------------------------------------------------------------
    // BMKG
    // ------------------------------------------------------------------

    private const val BMKG_QUAKE = "https://data.bmkg.go.id/DataMKG/TEWS/"

    private fun parseQuake(o: JSONObject): Quake? {
        // "Coordinates": "-6.10,106.80" (lat,lon). Cadangan: Lintang/Bujur "6.10 LS" / "106.80 BT".
        var lat: Double? = null
        var lon: Double? = null
        val co = o.optString("Coordinates")
        if (co.contains(",")) {
            lat = co.substringBefore(",").trim().toDoubleOrNull()
            lon = co.substringAfter(",").trim().toDoubleOrNull()
        }
        if (lat == null || lon == null) {
            val la = o.optString("Lintang")
            val lo = o.optString("Bujur")
            lat = la.substringBefore(" ").toDoubleOrNull()?.let { if (la.contains("LS")) -it else it }
            lon = lo.substringBefore(" ").toDoubleOrNull()?.let { if (lo.contains("BB")) -it else it }
        }
        if (lat == null || lon == null) return null
        return Quake(
            lat = lat,
            lon = lon,
            mag = o.optString("Magnitude").replace(',', '.').toDoubleOrNull() ?: 0.0,
            depth = o.optString("Kedalaman"),
            region = o.optString("Wilayah"),
            time = listOf(o.optString("Tanggal"), o.optString("Jam")).filter { it.isNotBlank() }.joinToString(" "),
            tsunami = o.optString("Potensi"),
        )
    }

    /** Gempa M5+ terbaru (gempaterkini) digabung dengan gempa terbaru (autogempa). */
    suspend fun quakes(): List<Quake> {
        val out = ArrayList<Quake>()
        runCatching {
            val g = JSONObject(get(BMKG_QUAKE + "gempaterkini.json")).getJSONObject("Infogempa").get("gempa")
            if (g is JSONArray) for (i in 0 until g.length()) parseQuake(g.getJSONObject(i))?.let { out += it }
            else if (g is JSONObject) parseQuake(g)?.let { out += it }
        }
        runCatching {
            val g = JSONObject(get(BMKG_QUAKE + "autogempa.json")).getJSONObject("Infogempa").getJSONObject("gempa")
            parseQuake(g)?.let { q -> if (out.none { it.time == q.time && it.region == q.region }) out += q }
        }
        if (out.isEmpty()) throw IOException("Data gempa BMKG kosong")
        return out
    }

    /**
     * Peringatan dini cuaca (nowcast) BMKG: RSS berisi tautan ke berkas CAP per peringatan.
     * Dibatasi 25 peringatan agar hemat kuota. Gagal pada satu CAP tidak menggagalkan yang lain.
     */
    suspend fun alerts(): List<WeatherAlert> {
        val rss = get("https://www.bmkg.go.id/alerts/nowcast/id")
        val links = LinkedHashSet<String>()
        val p = XmlPullParserFactory.newInstance().newPullParser()
        p.setInput(StringReader(rss))
        var ev = p.eventType
        var inItem = false
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "item", "entry" -> inItem = true
                    "link" -> if (inItem) {
                        val href = p.getAttributeValue(null, "href")
                        val t = href ?: runCatching { p.nextText() }.getOrNull()
                        t?.trim()?.takeIf { it.startsWith("http") }?.let { links += it }
                    }
                }
            } else if (ev == XmlPullParser.END_TAG && (p.name == "item" || p.name == "entry")) inItem = false
            ev = p.next()
        }
        val out = ArrayList<WeatherAlert>()
        for (u in links.take(25)) {
            runCatching { parseCap(get(u)) }.getOrNull()?.let { out += it }
        }
        return out
    }

    private fun parseCap(xml: String): WeatherAlert? {
        val p = XmlPullParserFactory.newInstance().newPullParser()
        p.setInput(StringReader(xml))
        var event = ""
        var headline = ""
        var severity = ""
        var area = ""
        val polys = ArrayList<List<Pair<Double, Double>>>()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "event" -> event = p.nextText().trim()
                    "headline" -> headline = p.nextText().trim()
                    "severity" -> severity = p.nextText().trim()
                    "areaDesc" -> if (area.isBlank()) area = p.nextText().trim()
                    "polygon" -> {
                        // CAP: "lat,lon lat,lon ..."
                        val pts = p.nextText().trim().split(Regex("\\s+")).mapNotNull { s ->
                            val a = s.split(",")
                            val la = a.getOrNull(0)?.toDoubleOrNull()
                            val lo = a.getOrNull(1)?.toDoubleOrNull()
                            if (la != null && lo != null) la to lo else null
                        }
                        if (pts.size >= 3) polys += pts
                    }
                }
            }
            ev = p.next()
        }
        if (polys.isEmpty()) return null
        return WeatherAlert(event, headline, area, severity, polys)
    }

    // ------------------------------------------------------------------
    // NASA FIRMS (butuh MAP_KEY gratis)
    // ------------------------------------------------------------------

    /** Titik panas 24 jam terakhir (VIIRS S-NPP NRT) di area peta. Maks 800 titik, FRP terbesar dulu. */
    suspend fun fires(
        key: String, south: Double, north: Double, west: Double, east: Double,
    ): List<FireSpot> {
        val w = west.coerceIn(-180.0, 180.0)
        val e = east.coerceIn(-180.0, 180.0)
        val area = "${f(w)},${f(south.coerceIn(-90.0, 90.0))},${f(e)},${f(north.coerceIn(-90.0, 90.0))}"
        val csv = get("https://firms.modaps.eosdis.nasa.gov/api/area/csv/$key/VIIRS_SNPP_NRT/$area/1")
        val lines = csv.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.isEmpty()) return emptyList()
        val head = lines[0].split(",")
        if (!head.contains("latitude")) throw IOException(lines[0].take(80)) // mis. "Invalid MAP_KEY"
        val iLat = head.indexOf("latitude")
        val iLon = head.indexOf("longitude")
        val iFrp = head.indexOf("frp")
        val iConf = head.indexOf("confidence")
        return lines.drop(1).mapNotNull { l ->
            val c = l.split(",")
            val la = c.getOrNull(iLat)?.toDoubleOrNull() ?: return@mapNotNull null
            val lo = c.getOrNull(iLon)?.toDoubleOrNull() ?: return@mapNotNull null
            val conf = c.getOrNull(iConf)?.trim()?.lowercase().orEmpty()
            if (conf == "l" || conf == "low") return@mapNotNull null
            FireSpot(la, lo, c.getOrNull(iFrp)?.toDoubleOrNull() ?: 0.0, conf == "h" || conf == "high")
        }.sortedByDescending { it.frp }.take(800)
    }
}
