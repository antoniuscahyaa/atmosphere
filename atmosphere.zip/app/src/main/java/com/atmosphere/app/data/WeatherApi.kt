package com.atmosphere.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Semua sumber data gratis & tanpa API key:
 *  - Open-Meteo        : prakiraan cuaca, angin, CAPE (potensi badai), geocoding
 *  - RainViewer        : tile radar hujan
 *  - Nominatim (OSM)   : nama lokasi dari koordinat (reverse geocoding)
 */
object WeatherApi {
    private const val UA = "Atmosphere/1.0 (com.atmosphere.app)"
    private const val FORECAST = "https://api.open-meteo.com/v1/forecast"

    private fun f(v: Double) = String.format(Locale.US, "%.4f", v)

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun JSONArray.d(i: Int): Double = if (isNull(i)) 0.0 else optDouble(i, 0.0)
    private fun JSONArray.n(i: Int): Int = if (isNull(i)) 0 else optInt(i, 0)

    /** Prakiraan per jam untuk hari ini + besok di zona waktu lokasi. */
    suspend fun forecast(lat: Double, lon: Double): Forecast {
        val url = "$FORECAST?latitude=${f(lat)}&longitude=${f(lon)}" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,is_day,precipitation," +
            "weather_code,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m" +
            "&hourly=temperature_2m,precipitation_probability,precipitation,weather_code," +
            "wind_speed_10m,wind_direction_10m,wind_gusts_10m,is_day,cape,uv_index" +
            "&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max" +
            "&timezone=auto&forecast_days=2"
        val j = JSONObject(get(url))

        val c = j.getJSONObject("current")
        val t = c.getString("time")
        val now = Now(
            date = t.substring(0, 10),
            hour = t.substring(11, 13).toInt(),
            temp = c.optDouble("temperature_2m", 0.0),
            feels = c.optDouble("apparent_temperature", 0.0),
            humidity = c.optInt("relative_humidity_2m", 0),
            code = c.optInt("weather_code", 0),
            isDay = c.optInt("is_day", 1) == 1,
            rain = c.optDouble("precipitation", 0.0),
            pressure = c.optDouble("pressure_msl", 0.0),
            wind = c.optDouble("wind_speed_10m", 0.0),
            windDir = c.optDouble("wind_direction_10m", 0.0),
            gust = c.optDouble("wind_gusts_10m", 0.0),
        )

        val h = j.getJSONObject("hourly")
        val times = h.getJSONArray("time")
        val temp = h.getJSONArray("temperature_2m")
        val prob = h.getJSONArray("precipitation_probability")
        val rain = h.getJSONArray("precipitation")
        val code = h.getJSONArray("weather_code")
        val ws = h.getJSONArray("wind_speed_10m")
        val wd = h.getJSONArray("wind_direction_10m")
        val wg = h.getJSONArray("wind_gusts_10m")
        val day = h.getJSONArray("is_day")
        val cape = h.getJSONArray("cape")
        val uv = h.getJSONArray("uv_index")
        val hours = List(times.length()) { i ->
            val ts = times.getString(i)
            Hour(
                date = ts.substring(0, 10),
                hour = ts.substring(11, 13).toInt(),
                temp = temp.d(i),
                code = code.n(i),
                isDay = day.n(i) == 1,
                rainProb = prob.n(i),
                rain = rain.d(i),
                wind = ws.d(i),
                windDir = wd.d(i),
                gust = wg.d(i),
                cape = cape.d(i),
                uv = uv.d(i),
            )
        }

        val dj = j.getJSONObject("daily")
        val dt = dj.getJSONArray("time")
        val dmax = dj.getJSONArray("temperature_2m_max")
        val dmin = dj.getJSONArray("temperature_2m_min")
        val sr = dj.getJSONArray("sunrise")
        val ss = dj.getJSONArray("sunset")
        val duv = dj.getJSONArray("uv_index_max")
        val days = List(dt.length()) { i ->
            Day(dt.getString(i), dmax.d(i), dmin.d(i), sr.getString(i), ss.getString(i), duv.d(i))
        }
        return Forecast(now, days, hours)
    }

    /**
     * Grid angin untuk area yang sedang terlihat di peta.
     * Satu request Open-Meteo untuk banyak koordinat sekaligus.
     */
    suspend fun windGrid(
        south: Double, north: Double, west: Double, east: Double,
        cols: Int, rows: Int,
    ): List<WindPoint> {
        val s = south.coerceIn(-80.0, 80.0)
        val n = north.coerceIn(-80.0, 80.0)
        val lats = ArrayList<Double>()
        val lons = ArrayList<Double>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                lats += s + (r + 0.5) / rows * (n - s)
                val lon = west + (c + 0.5) / cols * (east - west)
                lons += ((lon + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
            }
        }
        val url = "$FORECAST?latitude=${lats.joinToString(",") { f(it) }}" +
            "&longitude=${lons.joinToString(",") { f(it) }}" +
            "&current=wind_speed_10m,wind_direction_10m,weather_code&timezone=auto"
        val txt = get(url).trim()
        val arr = if (txt.startsWith("[")) JSONArray(txt) else JSONArray().put(JSONObject(txt))
        val out = ArrayList<WindPoint>()
        for (i in 0 until minOf(arr.length(), lats.size)) {
            val cur = arr.getJSONObject(i).optJSONObject("current") ?: continue
            out += WindPoint(
                lat = lats[i],
                lon = lons[i],
                speed = cur.optDouble("wind_speed_10m", 0.0),
                dir = cur.optDouble("wind_direction_10m", 0.0),
                code = cur.optInt("weather_code", 0),
            )
        }
        return out
    }

    /** Frame radar hujan terbaru dari RainViewer. */
    suspend fun radar(): RadarData {
        val j = JSONObject(get("https://api.rainviewer.com/public/weather-maps.json"))
        val past = j.getJSONObject("radar").getJSONArray("past")
        val frames = List(past.length()) { i ->
            val o = past.getJSONObject(i)
            RadarFrame(o.getLong("time"), o.getString("path"))
        }
        return RadarData(j.getString("host"), frames)
    }

    suspend fun search(q: String): List<Place> {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            "${URLEncoder.encode(q, "UTF-8")}&count=6&language=id&format=json"
        val r = JSONObject(get(url)).optJSONArray("results") ?: return emptyList()
        return List(r.length()) { i ->
            val o = r.getJSONObject(i)
            Place(
                name = o.optString("name"),
                detail = listOf(o.optString("admin1"), o.optString("country"))
                    .filter { it.isNotBlank() }
                    .joinToString(", "),
                lat = o.getDouble("latitude"),
                lon = o.getDouble("longitude"),
            )
        }
    }

    /** Nama tempat dari koordinat; null jika gagal (mis. di tengah laut). */
    suspend fun reverseName(lat: Double, lon: Double): String? = try {
        val j = JSONObject(
            get(
                "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10" +
                    "&accept-language=id&lat=${f(lat)}&lon=${f(lon)}"
            )
        )
        val a = j.optJSONObject("address")
        val main = listOf("village", "town", "city", "municipality", "county", "state_district", "state")
            .firstNotNullOfOrNull { k -> a?.optString(k)?.takeIf { it.isNotBlank() } }
        val country = a?.optString("country").orEmpty()
        listOfNotNull(main, country.takeIf { it.isNotBlank() })
            .joinToString(", ")
            .ifBlank { null }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }
}
