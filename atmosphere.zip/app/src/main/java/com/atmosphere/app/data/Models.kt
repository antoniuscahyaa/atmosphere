package com.atmosphere.app.data

data class Place(val name: String, val detail: String, val lat: Double, val lon: Double)

/** Kondisi saat ini di lokasi (waktu lokal lokasi tersebut). */
data class Now(
    val date: String,
    val hour: Int,
    val temp: Double,
    val feels: Double,
    val humidity: Int,
    val code: Int,
    val isDay: Boolean,
    val rain: Double,
    val pressure: Double,
    val wind: Double,
    val windDir: Double,
    val gust: Double,
)

data class Hour(
    val date: String,
    val hour: Int,
    val temp: Double,
    val code: Int,
    val isDay: Boolean,
    val rainProb: Int,
    val rain: Double,
    val wind: Double,
    val windDir: Double,
    val gust: Double,
    val cape: Double,
    val uv: Double,
)

data class Day(
    val date: String,
    val max: Double,
    val min: Double,
    val sunrise: String,
    val sunset: String,
    val uvMax: Double,
)

data class Forecast(val now: Now, val days: List<Day>, val hours: List<Hour>)

/** Satu titik di grid angin pada peta. dir = arah ASAL angin (derajat), speed km/j. */
data class WindPoint(val lat: Double, val lon: Double, val speed: Double, val dir: Double, val code: Int)

data class RadarFrame(val time: Long, val path: String)
data class RadarData(val host: String, val frames: List<RadarFrame>)
