package com.atmosphere.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.atmosphere.app.BuildConfig
import com.atmosphere.app.data.AirQuality
import com.atmosphere.app.data.FireSpot
import com.atmosphere.app.data.Forecast
import com.atmosphere.app.data.Marine
import com.atmosphere.app.data.Quake
import com.atmosphere.app.data.WeatherAlert
import com.atmosphere.app.data.Place
import com.atmosphere.app.data.RadarData
import com.atmosphere.app.data.RadarFrame
import com.atmosphere.app.data.WeatherApi
import com.atmosphere.app.data.WindPoint
import com.atmosphere.app.map.HazardOverlay
import com.atmosphere.app.map.PinOverlay
import com.atmosphere.app.map.RadarLayer
import com.atmosphere.app.map.Tiles
import com.atmosphere.app.map.WindOverlay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.osmdroid.events.DelayedMapListener
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class Jobs {
    var wind: Job? = null
    var select: Job? = null
    var fire: Job? = null
}

@Composable
fun AtmosphereApp() {
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val density = LocalDensity.current
    val screenHdp = LocalConfiguration.current.screenHeightDp

    var map by remember { mutableStateOf<MapView?>(null) }
    var pin by remember { mutableStateOf<GeoPoint?>(null) }
    var forecast by remember { mutableStateOf<Forecast?>(null) }
    var placeName by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var air by remember { mutableStateOf<AirQuality?>(null) }
    var marine by remember { mutableStateOf<Marine?>(null) }

    var radarOn by remember { mutableStateOf(true) }
    var windOn by remember { mutableStateOf(true) }
    var stormOn by remember { mutableStateOf(true) }
    var radar by remember { mutableStateOf<RadarData?>(null) }
    var frameIdx by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var windPoints by remember { mutableStateOf<List<WindPoint>>(emptyList()) }

    var alertOn by remember { mutableStateOf(false) }
    var quakeOn by remember { mutableStateOf(false) }
    var fireOn by remember { mutableStateOf(false) }
    var alerts by remember { mutableStateOf<List<WeatherAlert>>(emptyList()) }
    var quakes by remember { mutableStateOf<List<Quake>>(emptyList()) }
    var fires by remember { mutableStateOf<List<FireSpot>>(emptyList()) }
    var notice by remember { mutableStateOf<String?>(null) }

    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Place>>(emptyList()) }

    val windOverlay = remember { WindOverlay() }
    val hazardOverlay = remember { HazardOverlay() }
    val pinOverlay = remember { PinOverlay() }
    val radarLayer = remember { RadarLayer() }
    val jobs = remember { Jobs() }

    // ---- aksi ----

    fun select(lat: Double, lon: Double, name: String?) {
        focus.clearFocus()
        val lonN = ((lon + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
        val p = GeoPoint(lat, lonN)
        pin = p
        pinOverlay.point = p
        map?.invalidate()
        loading = true
        error = null
        forecast = null
        air = null
        marine = null
        placeName = name ?: "Memuat lokasi…"
        jobs.select?.cancel()
        jobs.select = scope.launch {
            try {
                val f = async { WeatherApi.forecast(lat, lonN) }
                val n = if (name == null) async { WeatherApi.reverseName(lat, lonN) } else null
                // Kualitas udara & gelombang bersifat tambahan: gagal tidak menghalangi prakiraan.
                val a = async { WeatherApi.airQuality(lat, lonN) }
                val w = async { WeatherApi.marine(lat, lonN) }
                forecast = f.await()
                if (n != null) {
                    placeName = n.await() ?: "%.3f, %.3f".format(lat, lonN)
                }
                air = a.await()
                marine = w.await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Gagal memuat prakiraan. Periksa koneksi internet."
                if (name == null) placeName = "%.3f, %.3f".format(lat, lonN)
            } finally {
                loading = false
            }
        }
    }

    fun closeSheet() {
        jobs.select?.cancel()
        pin = null
        pinOverlay.point = null
        forecast = null
        air = null
        marine = null
        error = null
        loading = false
        map?.invalidate()
    }

    fun refreshWind(m: MapView) {
        if (!windOn && !stormOn) return
        if (m.width == 0 || m.height == 0) return
        jobs.wind?.cancel()
        jobs.wind = scope.launch {
            val bb = m.boundingBox
            runCatching { WeatherApi.windGrid(bb.latSouth, bb.latNorth, bb.lonWest, bb.lonEast, 4, 5) }
                .onSuccess { windPoints = it }
        }
    }

    fun refreshFires(m: MapView) {
        if (!fireOn || m.width == 0 || m.height == 0) return
        if (BuildConfig.FIRMS_MAP_KEY.isBlank()) return
        if (m.zoomLevelDouble < 5.0) {
            notice = "Zoom lebih dekat untuk melihat titik api"
            return
        }
        jobs.fire?.cancel()
        jobs.fire = scope.launch {
            val bb = m.boundingBox
            runCatching {
                WeatherApi.fires(BuildConfig.FIRMS_MAP_KEY, bb.latSouth, bb.latNorth, bb.lonWest, bb.lonEast)
            }.onSuccess {
                fires = it
                notice = if (it.isEmpty()) "Tidak ada titik api di area ini (24 jam terakhir)" else null
            }.onFailure {
                if (it is CancellationException) throw it
                notice = "Gagal memuat titik api (${it.message?.take(40) ?: "jaringan"})"
            }
        }
    }

    val tapReceiver = remember {
        object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                select(p.latitude, p.longitude, null)
                return true
            }

            override fun longPressHelper(p: GeoPoint): Boolean = false
        }
    }

    // ---- efek ----

    LaunchedEffect(query) {
        if (query.trim().length < 2) {
            results = emptyList()
        } else {
            delay(400)
            results = runCatching { WeatherApi.search(query.trim()) }.getOrDefault(emptyList())
        }
    }

    LaunchedEffect(map, windOn, stormOn) {
        val m = map ?: return@LaunchedEffect
        delay(400)
        refreshWind(m)
    }

    // Peringatan dini BMKG
    LaunchedEffect(alertOn) {
        while (alertOn) {
            runCatching { WeatherApi.alerts() }
                .onSuccess {
                    alerts = it
                    notice = if (it.isEmpty()) "Tidak ada peringatan dini BMKG aktif" else null
                }
                .onFailure { if (it is CancellationException) throw it; notice = "Gagal memuat peringatan BMKG" }
            delay(10 * 60_000L)
        }
    }

    // Gempa BMKG
    LaunchedEffect(quakeOn) {
        while (quakeOn) {
            runCatching { WeatherApi.quakes() }
                .onSuccess { quakes = it }
                .onFailure { if (it is CancellationException) throw it; notice = "Gagal memuat data gempa BMKG" }
            delay(5 * 60_000L)
        }
    }

    // Titik api FIRMS (butuh key)
    LaunchedEffect(map, fireOn) {
        val m = map ?: return@LaunchedEffect
        if (!fireOn) return@LaunchedEffect
        if (BuildConfig.FIRMS_MAP_KEY.isBlank()) {
            notice = "Key NASA FIRMS belum diisi (lihat README)"
            return@LaunchedEffect
        }
        delay(400)
        refreshFires(m)
    }

    LaunchedEffect(alerts, quakes, fires, alertOn, quakeOn, fireOn, map) {
        hazardOverlay.alerts = alerts
        hazardOverlay.quakes = quakes
        hazardOverlay.fires = fires
        hazardOverlay.showAlerts = alertOn
        hazardOverlay.showQuakes = quakeOn
        hazardOverlay.showFires = fireOn
        map?.invalidate()
    }

    LaunchedEffect(alertOn, quakeOn, fireOn) {
        if (!alertOn && !quakeOn && !fireOn) notice = null
    }

    LaunchedEffect(windPoints, windOn, stormOn, map) {
        windOverlay.points = windPoints
        windOverlay.showWind = windOn
        windOverlay.showStorm = stormOn
        map?.invalidate()
    }

    // Ambil frame radar & segarkan tiap 5 menit selama radar aktif
    LaunchedEffect(radarOn) {
        while (radarOn) {
            runCatching { WeatherApi.radar() }.onSuccess { r ->
                radar = r
                if (!playing || frameIdx >= r.frames.size) frameIdx = r.frames.lastIndex.coerceAtLeast(0)
            }
            delay(5 * 60_000L)
        }
    }

    // Animasi radar
    LaunchedEffect(playing, radar) {
        val n = radar?.frames?.size ?: 0
        while (playing && n > 1) {
            delay(900)
            frameIdx = (frameIdx + 1) % n
        }
    }

    // Tampilkan frame radar di peta
    LaunchedEffect(map, radarOn, radar, frameIdx) {
        val m = map ?: return@LaunchedEffect
        val r = radar
        val fr = r?.frames?.getOrNull(frameIdx)
        if (!radarOn || r == null || fr == null) radarLayer.clear(m) else radarLayer.show(m, r.host, fr.path)
    }

    // Geser pusat peta supaya pin tidak tertutup panel prakiraan
    LaunchedEffect(map, pin != null) {
        val offset = if (pin != null) with(density) { (screenHdp * 0.26f).dp.roundToPx() } else 0
        map?.setMapCenterOffset(0, -offset)
    }
    LaunchedEffect(map, pin) {
        pin?.let { map?.controller?.animateTo(it) }
    }

    DisposableEffect(lifecycleOwner, map) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> map?.onResume()
                Lifecycle.Event.ON_PAUSE -> map?.onPause()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // ---- UI ----

    val frames = radar?.frames.orEmpty()

    Box(Modifier.fillMaxSize().background(C.Bg)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(Tiles.voyager)
                    setMultiTouchControls(true)
                    zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
                    minZoomLevel = 3.0
                    maxZoomLevel = 13.0
                    isTilesScaledToDpi = true
                    controller.setZoom(7.0)
                    controller.setCenter(GeoPoint(-6.2, 106.85)) // Jakarta
                    overlays.add(hazardOverlay)
                    overlays.add(windOverlay)
                    overlays.add(pinOverlay)
                    overlays.add(MapEventsOverlay(tapReceiver))
                    addMapListener(
                        DelayedMapListener(
                            object : MapListener {
                                override fun onScroll(event: ScrollEvent?): Boolean {
                                    refreshWind(this@apply)
                                    refreshFires(this@apply)
                                    return false
                                }

                                override fun onZoom(event: ZoomEvent?): Boolean {
                                    refreshWind(this@apply)
                                    refreshFires(this@apply)
                                    return false
                                }
                            },
                            800,
                        )
                    )
                    post { map = this }
                }
            },
            onRelease = { it.onDetach() },
        )

        // Pencarian, lapisan, kontrol radar
        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            SearchBar(
                query = query,
                onQuery = { query = it },
                results = results,
                onPick = { p ->
                    query = ""
                    results = emptyList()
                    map?.controller?.setZoom(9.0)
                    select(p.lat, p.lon, p.name)
                },
            )
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                LayerChip("Radar", radarOn, C.Blue, { radarOn = !radarOn; if (!radarOn) playing = false }) {
                    WeatherIcon(61, true, 20.dp)
                }
                LayerChip("Angin", windOn, C.Teal, { windOn = !windOn }) { fg -> WindGlyph(fg, 18.dp) }
                LayerChip("Badai", stormOn, C.Purple, { stormOn = !stormOn }) { fg ->
                    BoltGlyph(if (stormOn) Color.White else C.Purple, 18.dp)
                }
                LayerChip("Peringatan", alertOn, C.Gold, { alertOn = !alertOn }) { fg -> AlertGlyph(fg, 18.dp) }
                LayerChip("Gempa", quakeOn, C.Pink, { quakeOn = !quakeOn }) { fg -> QuakeGlyph(fg, 18.dp) }
                LayerChip("Api", fireOn, C.Orange, { fireOn = !fireOn }) { fg -> FlameGlyph(fg, 18.dp) }
            }
            notice?.let {
                Spacer(Modifier.height(8.dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) { Txt(it, 12, C.Muted) }
            }
            if (radarOn && frames.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                RadarBar(frames, frameIdx.coerceIn(0, frames.lastIndex), playing) { playing = !playing }
            }
        }

        // Atribusi saat panel tertutup
        if (pin == null) {
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .navigationBarsPadding()
                    .padding(8.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White.copy(alpha = 0.85f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Txt("© OpenStreetMap · CARTO · Open-Meteo · RainViewer", 9, C.Muted)
            }
        }

        // Panel prakiraan per jam
        AnimatedVisibility(
            visible = pin != null,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            val p = pin
            ForecastSheet(
                place = placeName,
                lat = p?.latitude ?: 0.0,
                lon = p?.longitude ?: 0.0,
                forecast = forecast,
                air = air,
                marine = marine,
                loading = loading,
                error = error,
                onClose = { closeSheet() },
                onRetry = { p?.let { select(it.latitude, it.longitude, if (placeName.contains("…")) null else placeName) } },
            )
        }
    }
}

@Composable
private fun SearchBar(
    query: String,
    onQuery: (String) -> Unit,
    results: List<Place>,
    onPick: (Place) -> Unit,
) {
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .height(50.dp)
                .clip(RoundedCornerShape(25.dp))
                .background(Color.White)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SearchGlyph(C.Blue, 20.dp)
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) Txt("Cari kota atau tempat", 15, C.Muted)
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = C.Ink, fontSize = 15.sp),
                    cursorBrush = SolidColor(C.Blue),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(C.Chip)
                        .clickable { onQuery("") },
                    contentAlignment = Alignment.Center,
                ) { CloseGlyph(C.Muted, 11.dp) }
            }
        }
        if (results.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
            ) {
                results.forEach { p ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(p) }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Txt(p.name, 15, bold = true, maxLines = 1)
                        if (p.detail.isNotBlank()) Txt(p.detail, 12, C.Muted, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun LayerChip(
    label: String,
    active: Boolean,
    color: Color,
    onClick: () -> Unit,
    icon: @Composable (Color) -> Unit,
) {
    val fg = if (active) Color.White else C.Ink
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (active) color else Color.White)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon(fg)
        Spacer(Modifier.width(6.dp))
        Txt(label, 13, fg, bold = true)
    }
}

@Composable
private fun RadarBar(frames: List<RadarFrame>, idx: Int, playing: Boolean, onToggle: () -> Unit) {
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.US) }
    val f = frames.getOrNull(idx)
    Row(
        Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White)
            .padding(start = 6.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(C.Blue)
                .clickable(onClick = onToggle),
            contentAlignment = Alignment.Center,
        ) {
            if (playing) PauseGlyph(Color.White, 14.dp) else PlayGlyph(Color.White, 14.dp)
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Txt("Radar hujan", 11, C.Muted)
            val time = if (f != null) fmt.format(Date(f.time * 1000)) else "--:--"
            Txt(time + if (idx == frames.lastIndex) " · terbaru" else "", 14, bold = true)
        }
        Spacer(Modifier.width(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
            frames.forEachIndexed { i, _ ->
                Box(
                    Modifier
                        .size(width = 5.dp, height = if (i == idx) 14.dp else 8.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (i == idx) C.Blue else C.Chip)
                )
            }
        }
    }
}
