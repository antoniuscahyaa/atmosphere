package com.atmosphere.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import kotlin.math.cos
import kotlin.math.sin

enum class Sky { Clear, PartlyCloudy, Cloudy, Fog, Drizzle, Rain, HeavyRain, Snow, Thunder }

fun skyOf(code: Int): Sky = when (code) {
    0, 1 -> Sky.Clear
    2 -> Sky.PartlyCloudy
    3 -> Sky.Cloudy
    45, 48 -> Sky.Fog
    51, 53, 55, 56, 57 -> Sky.Drizzle
    61, 63, 80 -> Sky.Rain
    65, 66, 67, 81, 82 -> Sky.HeavyRain
    71, 73, 75, 77, 85, 86 -> Sky.Snow
    95, 96, 99 -> Sky.Thunder
    else -> Sky.Cloudy
}

/** Deskripsi kode cuaca WMO dalam Bahasa Indonesia. */
fun describe(code: Int): String = when (code) {
    0 -> "Cerah"
    1 -> "Cerah berawan"
    2 -> "Berawan sebagian"
    3 -> "Mendung"
    45, 48 -> "Berkabut"
    51, 53, 55 -> "Gerimis"
    56, 57 -> "Gerimis beku"
    61 -> "Hujan ringan"
    63 -> "Hujan sedang"
    65 -> "Hujan lebat"
    66, 67 -> "Hujan beku"
    71, 73, 75 -> "Salju"
    77 -> "Butiran salju"
    80 -> "Hujan lokal ringan"
    81 -> "Hujan lokal sedang"
    82 -> "Hujan lokal lebat"
    85, 86 -> "Hujan salju"
    95 -> "Badai petir"
    96, 99 -> "Badai petir & es"
    else -> "Berawan"
}

/** Arah ASAL angin dalam singkatan Indonesia. */
fun compass(deg: Double): String {
    val names = listOf("U", "TL", "T", "TG", "S", "BD", "B", "BL")
    val i = (((deg + 22.5) % 360 + 360) % 360 / 45).toInt() % 8
    return names[i]
}

private val SunBody = Color(0xFFFFB703)
private val SunRay = Color(0xFFFFC933)
private val MoonBody = Color(0xFFFFC857)
private val Star = Color(0xFFFFD166)
private val LightBody = Color(0xFFD9E6F8)
private val LightShade = Color(0xFFB4C9E6)
private val RainBody = Color(0xFF9DB4D8)
private val RainShade = Color(0xFF7C95BE)
private val StormBody = Color(0xFF7D8FB5)
private val StormShade = Color(0xFF677BA5)
private val DropBlue = Color(0xFF2D9CFF)
private val DropDeep = Color(0xFF1E6FE8)
private val DropLight = Color(0xFF6CBAFF)
private val SnowDot = Color(0xFF7FD6FF)
private val BoltYellow = Color(0xFFFFC400)
private val FogLine = Color(0xFFA7B7CF)

@Composable
fun WeatherIcon(code: Int, isDay: Boolean, sz: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(sz)) { drawWeather(skyOf(code), isDay) }
}

private fun DrawScope.drawWeather(sky: Sky, day: Boolean) {
    val s = size.minDimension
    when (sky) {
        Sky.Clear ->
            if (day) sun(Offset(s * .5f, s * .5f), s * .22f)
            else moon(Offset(s * .5f, s * .5f), s * .27f)

        Sky.PartlyCloudy -> {
            if (day) sun(Offset(s * .36f, s * .36f), s * .16f)
            else moon(Offset(s * .38f, s * .38f), s * .2f)
            cloud(s * .14f, s * .34f, s * .78f, LightBody, LightShade)
        }

        Sky.Cloudy -> {
            cloud(s * .3f, s * .1f, s * .6f, Color(0xFFE6EEFA), Color(0xFFC9D8EE))
            cloud(s * .06f, s * .28f, s * .82f, Color(0xFFB8CBE8), Color(0xFF93AACF))
        }

        Sky.Fog -> {
            cloud(s * .12f, s * .08f, s * .76f, LightBody, LightShade)
            fogLine(s, .66f, .18f, .82f)
            fogLine(s, .78f, .28f, .72f)
            fogLine(s, .90f, .2f, .6f)
        }

        Sky.Drizzle -> {
            cloud(s * .1f, s * .1f, s * .8f, RainBody, RainShade)
            drops(s, listOf(.32f, .5f, .68f), .68f, .12f, DropLight)
        }

        Sky.Rain -> {
            cloud(s * .1f, s * .1f, s * .8f, RainBody, RainShade)
            drops(s, listOf(.32f, .5f, .68f), .66f, .2f, DropBlue)
        }

        Sky.HeavyRain -> {
            cloud(s * .1f, s * .08f, s * .8f, StormBody, StormShade)
            drops(s, listOf(.26f, .42f, .58f, .74f), .64f, .26f, DropDeep)
        }

        Sky.Snow -> {
            cloud(s * .1f, s * .1f, s * .8f, RainBody, RainShade)
            for ((x, y) in listOf(.3f to .72f, .5f to .84f, .7f to .72f, .4f to .93f, .6f to .93f)) {
                drawCircle(SnowDot, s * .045f, Offset(s * x, s * y))
            }
        }

        Sky.Thunder -> {
            cloud(s * .1f, s * .08f, s * .8f, StormBody, StormShade)
            bolt(s * .5f, s * .78f, s * .4f, BoltYellow)
            drops(s, listOf(.28f, .74f), .66f, .16f, DropBlue)
        }
    }
}

private fun DrawScope.sun(c: Offset, r: Float) {
    for (i in 0 until 8) {
        val a = Math.toRadians(i * 45.0)
        val ca = cos(a).toFloat()
        val sa = sin(a).toFloat()
        drawLine(
            SunRay,
            Offset(c.x + ca * r * 1.4f, c.y + sa * r * 1.4f),
            Offset(c.x + ca * r * 1.8f, c.y + sa * r * 1.8f),
            strokeWidth = r * 0.3f,
            cap = StrokeCap.Round,
        )
    }
    drawCircle(SunBody, r, c)
}

private fun DrawScope.moon(c: Offset, r: Float) {
    val a = Path().apply { addOval(Rect(c, r)) }
    val b = Path().apply { addOval(Rect(Offset(c.x + r * 0.5f, c.y - r * 0.3f), r * 0.85f)) }
    drawPath(Path.combine(PathOperation.Difference, a, b), MoonBody)
    val s = size.minDimension
    drawCircle(Star, s * .03f, Offset(s * .74f, s * .26f))
    drawCircle(Star, s * .022f, Offset(s * .84f, s * .44f))
}

private fun DrawScope.cloud(x: Float, y: Float, w: Float, body: Color, shade: Color) {
    fun shape(color: Color, dy: Float) {
        drawCircle(color, w * 0.2f, Offset(x + w * 0.27f, y + w * 0.40f + dy))
        drawCircle(color, w * 0.27f, Offset(x + w * 0.5f, y + w * 0.27f + dy))
        drawCircle(color, w * 0.21f, Offset(x + w * 0.75f, y + w * 0.39f + dy))
        drawRoundRect(
            color,
            Offset(x + w * 0.07f, y + w * 0.35f + dy),
            Size(w * 0.89f, w * 0.25f),
            CornerRadius(w * 0.125f),
        )
    }
    shape(shade, w * 0.04f)
    shape(body, 0f)
}

private fun DrawScope.drops(s: Float, xs: List<Float>, y: Float, len: Float, color: Color) {
    xs.forEach { x ->
        drawLine(
            color,
            Offset(s * x, s * y),
            Offset(s * x - s * 0.05f, s * (y + len)),
            strokeWidth = s * 0.075f,
            cap = StrokeCap.Round,
        )
    }
}

private fun DrawScope.fogLine(s: Float, y: Float, x1: Float, x2: Float) {
    drawLine(FogLine, Offset(s * x1, s * y), Offset(s * x2, s * y), strokeWidth = s * 0.075f, cap = StrokeCap.Round)
}

internal fun DrawScope.bolt(cx: Float, cy: Float, h: Float, color: Color) {
    val p = Path().apply {
        moveTo(cx + 0.12f * h, cy - 0.5f * h)
        lineTo(cx - 0.28f * h, cy + 0.04f * h)
        lineTo(cx - 0.02f * h, cy + 0.04f * h)
        lineTo(cx - 0.14f * h, cy + 0.5f * h)
        lineTo(cx + 0.28f * h, cy - 0.08f * h)
        lineTo(cx + 0.02f * h, cy - 0.08f * h)
        close()
    }
    drawPath(p, color)
}
