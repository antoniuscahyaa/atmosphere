package com.atmosphere.app.map

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.graphics.Typeface
import com.atmosphere.app.data.FireSpot
import com.atmosphere.app.data.Quake
import com.atmosphere.app.data.WeatherAlert
import com.atmosphere.app.data.WindPoint
import org.osmdroid.tileprovider.MapTileProviderBasic
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.TilesOverlay

object Tiles {
    /** Basemap CARTO Voyager (OSM): flat, bersih, berwarna lembut. */
    val voyager = XYTileSource(
        "CartoVoyager", 0, 19, 256, ".png",
        arrayOf(
            "https://a.basemaps.cartocdn.com/rastertiles/voyager/",
            "https://b.basemaps.cartocdn.com/rastertiles/voyager/",
            "https://c.basemaps.cartocdn.com/rastertiles/voyager/",
        ),
        "© OpenStreetMap contributors © CARTO",
    )
}

/**
 * Tile radar RainViewer. Tier gratis dibatasi zoom maksimum 7 (osmdroid akan
 * memperbesar tile saat peta di-zoom lebih dekat).
 * Skema warna 2 = "Universal Blue". Ubah RADAR_COLOR jika tile kosong.
 */
class RadarTileSource(private val host: String, private val path: String) :
    OnlineTileSourceBase("rv" + path.substringAfterLast('/'), 0, 7, 256, ".png", arrayOf(host)) {

    override fun getTileURLString(pMapTileIndex: Long): String {
        val z = MapTileIndex.getZoom(pMapTileIndex)
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        return "$host$path/256/$z/$x/$y/$RADAR_COLOR/1_1.png"
    }

    companion object {
        const val RADAR_COLOR = 2
    }
}

/** Mengelola satu overlay radar yang diganti tiap frame (animasi). */
class RadarLayer {
    private var overlay: TilesOverlay? = null
    private var shownPath: String? = null

    fun show(map: MapView, host: String, path: String) {
        if (shownPath == path && overlay != null) return
        detach(map)
        val ctx = map.context
        val provider = MapTileProviderBasic(ctx, RadarTileSource(host, path))
        val o = TilesOverlay(provider, ctx)
        o.loadingBackgroundColor = Color.TRANSPARENT
        o.loadingLineColor = Color.TRANSPARENT
        o.setColorFilter(ColorMatrixColorFilter(ColorMatrix().apply { setScale(1f, 1f, 1f, 0.8f) }))
        map.overlays.add(0, o)
        overlay = o
        shownPath = path
        map.invalidate()
        map.postDelayed({ map.invalidate() }, 700)
        map.postDelayed({ map.invalidate() }, 2000)
    }

    fun clear(map: MapView) {
        detach(map)
        map.invalidate()
    }

    private fun detach(map: MapView) {
        overlay?.let {
            map.overlays.remove(it)
            it.onDetach(map)
        }
        overlay = null
        shownPath = null
    }
}

fun windColor(kmh: Double): Int = when {
    kmh < 8 -> 0xFF4CC9F0
    kmh < 20 -> 0xFF2EC4B6
    kmh < 35 -> 0xFFFFB703
    kmh < 50 -> 0xFFFB5607
    else -> 0xFFE63946
}.toInt()

/** Panah arah angin (berwarna menurut kecepatan) + penanda badai petir. */
class WindOverlay : Overlay() {
    var points: List<WindPoint> = emptyList()
    var showWind = true
    var showStorm = true

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val path = Path()
    private val pt = Point()

    override fun draw(c: Canvas, map: MapView, shadow: Boolean) {
        if (shadow || points.isEmpty() || (!showWind && !showStorm)) return
        val d = map.resources.displayMetrics.density
        val pj = map.projection
        for (p in points) {
            pj.toPixels(GeoPoint(p.lat, p.lon), pt)
            if (pt.x < -60 * d || pt.y < -60 * d || pt.x > map.width + 60 * d || pt.y > map.height + 60 * d) continue
            if (showWind) drawWind(c, pt.x.toFloat(), pt.y.toFloat(), d, p)
            if (showStorm && p.code >= 95) {
                val off = if (showWind) 20f * d else 0f
                drawStorm(c, pt.x + off, pt.y - off, d)
            }
        }
    }

    private fun drawWind(c: Canvas, x: Float, y: Float, d: Float, p: WindPoint) {
        val r = 17f * d
        val col = windColor(p.speed)
        fill.style = Paint.Style.FILL
        fill.color = col
        c.drawCircle(x, y, r, fill)

        c.save()
        c.translate(x, y)
        // dir = arah asal angin -> panah menunjuk ke arah angin bertiup
        c.rotate((p.dir + 180.0).toFloat())
        stroke.strokeWidth = 2.4f * d
        c.drawLine(0f, r * 0.5f, 0f, -r * 0.4f, stroke)
        path.reset()
        path.moveTo(0f, -r * 0.7f)
        path.lineTo(-r * 0.4f, -r * 0.15f)
        path.lineTo(r * 0.4f, -r * 0.15f)
        path.close()
        fill.color = Color.WHITE
        c.drawPath(path, fill)
        c.restore()

        val label = p.speed.toInt().toString()
        text.textSize = 11f * d
        text.style = Paint.Style.STROKE
        text.strokeWidth = 3f * d
        text.color = Color.WHITE
        c.drawText(label, x, y + r + 13f * d, text)
        text.style = Paint.Style.FILL
        text.color = 0xFF14213D.toInt()
        c.drawText(label, x, y + r + 13f * d, text)
    }

    private fun drawStorm(c: Canvas, x: Float, y: Float, d: Float) {
        val r = 12f * d
        fill.style = Paint.Style.FILL
        fill.color = 0xFF8338EC.toInt()
        c.drawCircle(x, y, r, fill)
        val s = r * 0.7f
        path.reset()
        path.moveTo(x + 0.12f * s * 2, y - 0.5f * s * 2)
        path.lineTo(x - 0.28f * s * 2, y + 0.04f * s * 2)
        path.lineTo(x - 0.02f * s * 2, y + 0.04f * s * 2)
        path.lineTo(x - 0.14f * s * 2, y + 0.5f * s * 2)
        path.lineTo(x + 0.28f * s * 2, y - 0.08f * s * 2)
        path.lineTo(x + 0.02f * s * 2, y - 0.08f * s * 2)
        path.close()
        fill.color = 0xFFFFC400.toInt()
        c.drawPath(path, fill)
    }
}

/** Pin lokasi yang dipilih (ujung pin tepat di titik yang disentuh). */
class PinOverlay : Overlay() {
    var point: GeoPoint? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val pt = Point()

    override fun draw(c: Canvas, map: MapView, shadow: Boolean) {
        val p = point ?: return
        if (shadow) return
        val d = map.resources.displayMetrics.density
        map.projection.toPixels(p, pt)
        val x = pt.x.toFloat()
        val y = pt.y.toFloat()
        val r = 13f * d
        val cy = y - r * 2.1f

        fill.style = Paint.Style.FILL
        fill.color = 0xFFFF006E.toInt()
        path.reset()
        path.moveTo(x, y)
        path.lineTo(x - r * 0.85f, cy + r * 0.5f)
        path.lineTo(x + r * 0.85f, cy + r * 0.5f)
        path.close()
        c.drawPath(path, fill)
        c.drawCircle(x, cy, r, fill)
        fill.color = Color.WHITE
        c.drawCircle(x, cy, r * 0.42f, fill)
    }
}

/** Warna gempa menurut magnitudo. */
fun quakeColor(mag: Double): Int = when {
    mag < 4.0 -> 0xFFFFB703
    mag < 5.0 -> 0xFFFB5607
    mag < 6.0 -> 0xFFE63946
    else -> 0xFF9D0208
}.toInt()

/** Poligon peringatan dini BMKG, titik api FIRMS, dan lingkaran gempa. Digambar di bawah angin/pin. */
class HazardOverlay : Overlay() {
    var alerts: List<WeatherAlert> = emptyList()
    var fires: List<FireSpot> = emptyList()
    var quakes: List<Quake> = emptyList()
    var showAlerts = false
    var showFires = false
    var showQuakes = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val path = Path()
    private val pt = Point()

    override fun draw(c: Canvas, map: MapView, shadow: Boolean) {
        if (shadow) return
        val d = map.resources.displayMetrics.density
        val pj = map.projection
        if (showAlerts) for (a in alerts) drawAlert(c, pj, a, d)
        if (showFires) for (f in fires) {
            pj.toPixels(GeoPoint(f.lat, f.lon), pt)
            if (pt.x < -20 * d || pt.y < -20 * d || pt.x > map.width + 20 * d || pt.y > map.height + 20 * d) continue
            fill.style = Paint.Style.FILL
            fill.color = Color.WHITE
            c.drawCircle(pt.x.toFloat(), pt.y.toFloat(), 5.5f * d, fill)
            fill.color = if (f.high) 0xFFE63946.toInt() else 0xFFFB5607.toInt()
            c.drawCircle(pt.x.toFloat(), pt.y.toFloat(), 4f * d, fill)
        }
        if (showQuakes) for (q in quakes) {
            pj.toPixels(GeoPoint(q.lat, q.lon), pt)
            if (pt.x < -40 * d || pt.y < -40 * d || pt.x > map.width + 40 * d || pt.y > map.height + 40 * d) continue
            val r = (9f + (q.mag - 3.0).coerceIn(0.0, 5.0).toFloat() * 3f) * d
            val x = pt.x.toFloat()
            val y = pt.y.toFloat()
            val col = quakeColor(q.mag)
            fill.style = Paint.Style.FILL
            fill.color = (col and 0x00FFFFFF) or 0x44000000
            c.drawCircle(x, y, r * 1.7f, fill)
            fill.color = col
            c.drawCircle(x, y, r, fill)
            line.color = Color.WHITE
            line.strokeWidth = 2f * d
            c.drawCircle(x, y, r, line)
            text.color = Color.WHITE
            text.textSize = 10.5f * d
            c.drawText("%.1f".format(q.mag), x, y + 3.6f * d, text)
        }
    }

    private fun drawAlert(c: Canvas, pj: org.osmdroid.views.Projection, a: WeatherAlert, d: Float) {
        val col = when (a.severity.lowercase()) {
            "extreme", "severe" -> 0xFFE63946
            "moderate" -> 0xFFFB5607
            else -> 0xFFFFB703
        }.toInt()
        for (poly in a.polygons) {
            path.reset()
            poly.forEachIndexed { i, (la, lo) ->
                pj.toPixels(GeoPoint(la, lo), pt)
                if (i == 0) path.moveTo(pt.x.toFloat(), pt.y.toFloat()) else path.lineTo(pt.x.toFloat(), pt.y.toFloat())
            }
            path.close()
            fill.style = Paint.Style.FILL
            fill.color = (col and 0x00FFFFFF) or 0x40000000
            c.drawPath(path, fill)
            line.color = col
            line.strokeWidth = 2f * d
            c.drawPath(path, line)
        }
    }
}
