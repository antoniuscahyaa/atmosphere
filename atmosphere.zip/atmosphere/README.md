# Atmosphere

Aplikasi cuaca native Android (Kotlin + Jetpack Compose) dengan peta live.
Package: `com.atmosphere.app` · Min Android 8 (API 26) · Target API 34 → jalan di Android 10.

## Fitur

- **Tampilan bergaya DialChat**: header biru berujung membulat dengan tombol "kaca", kartu abu muda, palet kalem, navigasi bawah (Beranda · Peta · Pengaturan), **mode terang/gelap** (Sistem/Terang/Gelap di Pengaturan; peta ikut gelap)
- **Lokasi favorit**: sampai 4 kartu di Beranda (di bawah header). Sentuh kartu untuk membuka panel prakiraan lengkap, termasuk perbandingan antar sumber
- **Pengaturan**: tema, **bahasa (Sistem / Indonesia / English)**, nama pengguna, izin lokasi, daftar sumber data
- **Beranda** (layar pertama): sapaan sesuai jam + nama pengguna (diisi sekali, bisa diubah dengan menyentuh nama), cuaca di lokasi saat ini, kartu **kecocokan sumber prakiraan**, peringatan dini BMKG di area Anda (hanya muncul jika ada), grafik hujan 12 jam, ringkasan (angin, UV, AQI, matahari, gelombang), saran otomatis berbasis aturan, gempa BMKG terdekat (≤ 300 km), dan pintasan ke Peta / Radar / Detail prakiraan
- **Prakiraan multi-sumber**: Open-Meteo dibandingkan dengan MET Norway, ECMWF, DWD ICON, dan NOAA GFS. Contoh hasil: "3 dari 5 sumber memprediksi hujan sekitar 15:00". Sentuh kartu untuk tabel per sumber. Tampil di beranda dan di panel prakiraan peta
- Peta yang bisa digeser dan di-zoom (OpenStreetMap, basemap OSM standar)
- Lapisan **Radar** hujan live + animasi 2 jam terakhir (RainViewer)
- Lapisan **Angin**: panah arah angin berwarna menurut kecepatan, mengikuti area peta yang terlihat
- Lapisan **Badai**: penanda petir di titik grid yang sedang badai petir
- Sentuh peta → pin lokasi + panel **prakiraan per jam** (Hari ini / Besok): ikon, suhu, peluang hujan, angin; peringatan potensi badai petir dari kode cuaca + CAPE
- Lapisan **Peringatan**: poligon peringatan dini cuaca BMKG (CAP), warna menurut tingkat keparahan
- Lapisan **Gempa**: gempa terbaru BMKG (M5+ dan gempa terbaru), lingkaran berwarna menurut magnitudo
- Lapisan **Api**: titik panas 24 jam terakhir (NASA FIRMS, VIIRS), perlu zoom ≥ 5 dan key gratis
- Panel prakiraan juga menampilkan **kualitas udara** (AQI AS, PM2.5/PM10) dan **tinggi gelombang** (hanya di laut)
- Tombol **lokasi saya** (kanan bawah): meminta izin lokasi, menampilkan titik biru, lalu langsung membuka prakiraan di posisi itu
- Pencarian kota
- UI flat, minimalis, ikon cuaca digambar sendiri (Canvas), tanpa file gambar

## Cara menjalankan

1. Install Android Studio (Koala 2024.1 atau lebih baru).
2. `File > Open` → pilih folder `atmosphere` ini, tunggu Gradle sync selesai.
3. Colok HP (aktifkan Opsi Pengembang + USB debugging) → tekan **Run**.
4. Untuk APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

## Mengisi API key NASA FIRMS (lapisan "Api")

Hanya lapisan Api yang butuh key. Daftar gratis di https://firms.modaps.eosdis.nasa.gov/api/map_key/ (key dikirim ke email), lalu:

- **Lokal**: tambah baris ini di `local.properties` (file ini otomatis di-ignore git):
  ```
  FIRMS_MAP_KEY=kunci_anda
  ```
- **CI / GitHub Actions**: buat secret `FIRMS_MAP_KEY` dan teruskan sebagai environment variable pada langkah build.

Tanpa key, app tetap jalan; chip Api hanya menampilkan pesan "Key NASA FIRMS belum diisi". Key tertanam di APK, jadi pakai key khusus app ini.

## API gratis yang dipakai (tanpa API key kecuali FIRMS)

| Data | Sumber | Catatan |
|---|---|---|
| Prakiraan, angin, CAPE, pencarian kota | Open-Meteo | Gratis untuk non-komersial |
| Prakiraan pembanding | Open-Meteo (model ECMWF, DWD ICON, NOAA GFS) + MET Norway (`api.met.no`) | Tanpa key. MET Norway: lisensi CC BY 4.0, wajib atribusi dan User-Agent yang jelas |
| Radar hujan | RainViewer | Tier gratis: zoom tile maks 7, hanya data lampau (tanpa nowcast), wajib atribusi |
| Nama lokasi dari koordinat | Nominatim (OSM, zoom 14) | Hasil: "Kelurahan/desa, Kota/Kabupaten". Maks ~1 request/detik, cukup untuk pemakaian pribadi |
| Basemap | OpenStreetMap (tile.openstreetmap.org) | Atribusi tampil; untuk pemakaian ramai pertimbangkan penyedia tile sendiri |
| Kualitas udara | Open-Meteo Air Quality | AQI AS, PM2.5, PM10 |
| Gelombang laut | Open-Meteo Marine | Kosong untuk lokasi daratan |
| Gempa | BMKG Data Terbuka (`data.bmkg.go.id`) | `gempaterkini.json`, `autogempa.json`; cantumkan BMKG sebagai sumber |
| Peringatan dini cuaca | BMKG (`bmkg.go.id/alerts/nowcast/id`, CAP) | Gagal satu CAP tidak menggagalkan yang lain |
| Titik api | NASA FIRMS (butuh `FIRMS_MAP_KEY`) | VIIRS S-NPP NRT, 1 hari, maks 800 titik |

Grid angin memakai 40 titik per pembaruan (diminta 0,8 detik setelah peta berhenti digeser).

## Lokasi favorit

- **Beranda**: kartu mini 2×2 berisi ikon, label, jam hujan pertama (atau kondisi cuaca jika tidak hujan), dan suhu. Kartu biru = hujan sudah/akan mulai dalam sekitar 2 jam. Tinggi kartu mengikuti isi (tidak terpotong); nama tempat lengkap ada di panel detail. Slot kosong tampil sebagai "+ Tambah lokasi". Link "Edit/Atur" membuka layar pengaturan.
- **Atur** (Beranda > Atur, atau Pengaturan > Lokasi favorit): ubah nama, hapus, urutkan dengan ▲ ▼, dan tambah lewat tiga cara: *Cari kota*, *Pilih di peta*, atau *Lokasi saya*.
- **Pilih di peta**: buka tab Peta, sentuh titik mana saja, lalu tekan **Simpan ke favorit** di panel prakiraan.
- **Detail**: menyentuh kartu membuka panel prakiraan yang sama dengan di Peta (per jam, kartu perbandingan sumber, UV, AQI, dst.) plus tombol *Buka di Peta* dan *Radar*.
- Data tersimpan lokal (SharedPreferences, JSON) lewat `data/Favorites.kt` dan `UserPrefs`; UI di `ui/FavoritesUi.kt`. Kartu memuat satu request prakiraan per favorit saat Beranda tampil atau dimuat ulang.

## Bahasa

Pilih di **Pengaturan > Tampilan > Bahasa**: Sistem (default, mengikuti bahasa HP; selain Indonesia jatuh ke English), Indonesia, atau English. Berubah langsung tanpa restart dan tersimpan di perangkat.

- Semua teks memakai `tr("Indonesia", "English")` dari `data/Lang.kt`. Pembacaan `Lang.mode` membuat layar tergambar ulang otomatis.
- Pencarian kota (Open-Meteo) dan nama lokasi (Nominatim) ikut meminta bahasa yang dipilih; kode WMO, arah angin (U/TL/… menjadi N/NE/…), satuan (km/j menjadi km/h), dan format tanggal juga menyesuaikan.
- Teks dari BMKG (wilayah gempa, isi peringatan dini) tetap Bahasa Indonesia karena datang langsung dari sumbernya.
- Menambah bahasa ketiga: tambah nilai di `Lang.mode`/`Lang.code`, lalu ubah `tr()` agar menerima teks tambahan (atau pindahkan ke `strings.xml` jika bahasanya banyak).

## Struktur

```
app/src/main/java/com/atmosphere/app/
├─ MainActivity.kt
├─ data/   Models.kt, WeatherApi.kt      ← semua panggilan API
│          Compare.kt                    ← logika perbandingan antar sumber
│          UserPrefs.kt                  ← nama pengguna, tema, bahasa, lokasi terakhir, util geo
│          Lang.kt                       ← pilihan bahasa + fungsi tr()
│          Favorites.kt                  ← daftar favorit (maks 4) + ringkasan cuaca kartu
├─ map/    MapLayers.kt                  ← radar, panah angin, penanda badai, pin, gempa/api/peringatan
└─ ui/     Nav.kt (tab + navigasi bawah), HomeScreen.kt, FavoritesUi.kt (kartu, detail, layar Atur), SettingsScreen.kt, Chrome.kt (header biru, nav bawah),
           CompareCard.kt, Advice.kt,
           AtmosphereApp.kt, ForecastSheet.kt, WeatherIcons.kt, Glyphs.kt, Theme.kt
```

## Penyesuaian

- Warna radar kosong/aneh → ubah `RADAR_COLOR` di `RadarTileSource` (MapLayers.kt).
- Kepadatan grid angin → parameter `5, 8` (kolom, baris) di `refreshWind` (AtmosphereApp.kt).
- Palet warna (terang & gelap) → objek `C` di Theme.kt. `C.Brand` = biru header/tombol, `C.Blue` = biru aksen untuk teks.

## Belum ada

Notifikasi peringatan, ketuk gempa/peringatan untuk detail, dan jalur siklon tropis (data siklon gratis perlu sumber lain, mis. GDACS/NOAA).
