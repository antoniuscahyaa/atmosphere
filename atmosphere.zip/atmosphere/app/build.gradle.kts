import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Key NASA FIRMS (gratis, untuk lapisan "Api"). Urutan: env FIRMS_MAP_KEY (CI/GitHub Secrets)
// lalu FIRMS_MAP_KEY di local.properties. Kosong = lapisan Api menampilkan pesan, app tetap jalan.
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val firmsKey: String = System.getenv("FIRMS_MAP_KEY")?.takeIf { it.isNotBlank() }
    ?: localProps.getProperty("FIRMS_MAP_KEY", "")

android {
    namespace = "com.atmosphere.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.atmosphere.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "FIRMS_MAP_KEY", "\"${firmsKey.trim()}\"")
    }

    // Penandatanganan memakai keystore dari environment (GitHub Secrets).
    // Jika tidak diset, APK ditandatangani dengan kunci debug agar tetap bisa dipasang.
    val keystorePath: String? = System.getenv("KEYSTORE_FILE")
    signingConfigs {
        if (keystorePath != null && File(keystorePath).exists()) {
            create("release") {
                storeFile = File(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Peta OpenStreetMap (gratis, tanpa API key)
    implementation("org.osmdroid:osmdroid-android:6.1.18")
}
