package com.atmosphere.app.ui

import android.content.res.Configuration
import android.content.res.Resources
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp

/** Pilihan tema pengguna: 0 = ikuti sistem, 1 = terang, 2 = gelap. */
object ThemeState {
    var mode by mutableIntStateOf(0)
}

/**
 * Palet bergaya DialChat: latar putih/gelap, kartu abu muda (surf), header biru `Brand`, aksen kalem.
 * Semua properti membaca [ThemeState] sehingga tampilan ikut berubah saat tema diganti.
 * Mode "sistem" dibaca dari konfigurasi sistem; activity dibuat ulang otomatis saat tema sistem berubah.
 */
object C {
    val isDark: Boolean
        get() = when (ThemeState.mode) {
            1 -> false
            2 -> true
            else -> (Resources.getSystem().configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        }

    private fun pick(light: Long, dark: Long) = Color(if (isDark) dark else light)

    /** Biru header & tombol terisi (sama di mode terang dan gelap). Teks di atasnya selalu putih. */
    val Brand = Color(0xFF1D4ED8)

    val Bg: Color get() = pick(0xFFFFFFFF, 0xFF0F1318)
    val Ink: Color get() = pick(0xFF14181F, 0xFFECEFF4)
    val Muted: Color get() = pick(0xFF5B6472, 0xFFA3ACBA)

    /** Permukaan kartu ("surf"). */
    val Chip: Color get() = pick(0xFFF3F4F7, 0xFF1C222B)
    val Line: Color get() = pick(0xFFE3E6EB, 0xFF2A313B)

    /** Aksen biru untuk teks/ikon/grafik (di mode gelap lebih terang agar terbaca). */
    val Blue: Color get() = pick(0xFF1D4ED8, 0xFF8AB0FF)

    val Sun = Color(0xFFFFB703)
    val Gold: Color get() = pick(0xFFB45309, 0xFFF2B04A)
    val Orange: Color get() = pick(0xFFC2410C, 0xFFFB8F5A)
    val Pink: Color get() = pick(0xFFB42318, 0xFFFF8A80)
    val Purple: Color get() = pick(0xFF6D28D9, 0xFFB79CFF)
    val Teal: Color get() = pick(0xFF0F7A41, 0xFF47C98A)
}

@Composable
fun AtmosphereTheme(content: @Composable () -> Unit) {
    val dark = C.isDark
    MaterialTheme(
        colorScheme = if (dark) {
            darkColorScheme(
                primary = C.Brand,
                onPrimary = Color.White,
                background = C.Bg,
                surface = C.Chip,
                onSurface = C.Ink,
            )
        } else {
            lightColorScheme(
                primary = C.Brand,
                onPrimary = Color.White,
                background = C.Bg,
                surface = Color.White,
                onSurface = C.Ink,
            )
        },
        content = content,
    )
}

@Composable
fun Txt(
    text: String,
    size: Int = 14,
    color: Color = C.Ink,
    bold: Boolean = false,
    modifier: Modifier = Modifier,
    maxLines: Int = Int.MAX_VALUE,
    align: TextAlign? = null,
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        textAlign = align,
    )
}

/** Seperti [Txt], tetapi ukurannya Float (agar bisa dianimasikan halus) dan bobot hurufnya bisa diatur. */
@Composable
fun TxtSp(
    text: String,
    size: Float,
    color: Color = C.Ink,
    bold: Boolean = false,
    modifier: Modifier = Modifier,
    maxLines: Int = Int.MAX_VALUE,
    weight: FontWeight? = null,
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size.sp,
        fontWeight = weight ?: if (bold) FontWeight.Bold else FontWeight.Normal,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}
