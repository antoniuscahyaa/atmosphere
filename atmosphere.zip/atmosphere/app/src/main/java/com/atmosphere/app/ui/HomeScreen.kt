package com.atmosphere.app.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.atmosphere.app.data.AirQuality
import com.atmosphere.app.data.Compare
import com.atmosphere.app.data.Comparison
import com.atmosphere.app.data.Forecast
import com.atmosphere.app.data.Geo
import com.atmosphere.app.data.LocationHelper
import com.atmosphere.app.data.Marine
import com.atmosphere.app.data.Quake
import com.atmosphere.app.data.UserPrefs
import com.atmosphere.app.data.WeatherAlert
import com.atmosphere.app.data.WeatherApi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private enum class LocState { Loading, NeedLocation, Ready }

private fun greeting(): String = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
    in 4..10 -> "Selamat pagi"
    in 11..14 -> "Selamat siang"
    in 15..17 -> "Selamat sore"
    else -> "Selamat malam"
}

private fun two(n: Int) = n.toString().padStart(2, '0')

@Composable
fun HomeScreen(active: Boolean, modifier: Modifier = Modifier, onOpen: (MapRequest) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf(UserPrefs.name(ctx)) }
    var editingName by remember { mutableStateOf(false) }

    var state by remember { mutableStateOf(LocState.Loading) }
    var usingLast by remember { mutableStateOf(false) }
    var lat by remember { mutableStateOf(0.0) }
    var lon by remember { mutableStateOf(0.0) }
    var placeName by remember { mutableStateOf("") }
    var forecast by remember { mutableStateOf<Forecast?>(null) }
    var air by remember { mutableStateOf<AirQuality?>(null) }
    var marine by remember { mutableStateOf<Marine?>(null) }
    var comparison by remember { mutableStateOf<Comparison?>(null) }
    var alerts by remember { mutableStateOf<List<WeatherAlert>>(emptyList()) }
    var quake by remember { mutableStateOf<Pair<Quake, Double>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    var loadedAt by remember { mutableLongStateOf(0L) }

    fun load() {
        job?.cancel()
        job = scope.launch {
            state = LocState.Loading
            error = null
            val fresh = if (LocationHelper.hasPermission(ctx)) LocationHelper.current(ctx) else null
            val here: Pair<Double, Double>
            if (fresh != null) {
                here = fresh.latitude to fresh.longitude
                UserPrefs.setLastLocation(ctx, here.first, here.second)
                usingLast = false
            } else {
                val saved = UserPrefs.lastLocation(ctx)
                if (saved == null) {
                    state = LocState.NeedLocation
                    return@launch
                }
                here = saved
                usingLast = true
            }
            lat = here.first
            lon = here.second
            state = LocState.Ready
            forecast = null
            air = null
            marine = null
            comparison = null
            alerts = emptyList()
            quake = null
            placeName = ""

            // Peringatan & gempa BMKG: tambahan, gagal tidak menghalangi apa pun.
            launch {
                runCatching { WeatherApi.alerts() }.onSuccess { all ->
                    alerts = all.filter { a -> a.polygons.any { Geo.inPolygon(lat, lon, it) } }
                }.onFailure { if (it is CancellationException) throw it }
            }
            launch {
                runCatching { WeatherApi.quakes() }.onSuccess { qs ->
                    quake = qs.map { it to Geo.distanceKm(lat, lon, it.lat, it.lon) }
                        .filter { it.second <= 300.0 }
                        .minByOrNull { it.second }
                }.onFailure { if (it is CancellationException) throw it }
            }

            try {
                coroutineScope {
                    val f = async { WeatherApi.forecast(lat, lon) }
                    val n = async { WeatherApi.reverseName(lat, lon) }
                    val a = async { WeatherApi.airQuality(lat, lon) }
                    val w = async { WeatherApi.marine(lat, lon) }
                    val ex = async {
                        val fc = f.await()
                        try {
                            WeatherApi.otherSources(lat, lon, fc.utcOffset)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            emptyList()
                        }
                    }
                    val fc = f.await()
                    forecast = fc
                    placeName = n.await() ?: "%.3f, %.3f".format(lat, lon)
                    air = a.await()
                    marine = w.await()
                    comparison = Compare.build(fc, ex.await())
                    loadedAt = System.currentTimeMillis()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Gagal memuat prakiraan. Periksa koneksi internet."
            }
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        load()
    }

    // Beranda tetap hidup di latar saat tab lain dibuka; data disegarkan jika sudah lebih dari 10 menit.
    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        when {
            job == null -> {
                if (LocationHelper.hasPermission(ctx)) load()
                else permLauncher.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                )
            }
            state == LocState.NeedLocation -> load()
            forecast == null && error != null -> load()
            loadedAt != 0L && System.currentTimeMillis() - loadedAt > 10 * 60_000L -> load()
        }
    }

    Column(
        modifier
            .fillMaxSize()
            .background(C.Bg)
            // Beranda menutupi peta di bawahnya: sentuhan tidak boleh tembus ke peta.
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .verticalScroll(rememberScrollState()),
    ) {
        // ---- Header biru: sapaan + cuaca sekarang ----
        BlueHeader {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Column(Modifier.clickable { editingName = true }) {
                        Txt(
                            if (name.isBlank()) greeting() else "${greeting()},",
                            15, Color.White.copy(alpha = 0.85f),
                        )
                        if (name.isNotBlank()) Txt(name, 30, Color.White, bold = true, maxLines = 1)
                    }
                    val date = remember { SimpleDateFormat("EEEE, d MMMM yyyy", Locale("id")).format(Date()) }
                    Txt(
                        listOf(placeName.ifBlank { null }, date).filterNotNull().joinToString(" · "),
                        13, Color.White.copy(alpha = 0.8f), maxLines = 2,
                    )
                }
                GlassButton(onClick = { load() }) {
                    if (state == LocState.Loading || (state == LocState.Ready && forecast == null && error == null)) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp, modifier = Modifier.size(20.dp))
                    } else RefreshGlyph(Color.White, 20.dp)
                }
            }
            forecast?.let {
                Spacer(Modifier.height(16.dp))
                HeroInHeader(it, comparison)
            }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(top = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
        // ---- Isian nama ----
        if (name.isBlank() || editingName) {
            NameCard(
                initial = name,
                onSave = {
                    UserPrefs.setName(ctx, it)
                    name = UserPrefs.name(ctx)
                    editingName = false
                },
                onCancel = if (name.isNotBlank()) ({ editingName = false }) else null,
            )
        }

        // ---- Isi utama ----
        when {
            state == LocState.NeedLocation -> NeedLocationCard(
                onAllow = {
                    permLauncher.launch(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    )
                },
                onMap = { onOpen(MapRequest(lat = -6.2, lon = 106.85, name = null, openSheet = false)) },
            )

            error != null && forecast == null -> Card {
                Txt(error ?: "", 14, C.Muted, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                PillButton("Coba lagi", C.Brand, Color.White) { load() }
            }

            forecast == null -> Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = C.Blue, strokeWidth = 3.dp)
            }

            else -> {
                val f = forecast!!
                if (usingLast) {
                    Txt("Memakai lokasi terakhir yang diketahui karena lokasi saat ini belum tersedia.", 12, C.Muted)
                }
                comparison?.let { SourceCompareCard(it) }
                alerts.take(3).forEach { AlertCard(it) }
                RainCard(f, comparison)
                SummaryTiles(f, air, marine)
                TipsCard(f, air, comparison)
                quake?.let { (q, km) -> QuakeCard(q, km) }
                Shortcuts(
                    onMap = { onOpen(MapRequest(lat = lat, lon = lon, name = placeName, openSheet = false)) },
                    onRadar = { onOpen(MapRequest(lat = lat, lon = lon, name = placeName, openSheet = false, radar = true)) },
                    onDetail = { onOpen(MapRequest(lat = lat, lon = lon, name = placeName.ifBlank { null }, openSheet = true)) },
                )
                Txt(
                    "Data: Open-Meteo (ECMWF, DWD ICON, NOAA GFS) · MET Norway · BMKG · © OpenStreetMap",
                    10, C.Muted,
                )
            }
        }
        }
    }
}

// ---------------------------------------------------------------------
// Komponen beranda
// ---------------------------------------------------------------------

@Composable
internal fun Card(
    modifier: Modifier = Modifier,
    bg: Color = C.Chip,
    content: @Composable () -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(bg)
            .padding(16.dp)
    ) { content() }
}

@Composable
internal fun PillButton(label: String, bg: Color, fg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) { Txt(label, 14, fg, bold = true) }
}

@Composable
internal fun NameCard(initial: String, onSave: (String) -> Unit, onCancel: (() -> Unit)?) {
    val focus = LocalFocusManager.current
    var text by remember { mutableStateOf(initial) }
    Card {
        Txt(if (initial.isBlank()) "Halo! Siapa nama Anda?" else "Ubah nama", 15, bold = true)
        Spacer(Modifier.height(2.dp))
        Txt("Dipakai untuk sapaan di beranda. Disimpan hanya di perangkat ini.", 12, C.Muted)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(C.Bg)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                if (text.isEmpty()) Txt("Nama", 15, C.Muted)
                BasicTextField(
                    value = text,
                    onValueChange = { text = it.take(30) },
                    singleLine = true,
                    textStyle = TextStyle(color = C.Ink, fontSize = 15.sp),
                    cursorBrush = SolidColor(C.Blue),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = {
                        focus.clearFocus()
                        if (text.isNotBlank()) onSave(text)
                    }),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.width(8.dp))
            PillButton("Simpan", if (text.isNotBlank()) C.Brand else C.Muted, Color.White) {
                focus.clearFocus()
                if (text.isNotBlank()) onSave(text)
            }
        }
        if (onCancel != null) {
            Spacer(Modifier.height(8.dp))
            Txt("Batal", 13, C.Muted, bold = true, modifier = Modifier.clickable(onClick = onCancel))
        }
    }
}

@Composable
private fun NeedLocationCard(onAllow: () -> Unit, onMap: () -> Unit) {
    Card {
        Txt("Lokasi belum tersedia", 17, bold = true)
        Spacer(Modifier.height(4.dp))
        Txt(
            "Beranda menampilkan cuaca di lokasi Anda saat ini. Izinkan akses lokasi dan pastikan GPS/Lokasi aktif.",
            13, C.Muted,
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("Izinkan lokasi", C.Brand, Color.White, onClick = onAllow)
            PillButton("Buka peta", C.Bg, C.Ink, onClick = onMap)
        }
    }
}

@Composable
private fun HeroInHeader(f: Forecast, c: Comparison?) {
    val now = f.now
    val day = f.days.firstOrNull { it.date == now.date } ?: f.days.first()
    val soft = Color.White.copy(alpha = 0.85f)
    Row(verticalAlignment = Alignment.CenterVertically) {
        WeatherIcon(now.code, now.isDay, 84.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Txt("${now.temp.roundToInt()}°", 56, Color.White, bold = true)
            Txt(describe(now.code), 15, soft)
        }
        Column(horizontalAlignment = Alignment.End) {
            Txt("Terasa ${now.feels.roundToInt()}°", 13, soft)
            Txt("Maks ${day.max.roundToInt()}° · Min ${day.min.roundToInt()}°", 14, Color.White, bold = true)
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.18f))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        DropGlyph(Color.White, 14.dp)
        Spacer(Modifier.width(8.dp))
        Txt(Compare.rainSentence(f, c), 14, Color.White, bold = true)
    }
}

@Composable
private fun AlertCard(a: WeatherAlert) {
    Card(bg = C.Gold.copy(alpha = 0.14f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AlertGlyph(C.Gold, 20.dp)
            Spacer(Modifier.width(8.dp))
            Txt("Peringatan dini BMKG", 12, C.Gold, bold = true)
        }
        Spacer(Modifier.height(4.dp))
        Txt(a.event.ifBlank { a.headline }, 15, bold = true)
        if (a.headline.isNotBlank() && a.headline != a.event) Txt(a.headline, 12, C.Muted, maxLines = 3)
        if (a.area.isNotBlank()) Txt(a.area, 12, C.Muted, maxLines = 2)
    }
}

@Composable
private fun RainCard(f: Forecast, c: Comparison?) {
    val series = Compare.rainSeries(f, c)
    if (series.isEmpty()) return
    val maxMm = maxOf(2.0, series.maxOf { it.meanRain })
    val total = c?.total ?: 1
    Card {
        Txt("Hujan ${Compare.WINDOW} jam ke depan", 15, bold = true)
        Txt(
            if (c != null) "Rata-rata ${c.total} sumber · warna tua = sebagian besar sumber memprediksi hujan"
            else "Curah hujan per jam (mm)",
            11, C.Muted,
        )
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().height(96.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            series.forEach { h ->
                val frac = (h.meanRain / maxMm).coerceIn(0.0, 1.0).toFloat()
                val strong = h.rainSources * 2 > total
                Box(
                    Modifier
                        .weight(1f)
                        .height((6 + 90 * frac).dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(
                            when {
                                h.rainSources == 0 -> C.Line
                                strong -> C.Blue
                                else -> C.Blue.copy(alpha = 0.4f)
                            }
                        )
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            series.forEachIndexed { i, h ->
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    if (i % 3 == 0) Txt(two(h.hour), 10, C.Muted, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun SummaryTiles(f: Forecast, air: AirQuality?, marine: Marine?) {
    val now = f.now
    val day = f.days.firstOrNull { it.date == now.date } ?: f.days.first()
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatTile("Angin", "${now.wind.roundToInt()} km/j", "dari ${compass(now.windDir)}", C.Teal)
        StatTile("Hembusan", "${now.gust.roundToInt()} km/j", "maks saat ini", C.Orange)
        StatTile("Lembap", "${now.humidity}%", "kelembapan", C.Blue)
        StatTile("UV maks", "${day.uvMax.roundToInt()}", "indeks UV hari ini", C.Gold)
        if (air != null) {
            val (label, col) = aqiInfo(air.aqi)
            StatTile("Kualitas udara", "AQI ${air.aqi}", label, col)
        }
        StatTile("Matahari", day.sunrise.takeLast(5), "terbenam ${day.sunset.takeLast(5)}", C.Gold)
        if (marine != null) {
            StatTile("Gelombang", "%.1f m".format(marine.height), "periode %.0f dtk".format(marine.period), C.Teal)
        }
    }
}

@Composable
private fun TipsCard(f: Forecast, air: AirQuality?, c: Comparison?) {
    val tips = remember(f, air, c) { buildTips(f, air, c) }
    Card {
        Txt("Saran untuk hari ini", 15, bold = true)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            tips.forEach { t ->
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        Modifier
                            .padding(top = 6.dp)
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(t.color)
                    )
                    Spacer(Modifier.width(10.dp))
                    Txt(t.text, 13)
                }
            }
        }
    }
}

@Composable
private fun QuakeCard(q: Quake, km: Double) {
    Card(bg = C.Pink.copy(alpha = 0.10f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            QuakeGlyph(C.Pink, 20.dp)
            Spacer(Modifier.width(8.dp))
            Txt("Gempa terdekat (BMKG)", 12, C.Pink, bold = true)
        }
        Spacer(Modifier.height(4.dp))
        Txt("M ${"%.1f".format(q.mag)} · ${km.roundToInt()} km dari Anda", 15, bold = true)
        Txt(q.region, 12, C.Muted, maxLines = 2)
        if (q.time.isNotBlank()) Txt(q.time, 11, C.Muted)
    }
}

@Composable
private fun Shortcuts(onMap: () -> Unit, onRadar: () -> Unit, onDetail: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ShortcutButton("Peta", Modifier.weight(1f), onMap) { MapGlyph(C.Blue, 18.dp) }
        ShortcutButton("Radar", Modifier.weight(1f), onRadar) { DropGlyph(C.Blue, 14.dp) }
        ShortcutButton("Detail", Modifier.weight(1f), onDetail) { BoltGlyph(C.Blue, 18.dp) }
    }
}

@Composable
private fun ShortcutButton(
    label: String,
    modifier: Modifier,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(C.Chip)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon()
        Spacer(Modifier.width(6.dp))
        Txt(label, 14, C.Ink, bold = true)
    }
}
