package com.atmosphere.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.roundToInt

/** Satu lokasi favorit: [label] buatan pengguna, [place] = "Kelurahan/desa, Kota". */
data class Favorite(val label: String, val place: String, val lat: Double, val lon: Double)

/** Ringkasan cuaca untuk satu kartu favorit di Beranda. */
data class FavSummary(
    val temp: Int,
    val code: Int,
    val isDay: Boolean,
    /** Peluang hujan tertinggi dalam jendela [Compare.WINDOW] jam ke depan (persen). */
    val rainProb: Int,
    /** Jam (lokal) hujan pertama dalam jendela itu, atau null jika tidak ada hujan. */
    val firstRainHour: Int?,
)

/** Hitung ringkasan kartu dari prakiraan lengkap (tanpa perbandingan sumber, agar ringan). */
fun summarize(f: Forecast): FavSummary {
    val now = f.now
    val upcoming = f.hours
        .filter { it.date > now.date || (it.date == now.date && it.hour >= now.hour) }
        .take(Compare.WINDOW)
    val first = upcoming.firstOrNull { it.rain >= Compare.RAIN_MM }
    return FavSummary(
        temp = now.temp.roundToInt(),
        code = now.code,
        isDay = now.isDay,
        rainProb = upcoming.maxOfOrNull { it.rainProb } ?: 0,
        firstRainHour = first?.hour,
    )
}

/** Daftar favorit (maks [MAX]) yang tersimpan di perangkat. State Compose, jadi UI ikut berubah. */
object Favorites {
    const val MAX = 4

    val items = mutableStateListOf<Favorite>()

    /** true = Peta baru dibuka dari layar Atur dan perlu menampilkan petunjuk "Simpan ke favorit". */
    var mapHint by mutableStateOf(false)

    fun load(ctx: Context) {
        items.clear()
        items.addAll(UserPrefs.favorites(ctx).take(MAX))
    }

    private fun save(ctx: Context) = UserPrefs.setFavorites(ctx, items.toList())

    /** false jika daftar sudah penuh. */
    fun add(ctx: Context, f: Favorite): Boolean {
        if (items.size >= MAX) return false
        items.add(f)
        save(ctx)
        return true
    }

    fun update(ctx: Context, index: Int, f: Favorite) {
        if (index !in items.indices) return
        items[index] = f
        save(ctx)
    }

    fun remove(ctx: Context, index: Int) {
        if (index !in items.indices) return
        items.removeAt(index)
        save(ctx)
    }

    fun move(ctx: Context, index: Int, delta: Int) {
        val j = index + delta
        if (index !in items.indices || j !in items.indices) return
        val t = items[index]
        items[index] = items[j]
        items[j] = t
        save(ctx)
    }
}
