package com.atmosphere.app.data

import org.json.JSONArray
import org.json.JSONObject
import android.content.Context
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Pengaturan kecil pengguna: nama untuk sapaan dan lokasi terakhir yang berhasil didapat. */
object UserPrefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("atmosphere_user", Context.MODE_PRIVATE)

    fun name(ctx: Context): String = sp(ctx).getString("name", "").orEmpty()

    fun setName(ctx: Context, name: String) {
        sp(ctx).edit().putString("name", name.trim().take(30)).apply()
    }

    /** Tema: 0 = ikuti sistem, 1 = terang, 2 = gelap. */
    fun theme(ctx: Context): Int = sp(ctx).getInt("theme", 0).coerceIn(0, 2)

    fun setTheme(ctx: Context, mode: Int) {
        sp(ctx).edit().putInt("theme", mode.coerceIn(0, 2)).apply()
    }

    /** Lokasi favorit (JSON). */
    fun favorites(ctx: Context): List<Favorite> = try {
        val a = JSONArray(sp(ctx).getString("favorites", "[]"))
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Favorite(o.getString("label"), o.getString("place"), o.getDouble("lat"), o.getDouble("lon"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun setFavorites(ctx: Context, list: List<Favorite>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("label", it.label).put("place", it.place).put("lat", it.lat).put("lon", it.lon))
        }
        sp(ctx).edit().putString("favorites", a.toString()).apply()
    }

    /** Bahasa: 0 = ikuti sistem, 1 = Indonesia, 2 = English. */
    fun language(ctx: Context): Int = sp(ctx).getInt("lang", 0).coerceIn(0, 2)

    fun setLanguage(ctx: Context, mode: Int) {
        sp(ctx).edit().putInt("lang", mode.coerceIn(0, 2)).apply()
    }

    fun lastLocation(ctx: Context): Pair<Double, Double>? {
        val p = sp(ctx)
        if (!p.contains("lat") || !p.contains("lon")) return null
        return Double.fromBits(p.getLong("lat", 0)) to Double.fromBits(p.getLong("lon", 0))
    }

    fun setLastLocation(ctx: Context, lat: Double, lon: Double) {
        sp(ctx).edit().putLong("lat", lat.toBits()).putLong("lon", lon.toBits()).apply()
    }
}

object Geo {
    /** Titik (lat, lon) di dalam poligon? Algoritma ray casting. */
    fun inPolygon(lat: Double, lon: Double, poly: List<Pair<Double, Double>>): Boolean {
        var inside = false
        var j = poly.lastIndex
        for (i in poly.indices) {
            val (yi, xi) = poly[i]
            val (yj, xj) = poly[j]
            if ((yi > lat) != (yj > lat) && lon < (xj - xi) * (lat - yi) / (yj - yi) + xi) inside = !inside
            j = i
        }
        return inside
    }

    /** Jarak lingkaran besar dalam km. */
    fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dp = p2 - p1
        val dl = Math.toRadians(lon2 - lon1)
        val a = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
        return 2 * r * asin(sqrt(a))
    }
}
