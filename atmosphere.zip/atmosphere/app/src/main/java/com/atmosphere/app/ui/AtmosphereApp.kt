package com.atmosphere.app.ui

import com.atmosphere.app.data.Favorite
import com.atmosphere.app.data.Favorites
import com.atmosphere.app.data.Geo
import com.atmosphere.app.data.tr
import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.atmosphere.app.BuildConfig
import com.atmosphere.app.data.AirQuality
import com.atmosphere.app.data.Compare
import com.atmosphere.app.data.Comparison
import com.atmosphere.app.data.FireSpot
import com.atmosphere.app.data.Forecast
import com.atmosphere.app.data.LocationHelper
import com.atmosphere.app.data.Marine
import com.atmosphere.app.data.Quake
import com.atmosphere.app.data.WeatherAlert
import com.atmosphere.app.data.Place
import com.atmosphere.app.data.RadarData
import com.atmosphere.app.data.RadarFrame
import com.atmosphere.app.data.WeatherApi
import com.atmosphere.app.data.WindPoint
import com.atmosphere.app.map.HazardOverlay
import com.atmosphere.app.map.MyLocationOverlay
import com.atmosphere.app.map.PinOverlay
import com.atmosphere.app.map.RadarLayer
import com.atmosphere.app.map.Tiles
import com.atmosphere.app.map.WindOverlay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.osmdroid.events.DelayedMapListener
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.TilesOverlay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class Jobs {
    var wind: Job? = null
    var select: Job? = null
    var fire: Job? = null
}

@Composable
fun AtmosphereApp(request: MapRequest? = null, active: Boolean = true, onHome: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val density = LocalDensity.current
    val screenHdp = LocalConfiguration.current.screenHeightDp

    var map by remember { mutableStateOf<MapView?>(null) }
    var pin by remember { mutableStateOf<GeoPoint?>(null) }
    var forecast by remember { mutableStateOf<Forecast?>(null) }
    var placeName by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var air by remember { mutableStateOf<AirQuality?>(null) }
    var marine by remember { mutableStateOf<Marine?>(null) }
    var comparison by remember { mutableStateOf<Comparison?>(null) }

    var radarOn by remember { mutableStateOf(true) }
    var windOn by remember { mutableStateOf(true) }
    var stormOn by remember { mutableStateOf(true) }
    var radar by remember { mutableStateOf<RadarData?>(null) }
    var frameIdx by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var windPoints by remember { mutableStateOf<List<WindPoint>>(emptyList()) }

    var alertOn by remember { mutableStateOf(false) }
    var quakeOn by remember { mutableStateOf(false) }
    var fireOn by remember { mutableStateOf(false) }
    var alerts by remember { mutableStateOf<List<WeatherAlert>>(emptyList()) }
    var quakes by remember { mutableStateOf<List<Quake>>(emptyList()) }
    var fires by remember { mutableStateOf<List<FireSpot>>(emptyList()) }
    var notice by remember { mutableStateOf<String?>(null) }
    var locating by remember { mutableStateOf(false) }

    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Place>>(emptyList()) }

    val windOverlay = remember { WindOverlay() }
    val hazardOverlay = remember { HazardOverlay() }
    val myLocOverlay = remember { MyLocationOverlay() }
    val pinOverlay = remember { PinOverlay() }
    val radarLayer = remember { RadarLayer() }
    val jobs = remember { Jobs() }

    // ---- aksi ----

    fun select(lat: Double, lon: Double, name: String?) {
        focus.clearFocus()
        val lonN = ((lon + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
        val p = GeoPoint(lat, lonN)
        pin = p
        pinOverlay.point = p
        map?.invalidate()
        loading = true
        error = null
        forecast = null
        air = null
        marine = null
        comparison = null
        placeName = name ?: tr("Memuat lokasi…", "Loading location…")
        jobs.select?.cancel()
        jobs.select = scope.launch {
            try {
                val f = async { WeatherApi.forecast(lat, lonN) }
                val n = if (name == null) async { WeatherApi.reverseName(lat, lonN) } else null
                // Kualitas udara & gelombang bersifat tambahan: gagal tidak menghalangi prakiraan.
                val a = async { WeatherApi.airQuality(lat, lonN) }
                val w = async { WeatherApi.marine(lat, lonN) }
                // Sumber pembanding juga tambahan: gagal hanya berarti tidak ada kartu kecocokan.
                val ex = async {
                    val fc = f.await()
                    try {
                        WeatherApi.otherSources(lat, lonN, fc.utcOffset)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
                forecast = f.await()
                if (n != null) {
                    placeName = n.await() ?: "%.3f, %.3f".format(lat, lonN)
                }
                air = a.await()
                marine = w.await()
                comparison = Compare.build(f.await(), ex.await())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = tr("Gagal memuat prakiraan. Periksa koneksi internet.", "Failed to load the forecast. Check your internet connection.")
                if (name == null) placeName = "%.3f, %.3f".format(lat, lonN)
            } finally {
                loading = false
            }
        }
    }

    fun closeSheet() {
        jobs.select?.cancel()
        pin = null
        pinOverlay.point = null
        forecast = null
        air = null
        marine = null
        comparison = null
        error = null
        loading = false
        map?.invalidate()
    }

    fun refreshWind(m: MapView) {
        if (!windOn && !stormOn) return
        if (m.width == 0 || m.height == 0) return
        jobs.wind?.cancel()
        jobs.wind = scope.launch {
            val bb = m.boundingBox
            runCatching { WeatherApi.windGrid(bb.latSouth, bb.latNorth, bb.lonWest, bb.lonEast, 5, 8) }
                .onSuccess { windPoints = it }
        }
    }

    fun refreshFires(m: MapView) {
        if (!fireOn || m.width == 0 || m.height == 0) return
        if (BuildConfig.FIRMS_MAP_KEY.isBlank()) return
        if (m.zoomLevelDouble < 5.0) {
            notice = tr("Zoom lebih dekat untuk melihat titik api", "Zoom in closer to see fire hotspots")
            return
        }
        jobs.fire?.cancel()
        jobs.fire = scope.launch {
            val bb = m.boundingBox
            runCatching {
                WeatherApi.fires(BuildConfig.FIRMS_MAP_KEY, bb.latSouth, bb.latNorth, bb.lonWest, bb.lonEast)
            }.onSuccess {
                fires = it
                notice = if (it.isEmpty()) tr("Tidak ada titik api di area ini (24 jam terakhir)", "No fire hotspots in this area (last 24 hours)") else null
            }.onFailure {
                if (it is CancellationException) throw it
                notice = tr("Gagal memuat titik api (${it.message?.take(40) ?: "jaringan"})", "Failed to load fire hotspots (${it.message?.take(40) ?: "network"})")
            }
        }
    }

    fun flash(msg: String) {
        notice = msg
        scope.launch {
            delay(4000)
            if (notice == msg) notice = null
        }
    }

    fun saveFavorite() {
        val pt = pin ?: return
        if (placeName.isBlank() || placeName.contains("…")) {
            flash(tr("Nama lokasi masih dimuat, coba lagi sebentar", "Location name is still loading, try again in a moment"))
            return
        }
        if (Favorites.items.any { Geo.distanceKm(it.lat, it.lon, pt.latitude, pt.longitude) < 0.3 }) {
            flash(tr("Lokasi ini sudah ada di favorit", "This place is already in your favorites"))
            return
        }
        val ok = Favorites.add(ctx, Favorite(placeName.substringBefore(",").trim().take(24), placeName, pt.latitude, pt.longitude))
        flash(
            if (ok) tr("Disimpan ke favorit", "Saved to favorites")
            else tr("Favorit penuh (maks 4). Hapus satu lewat Beranda > Atur", "Favorites are full (max 4). Remove one via Home > Edit")
        )
    }

    // Datang dari layar Atur favorit lewat "Pilih di peta": beri petunjuk sekali.
    LaunchedEffect(active, Favorites.mapHint) {
        if (active && Favorites.mapHint) {
            Favorites.mapHint = false
            flash(tr("Sentuh peta, lalu tekan \"Simpan ke favorit\"", "Tap the map, then press \"Save to favorites\""))
        }
    }

    fun locate() {
        if (locating) return
        locating = true
        scope.launch {
            try {
                val l = LocationHelper.current(ctx)
                if (l == null) {
                    flash(tr("Lokasi belum tersedia. Pastikan GPS/Lokasi aktif", "Location unavailable. Make sure GPS/Location is turned on"))
                } else {
                    myLocOverlay.point = GeoPoint(l.latitude, l.longitude)
                    myLocOverlay.accuracyM = if (l.hasAccuracy()) l.accuracy else 0f
                    map?.controller?.setZoom(10.0)
                    select(l.latitude, l.longitude, null)
                }
            } finally {
                locating = false
            }
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) locate() else flash(tr("Izin lokasi ditolak", "Location permission denied"))
    }

    val tapReceiver = remember {
        object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                select(p.latitude, p.longitude, null)
                return true
            }

            override fun longPressHelper(p: GeoPoint): Boolean = false
        }
    }

    // ---- efek ----

    LaunchedEffect(query) {
        if (query.trim().length < 2) {
            results = emptyList()
        } else {
            delay(400)
            results = runCatching { WeatherApi.search(query.trim()) }.getOrDefault(emptyList())
        }
    }

    LaunchedEffect(map, windOn, stormOn) {
        val m = map ?: return@LaunchedEffect
        delay(400)
        refreshWind(m)
    }

    // Peringatan dini BMKG
    LaunchedEffect(alertOn) {
        while (alertOn) {
            runCatching { WeatherApi.alerts() }
                .onSuccess {
                    alerts = it
                    notice = if (it.isEmpty()) tr("Tidak ada peringatan dini BMKG aktif", "No active BMKG early warnings") else null
                }
                .onFailure { if (it is CancellationException) throw it; notice = tr("Gagal memuat peringatan BMKG", "Failed to load BMKG warnings") }
            delay(10 * 60_000L)
        }
    }

    // Gempa BMKG
    LaunchedEffect(quakeOn) {
        while (quakeOn) {
            runCatching { WeatherApi.quakes() }
                .onSuccess { quakes = it }
                .onFailure { if (it is CancellationException) throw it; notice = tr("Gagal memuat data gempa BMKG", "Failed to load BMKG earthquake data") }
            delay(5 * 60_000L)
        }
    }

    // Titik api FIRMS (butuh key)
    LaunchedEffect(map, fireOn) {
        val m = map ?: return@LaunchedEffect
        if (!fireOn) return@LaunchedEffect
        if (BuildConfig.FIRMS_MAP_KEY.isBlank()) {
            notice = tr("Key NASA FIRMS belum diisi (lihat README)", "NASA FIRMS key not set (see README)")
            return@LaunchedEffect
        }
        delay(400)
        refreshFires(m)
    }

    LaunchedEffect(alerts, quakes, fires, alertOn, quakeOn, fireOn, map) {
        hazardOverlay.alerts = alerts
        hazardOverlay.quakes = quakes
        hazardOverlay.fires = fires
        hazardOverlay.showAlerts = alertOn
        hazardOverlay.showQuakes = quakeOn
        hazardOverlay.showFires = fireOn
        map?.invalidate()
    }

    LaunchedEffect(alertOn, quakeOn, fireOn) {
        if (!alertOn && !quakeOn && !fireOn) notice = null
    }

    LaunchedEffect(windPoints, windOn, stormOn, map) {
        windOverlay.points = windPoints
        windOverlay.showWind = windOn
        windOverlay.showStorm = stormOn
        map?.invalidate()
    }

    // Ambil frame radar & segarkan tiap 5 menit selama radar aktif
    LaunchedEffect(radarOn) {
        while (radarOn) {
            runCatching { WeatherApi.radar() }.onSuccess { r ->
                radar = r
                if (!playing || frameIdx >= r.frames.size) frameIdx = r.frames.lastIndex.coerceAtLeast(0)
            }
            delay(5 * 60_000L)
        }
    }

    // Animasi radar
    LaunchedEffect(playing, radar) {
        val n = radar?.frames?.size ?: 0
        while (playing && n > 1) {
            delay(900)
            frameIdx = (frameIdx + 1) % n
        }
    }

    // Tampilkan frame radar di peta
    LaunchedEffect(map, radarOn, radar, frameIdx) {
        val m = map ?: return@LaunchedEffect
        val r = radar
        val fr = r?.frames?.getOrNull(frameIdx)
        if (!radarOn || r == null || fr == null) radarLayer.clear(m) else radarLayer.show(m, r.host, fr.path)
    }

    // Geser pusat peta supaya pin tidak tertutup panel prakiraan
    LaunchedEffect(map, pin != null) {
        val offset = if (pin != null) with(density) { (screenHdp * 0.26f).dp.roundToPx() } else 0
        map?.setMapCenterOffset(0, -offset)
    }
    LaunchedEffect(map, pin) {
        pin?.let { map?.controller?.animateTo(it) }
    }

    // Peta gelap: balik warna tile dasar OSM (radar & lapisan lain tidak ikut berubah)
    val dark = C.isDark
    LaunchedEffect(map, dark) {
        val m = map ?: return@LaunchedEffect
        m.overlayManager.tilesOverlay.setColorFilter(if (dark) TilesOverlay.INVERT_COLORS else null)
        m.invalidate()
    }

    // Permintaan dari beranda (Peta / Radar / Detail prakiraan)
    LaunchedEffect(request?.id, map) {
        val r = request ?: return@LaunchedEffect
        val m = map ?: return@LaunchedEffect
        if (r.radar) radarOn = true
        myLocOverlay.point = GeoPoint(r.lat, r.lon)
        m.controller.setZoom(9.0)
        if (r.openSheet) {
            select(r.lat, r.lon, r.name)
        } else {
            closeSheet()
            m.controller.setCenter(GeoPoint(r.lat, r.lon))
        }
    }

    // Tombol kembali: tutup panel dulu, baru kembali ke beranda
    BackHandler(enabled = active) {
        if (pin != null) closeSheet() else onHome()
    }

    DisposableEffect(lifecycleOwner, map) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> map?.onResume()
                Lifecycle.Event.ON_PAUSE -> map?.onPause()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // ---- UI ----

    val frames = radar?.frames.orEmpty()

    Box(Modifier.fillMaxSize().background(C.Bg)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(Tiles.base)
                    setMultiTouchControls(true)
                    zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
                    minZoomLevel = 3.0
                    maxZoomLevel = 19.0
                    isTilesScaledToDpi = true
                    controller.setZoom(7.0)
                    controller.setCenter(GeoPoint(-6.2, 106.85)) // Jakarta
                    overlays.add(hazardOverlay)
                    overlays.add(windOverlay)
                    overlays.add(myLocOverlay)
                    overlays.add(pinOverlay)
                    overlays.add(MapEventsOverlay(tapReceiver))
                    addMapListener(
                        DelayedMapListener(
                            object : MapListener {
                                override fun onScroll(event: ScrollEvent?): Boolean {
                                    refreshWind(this@apply)
                                    refreshFires(this@apply)
                                    return false
                                }

                                override fun onZoom(event: ZoomEvent?): Boolean {
                                    refreshWind(this@apply)
                                    refreshFires(this@apply)
                                    return false
                                }
                            },
                            800,
                        )
                    )
                    post { map = this }
                }
            },
            onRelease = { it.onDetach() },
        )

        // Header biru: pencarian + lapisan; di bawahnya catatan dan kontrol radar
        Column(Modifier.fillMaxWidth()) {
            BlueHeader {
                SearchBar(
                    query = query,
                    onQuery = { query = it },
                    results = results,
                    onPick = { p ->
                        query = ""
                        results = emptyList()
                        map?.controller?.setZoom(9.0)
                        select(p.lat, p.lon, p.name)
                    },
                )
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    LayerChip("Radar", radarOn, { radarOn = !radarOn; if (!radarOn) playing = false }) {
                        WeatherIcon(61, true, 20.dp)
                    }
                    LayerChip(tr("Angin", "Wind"), windOn, { windOn = !windOn }) { fg -> WindGlyph(fg, 18.dp) }
                    LayerChip(tr("Badai", "Storm"), stormOn, { stormOn = !stormOn }) { fg -> BoltGlyph(fg, 18.dp) }
                    LayerChip(tr("Peringatan", "Warnings"), alertOn, { alertOn = !alertOn }) { fg -> AlertGlyph(fg, 18.dp) }
                    LayerChip(tr("Gempa", "Quakes"), quakeOn, { quakeOn = !quakeOn }) { fg -> QuakeGlyph(fg, 18.dp) }
                    LayerChip(tr("Api", "Fire"), fireOn, { fireOn = !fireOn }) { fg -> FlameGlyph(fg, 18.dp) }
                }
            }
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                notice?.let {
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(C.Bg)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) { Txt(it, 12, C.Muted) }
                }
                if (radarOn && frames.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    RadarBar(frames, frameIdx.coerceIn(0, frames.lastIndex), playing) { playing = !playing }
                }
            }
        }

        // Tombol lokasi saya (disembunyikan saat panel prakiraan terbuka)
        if (pin == null) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(C.Bg)
                    .clickable {
                        if (LocationHelper.hasPermission(ctx)) locate()
                        else permLauncher.launch(
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                        )
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (locating) CircularProgressIndicator(color = C.Blue, strokeWidth = 2.5.dp, modifier = Modifier.size(24.dp))
                else LocateGlyph(C.Blue, 24.dp)
            }
        }

        // Atribusi saat panel tertutup
        if (pin == null) {
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(C.Bg.copy(alpha = 0.85f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Txt("© OpenStreetMap · Open-Meteo · MET Norway · RainViewer", 9, C.Muted)
            }
        }

        // Panel prakiraan per jam
        AnimatedVisibility(
            visible = pin != null,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            val p = pin
            ForecastSheet(
                place = placeName,
                lat = p?.latitude ?: 0.0,
                lon = p?.longitude ?: 0.0,
                forecast = forecast,
                air = air,
                marine = marine,
                comparison = comparison,
                loading = loading,
                error = error,
                onClose = { closeSheet() },
                onRetry = { p?.let { select(it.latitude, it.longitude, if (placeName.contains("…")) null else placeName) } },
                actions = {
                    PillButton(tr("Simpan ke favorit", "Save to favorites"), C.Brand, Color.White, Modifier.fillMaxWidth()) { saveFavorite() }
                },
            )
        }
    }
}

// Kolom pencarian selalu putih (di atas header biru), jadi warnanya tetap di kedua tema.
private val SearchInk = Color(0xFF14181F)
private val SearchMuted = Color(0xFF5B6472)
private val SearchBlue = Color(0xFF1D4ED8)

@Composable
private fun SearchBar(
    query: String,
    onQuery: (String) -> Unit,
    results: List<Place>,
    onPick: (Place) -> Unit,
) {
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .height(50.dp)
                .clip(RoundedCornerShape(25.dp))
                .background(Color.White)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SearchGlyph(SearchBlue, 20.dp)
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) Txt(tr("Cari kota atau tempat", "Search for a city or place"), 15, SearchMuted)
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = SearchInk, fontSize = 15.sp),
                    cursorBrush = SolidColor(SearchBlue),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF3F4F7))
                        .clickable { onQuery("") },
                    contentAlignment = Alignment.Center,
                ) { CloseGlyph(SearchMuted, 11.dp) }
            }
        }
        if (results.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
            ) {
                results.forEach { p ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(p) }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Txt(p.name, 15, SearchInk, bold = true, maxLines = 1)
                        if (p.detail.isNotBlank()) Txt(p.detail, 12, SearchMuted, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun LayerChip(
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    icon: @Composable (Color) -> Unit,
) {
    // Di atas header biru: aktif = putih terisi dengan teks biru, tidak aktif = kaca transparan.
    val fg = if (active) C.Brand else Color.White
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (active) Color.White else Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon(fg)
        Spacer(Modifier.width(6.dp))
        Txt(label, 13, fg, bold = true)
    }
}

@Composable
private fun RadarBar(frames: List<RadarFrame>, idx: Int, playing: Boolean, onToggle: () -> Unit) {
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.US) }
    val f = frames.getOrNull(idx)
    Row(
        Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(C.Bg)
            .padding(start = 6.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(C.Brand)
                .clickable(onClick = onToggle),
            contentAlignment = Alignment.Center,
        ) {
            if (playing) PauseGlyph(Color.White, 14.dp) else PlayGlyph(Color.White, 14.dp)
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Txt(tr("Radar hujan", "Rain radar"), 11, C.Muted)
            val time = if (f != null) fmt.format(Date(f.time * 1000)) else "--:--"
            Txt(time + if (idx == frames.lastIndex) tr(" · terbaru", " · latest") else "", 14, bold = true)
        }
        Spacer(Modifier.width(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
            frames.forEachIndexed { i, _ ->
                Box(
                    Modifier
                        .size(width = 5.dp, height = if (i == idx) 14.dp else 8.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (i == idx) C.Blue else C.Line)
                )
            }
        }
    }
}
