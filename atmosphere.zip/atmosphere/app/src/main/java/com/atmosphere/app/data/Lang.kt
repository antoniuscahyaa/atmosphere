package com.atmosphere.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/**
 * Pilihan bahasa aplikasi: 0 = ikuti sistem, 1 = Indonesia, 2 = English.
 * [mode] adalah state Compose, jadi semua layar yang memanggil [tr] otomatis
 * tergambar ulang saat bahasa diganti (tanpa restart).
 */
object Lang {
    var mode by mutableIntStateOf(0)

    /** Mode "sistem": bahasa Indonesia jika bahasa HP Indonesia, selain itu English. */
    val isIndonesian: Boolean
        get() = when (mode) {
            1 -> true
            2 -> false
            else -> Locale.getDefault().language.let { it == "id" || it == "in" }
        }

    /** Kode bahasa untuk API (pencarian kota, nama tempat) dan format tanggal. */
    val code: String get() = if (isIndonesian) "id" else "en"

    val locale: Locale get() = Locale.forLanguageTag(code)
}

/** Pilih teks sesuai bahasa aktif. Indonesia dulu, lalu English. */
fun tr(id: String, en: String): String = if (Lang.isIndonesian) id else en

/** Satuan kecepatan angin. */
val speedUnit: String get() = tr("km/j", "km/h")
