package com.atmosphere.app.ui

import com.atmosphere.app.data.Favorite
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.atmosphere.app.data.UserPrefs

/** Permintaan dari beranda ke layar peta. id berubah tiap permintaan agar selalu diproses ulang. */
data class MapRequest(
    val id: Int = 0,
    val lat: Double,
    val lon: Double,
    val name: String?,
    /** true = buka panel prakiraan di titik ini; false = hanya geser peta ke sini. */
    val openSheet: Boolean,
    /** true = pastikan lapisan radar menyala. */
    val radar: Boolean = false,
)

private const val TAB_HOME = 0
private const val TAB_MAP = 1
private const val TAB_SETTINGS = 2

/**
 * Kerangka aplikasi: tiga tab (Beranda, Peta, Pengaturan) dengan navigasi bawah.
 * Beranda tetap hidup di latar agar datanya tidak dimuat ulang tiap pindah tab;
 * peta baru dibuat saat pertama dibuka lalu dipertahankan.
 */
@Composable
fun AtmosphereRoot() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(TAB_HOME) }
    var mapVisited by remember { mutableStateOf(false) }
    var request by remember { mutableStateOf<MapRequest?>(null) }
    var counter by remember { mutableIntStateOf(0) }
    var showFavEditor by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<Favorite?>(null) }

    fun openMap(r: MapRequest?) {
        if (r != null) {
            counter++
            request = r.copy(id = counter)
        }
        mapVisited = true
        tab = TAB_MAP
    }

    BackHandler(enabled = tab == TAB_SETTINGS) { tab = TAB_HOME }
    // Terdaftar belakangan = diproses lebih dulu: detail ditutup dulu, lalu layar Atur.
    BackHandler(enabled = showFavEditor) { showFavEditor = false }
    BackHandler(enabled = detail != null) { detail = null }

    Column(Modifier.fillMaxSize().background(C.Bg)) {
        Box(Modifier.weight(1f)) {
            if (mapVisited) {
                AtmosphereApp(request = request, active = tab == TAB_MAP, onHome = { tab = TAB_HOME })
            }
            HomeScreen(
                active = tab == TAB_HOME,
                modifier = if (tab == TAB_HOME) Modifier.fillMaxSize() else Modifier.size(0.dp),
                onOpen = { openMap(it) },
                onFavorite = { detail = it },
                onEditFavorites = { showFavEditor = true },
            )
            if (tab == TAB_SETTINGS) SettingsScreen(Modifier.fillMaxSize(), onOpenFavorites = { showFavEditor = true })
            if (showFavEditor) {
                FavoritesScreen(
                    onBack = { showFavEditor = false },
                    onPickOnMap = {
                        showFavEditor = false
                        openMap(null)
                    },
                    modifier = Modifier.fillMaxSize(),
                )
            }
            detail?.let { fav ->
                FavoriteDetail(
                    fav = fav,
                    onClose = { detail = null },
                    onMap = { radar ->
                        detail = null
                        openMap(MapRequest(lat = fav.lat, lon = fav.lon, name = fav.place, openSheet = false, radar = radar))
                    },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        BottomNav(selected = tab) { i ->
            detail = null
            showFavEditor = false
            when (i) {
                TAB_MAP -> {
                    // Pertama kali dibuka lewat tab: pusatkan peta di lokasi terakhir yang diketahui.
                    val first = !mapVisited && request == null
                    val last = if (first) UserPrefs.lastLocation(ctx) else null
                    openMap(last?.let { MapRequest(lat = it.first, lon = it.second, name = null, openSheet = false) })
                }
                else -> tab = i
            }
        }
    }
}
