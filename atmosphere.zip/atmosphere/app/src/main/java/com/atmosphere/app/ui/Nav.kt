package com.atmosphere.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

/** Permintaan dari beranda ke layar peta. id berubah tiap permintaan agar selalu diproses ulang. */
data class MapRequest(
    val id: Int = 0,
    val lat: Double,
    val lon: Double,
    val name: String?,
    /** true = buka panel prakiraan di titik ini; false = hanya geser peta ke sini. */
    val openSheet: Boolean,
    /** true = pastikan lapisan radar menyala. */
    val radar: Boolean = false,
)

/** Beranda adalah layar pertama. Peta baru dibuat saat pertama dibuka lalu dipertahankan. */
@Composable
fun AtmosphereRoot() {
    var onMap by remember { mutableStateOf(false) }
    var mapVisited by remember { mutableStateOf(false) }
    var request by remember { mutableStateOf<MapRequest?>(null) }
    var counter by remember { mutableIntStateOf(0) }

    Box(Modifier.fillMaxSize()) {
        if (mapVisited) {
            AtmosphereApp(request = request, active = onMap, onHome = { onMap = false })
        }
        if (!onMap) {
            HomeScreen(onOpen = { r ->
                counter++
                request = r.copy(id = counter)
                mapVisited = true
                onMap = true
            })
        }
    }
}
