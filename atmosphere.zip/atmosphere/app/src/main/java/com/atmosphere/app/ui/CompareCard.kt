package com.atmosphere.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.atmosphere.app.data.Comparison
import kotlin.math.roundToInt

/**
 * Kartu kecocokan antar sumber prakiraan: satu kalimat ringkas + indikator,
 * dan jika disentuh, tabel perbandingan per sumber.
 */
@Composable
fun SourceCompareCard(c: Comparison, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    val tone = if (c.agree) C.Teal else C.Gold
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(tone.copy(alpha = 0.12f))
            .clickable { open = !open }
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(tone)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) { Txt(if (c.agree) "Sepakat" else "Terbelah", 11, Color.White, bold = true) }
            Spacer(Modifier.width(8.dp))
            Txt("Kecocokan ${c.total} sumber prakiraan", 12, C.Muted, modifier = Modifier.weight(1f), maxLines = 1)
            Txt(if (open) "Tutup" else "Detail", 12, C.Blue, bold = true)
        }
        Spacer(Modifier.height(6.dp))
        Txt(c.headline, 15, bold = true)
        if (c.tempMin != null && c.tempMax != null) {
            val lo = c.tempMin.roundToInt()
            val hi = c.tempMax.roundToInt()
            Spacer(Modifier.height(2.dp))
            Txt(
                if (lo == hi) "Suhu sekarang ${lo}° di semua sumber" else "Suhu sekarang ${lo}°–${hi}° antar sumber",
                12, C.Muted,
            )
        }

        if (open) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) {
                Txt("Sumber", 11, C.Muted, modifier = Modifier.weight(1.5f))
                Txt("Suhu", 11, C.Muted, modifier = Modifier.weight(0.8f), align = TextAlign.End)
                Txt("Hujan mulai", 11, C.Muted, modifier = Modifier.weight(1.2f), align = TextAlign.End)
                Txt("Total", 11, C.Muted, modifier = Modifier.weight(1f), align = TextAlign.End)
            }
            Spacer(Modifier.height(4.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                c.sources.forEach { s ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Txt(s.name, 13, bold = true, modifier = Modifier.weight(1.5f), maxLines = 1)
                        Txt(s.temp?.let { "${it.roundToInt()}°" } ?: "–", 13, modifier = Modifier.weight(0.8f), align = TextAlign.End)
                        Txt(
                            s.firstRain ?: "Tidak",
                            13,
                            if (s.firstRain != null) C.Blue else C.Muted,
                            bold = s.firstRain != null,
                            modifier = Modifier.weight(1.2f),
                            align = TextAlign.End,
                        )
                        Txt("%.1f mm".format(s.rainMm), 13, modifier = Modifier.weight(1f), align = TextAlign.End)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Txt("Jendela 12 jam ke depan. Hujan = curah ≥ 0,2 mm per jam.", 10, C.Muted)
        }
    }
}
