package com.atmosphere.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.SideEffect
import com.atmosphere.app.data.Lang
import com.atmosphere.app.data.UserPrefs
import com.atmosphere.app.ui.AtmosphereRoot
import com.atmosphere.app.ui.AtmosphereTheme
import com.atmosphere.app.ui.C
import com.atmosphere.app.ui.ThemeState
import org.osmdroid.config.Configuration
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // osmdroid: simpan cache tile di cache internal (tidak butuh izin penyimpanan)
        Configuration.getInstance().apply {
            load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
            userAgentValue = packageName
            val base = File(cacheDir, "osmdroid")
            osmdroidBasePath = base
            osmdroidTileCache = File(base, "tiles")
            tileFileSystemCacheMaxBytes = 150L * 1024 * 1024
            tileFileSystemCacheTrimBytes = 100L * 1024 * 1024
        }

        ThemeState.mode = UserPrefs.theme(this)
        Lang.mode = UserPrefs.language(this)

        setContent {
            val dark = C.isDark
            // Status bar selalu di atas header biru (ikon terang); bilah navigasi mengikuti tema.
            SideEffect {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
                    navigationBarStyle = if (dark) SystemBarStyle.dark(Color.TRANSPARENT)
                    else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                )
            }
            AtmosphereTheme {
                AtmosphereRoot()
            }
        }
    }
}
