package com.atmosphere.app.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.atmosphere.app.data.AirQuality
import com.atmosphere.app.data.Compare
import com.atmosphere.app.data.Comparison
import com.atmosphere.app.data.FavSummary
import com.atmosphere.app.data.Favorite
import com.atmosphere.app.data.Favorites
import com.atmosphere.app.data.Forecast
import com.atmosphere.app.data.Geo
import com.atmosphere.app.data.LocationHelper
import com.atmosphere.app.data.Marine
import com.atmosphere.app.data.Place
import com.atmosphere.app.data.WeatherApi
import com.atmosphere.app.data.summarize
import com.atmosphere.app.data.tr
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun two(n: Int) = n.toString().padStart(2, '0')

private fun Favorite.key() = "$lat,$lon"

// ---------------------------------------------------------------------
// Beranda: bagian "Lokasi favorit" (kartu 2×2)
// ---------------------------------------------------------------------

/**
 * Kartu favorit di Beranda. [reload] berubah tiap Beranda dimuat ulang, supaya kartu ikut disegarkan.
 * Menyentuh kartu memanggil [onOpen]; "Atur" / kartu tambah memanggil [onEdit].
 */
@Composable
fun FavoritesSection(reload: Long, onOpen: (Favorite) -> Unit, onEdit: () -> Unit) {
    val favs = Favorites.items.toList()
    // Kunci ada tetapi nilai null = gagal dimuat; kunci belum ada = masih memuat.
    val summaries = remember { mutableStateMapOf<String, FavSummary?>() }

    LaunchedEffect(favs, reload) {
        val keep = favs.map { it.key() }.toSet()
        summaries.keys.toList().filter { it !in keep }.forEach { summaries.remove(it) }
        coroutineScope {
            favs.forEach { f ->
                launch {
                    val s = try {
                        summarize(WeatherApi.forecast(f.lat, f.lon))
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        null
                    }
                    // Jangan menimpa data lama dengan "gagal" saat penyegaran.
                    if (s != null || !summaries.containsKey(f.key())) summaries[f.key()] = s
                }
            }
        }
    }

    if (favs.isEmpty()) {
        Card {
            Txt(tr("Tambah lokasi favorit", "Add favorite locations"), 15, bold = true)
            Txt(
                tr(
                    "Pantau cuaca rumah, kantor, atau tempat lain sekali lihat.",
                    "Keep an eye on the weather at home, work, or anywhere else at a glance.",
                ),
                13, C.Muted,
            )
            Spacer(Modifier.height(10.dp))
            PillButton(tr("Tambah", "Add"), C.Brand, Color.White) { onEdit() }
        }
        return
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Txt(
                tr("Lokasi favorit", "Favorite locations"), 13, C.Blue, bold = true,
                modifier = Modifier.weight(1f).padding(start = 4.dp),
            )
            Txt(
                tr("Atur", "Edit"), 13, C.Blue, bold = true,
                modifier = Modifier.clickable(onClick = onEdit).padding(horizontal = 8.dp, vertical = 6.dp),
            )
        }
        val tiles = buildList<Favorite?> {
            addAll(favs)
            if (favs.size < Favorites.MAX) add(null)
        }
        tiles.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { f ->
                    if (f == null) {
                        AddTile(Modifier.weight(1f), onEdit)
                    } else {
                        FavCard(
                            fav = f,
                            loaded = summaries.containsKey(f.key()),
                            s = summaries[f.key()],
                            modifier = Modifier.weight(1f),
                        ) { onOpen(f) }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

/** Kartu mini: ikon | nama + jam hujan | suhu. Tinggi mengikuti isi (tidak dikunci), jadi teks tidak terpotong. */
@Composable
private fun FavCard(fav: Favorite, loaded: Boolean, s: FavSummary?, modifier: Modifier, onClick: () -> Unit) {
    val soon = s?.rainSoon == true
    val status = when {
        s == null -> if (loaded) tr("Gagal memuat", "Failed to load") else tr("Memuat…", "Loading…")
        s.firstRainHour != null -> tr("Hujan ${two(s.firstRainHour)}:00", "Rain ${two(s.firstRainHour)}:00")
        else -> describe(s.code)
    }
    Row(
        modifier
            .heightIn(min = 54.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (soon) C.Blue.copy(alpha = 0.12f) else C.Chip)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s != null) WeatherIcon(s.code, s.isDay, 26.dp) else Spacer(Modifier.size(26.dp))
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Txt(fav.label, 14, bold = true, maxLines = 1)
            Txt(status, 11, if (soon) C.Blue else C.Muted, bold = true, maxLines = 1)
        }
        Spacer(Modifier.width(6.dp))
        Txt(
            if (s != null) "${s.temp}°" else if (loaded) "–" else "…",
            18, if (s != null) C.Ink else C.Muted, bold = true,
        )
    }
}

@Composable
private fun AddTile(modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier
            .heightIn(min = 54.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(C.Chip)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Txt("+", 22, C.Blue, bold = true)
        Spacer(Modifier.width(8.dp))
        Txt(tr("Tambah lokasi", "Add location"), 13, C.Blue, bold = true, maxLines = 1)
    }
}

// ---------------------------------------------------------------------
// Detail: panel prakiraan lengkap saat kartu disentuh
// ---------------------------------------------------------------------

/** Lapisan penuh layar: latar redup + panel prakiraan (sama dengan panel di Peta) untuk satu favorit. */
@Composable
fun FavoriteDetail(
    fav: Favorite,
    onClose: () -> Unit,
    onMap: (radar: Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    var forecast by remember(fav) { mutableStateOf<Forecast?>(null) }
    var air by remember(fav) { mutableStateOf<AirQuality?>(null) }
    var marine by remember(fav) { mutableStateOf<Marine?>(null) }
    var comparison by remember(fav) { mutableStateOf<Comparison?>(null) }
    var error by remember(fav) { mutableStateOf<String?>(null) }
    var loading by remember(fav) { mutableStateOf(true) }
    var attempt by remember(fav) { mutableIntStateOf(0) }

    LaunchedEffect(fav, attempt) {
        loading = true
        error = null
        try {
            coroutineScope {
                val f = async { WeatherApi.forecast(fav.lat, fav.lon) }
                val a = async { WeatherApi.airQuality(fav.lat, fav.lon) }
                val w = async { WeatherApi.marine(fav.lat, fav.lon) }
                val ex = async {
                    val fc = f.await()
                    try {
                        WeatherApi.otherSources(fav.lat, fav.lon, fc.utcOffset)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
                val fc = f.await()
                forecast = fc
                air = a.await()
                marine = w.await()
                comparison = Compare.build(fc, ex.await())
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = tr(
                "Gagal memuat prakiraan. Periksa koneksi internet.",
                "Failed to load the forecast. Check your internet connection.",
            )
        }
        loading = false
    }

    Box(modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.45f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose)
        )
        ForecastSheet(
            place = fav.label,
            subtitle = fav.place,
            lat = fav.lat,
            lon = fav.lon,
            forecast = forecast,
            air = air,
            marine = marine,
            comparison = comparison,
            loading = loading,
            error = error,
            onClose = onClose,
            onRetry = { attempt++ },
            actions = {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton(tr("Buka di Peta", "Open in Map"), C.Brand, Color.White, Modifier.weight(1.5f)) { onMap(false) }
                    PillButton("Radar", C.Bg, C.Ink, Modifier.weight(1f)) { onMap(true) }
                }
            },
            modifier = Modifier.align(Alignment.BottomCenter),
        )
    }
}

// ---------------------------------------------------------------------
// Layar Atur lokasi favorit
// ---------------------------------------------------------------------

@Composable
fun FavoritesScreen(onBack: () -> Unit, onPickOnMap: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val items = Favorites.items

    var renaming by remember { mutableIntStateOf(-1) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Place>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun addPlace(label: String?, fallback: String, lat: Double, lon: Double) {
        if (items.any { Geo.distanceKm(it.lat, it.lon, lat, lon) < 0.3 }) {
            message = tr("Lokasi ini sudah ada di favorit", "This place is already in your favorites")
            return
        }
        scope.launch {
            busy = true
            // Nama sampai tingkat kelurahan/desa; jika gagal, pakai nama dari pencarian.
            val place = WeatherApi.reverseName(lat, lon) ?: fallback
            val name = (label ?: place.substringBefore(",")).trim().take(24)
            val ok = Favorites.add(ctx, Favorite(name, place, lat, lon))
            message = if (ok) null else tr("Favorit sudah penuh (maks 4)", "Favorites are full (max 4)")
            searching = false
            query = ""
            results = emptyList()
            busy = false
        }
    }

    fun useMyLocation() {
        scope.launch {
            busy = true
            val l = LocationHelper.current(ctx)
            busy = false
            if (l == null) {
                message = tr(
                    "Lokasi belum tersedia. Pastikan GPS/Lokasi aktif",
                    "Location unavailable. Make sure GPS/Location is turned on",
                )
            } else {
                addPlace(null, "%.3f, %.3f".format(l.latitude, l.longitude), l.latitude, l.longitude)
            }
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) useMyLocation()
        else message = tr("Izin lokasi ditolak", "Location permission denied")
    }

    LaunchedEffect(query) {
        if (query.trim().length < 2) {
            results = emptyList()
            return@LaunchedEffect
        }
        delay(350)
        results = try {
            WeatherApi.search(query.trim())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    Column(
        modifier
            .fillMaxSize()
            .background(C.Bg)
            // Menutupi layar di bawahnya: sentuhan tidak boleh tembus.
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .verticalScroll(rememberScrollState()),
    ) {
        BlueHeader {
            GlassButton(onClick = onBack) { BackGlyph(Color.White, 20.dp) }
            Spacer(Modifier.height(10.dp))
            Txt(tr("Lokasi favorit", "Favorite locations"), 30, Color.White, bold = true)
            Txt(
                tr("Pilih sampai 4 tempat dan beri nama sendiri", "Choose up to 4 places and name them yourself"),
                14, Color.White.copy(alpha = 0.85f),
            )
        }

        Column(
            Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            SectionTitle(
                tr(
                    "Urutan di Beranda · ${items.size} dari ${Favorites.MAX} terisi",
                    "Order on Home · ${items.size} of ${Favorites.MAX} filled",
                )
            )

            items.forEachIndexed { i, f ->
                Card {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Txt(
                                "▲", 12, if (i > 0) C.Blue else C.Line,
                                modifier = Modifier
                                    .clickable(enabled = i > 0) { Favorites.move(ctx, i, -1) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                            )
                            Txt(
                                "▼", 12, if (i < items.size - 1) C.Blue else C.Line,
                                modifier = Modifier
                                    .clickable(enabled = i < items.size - 1) { Favorites.move(ctx, i, 1) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                            )
                        }
                        Spacer(Modifier.width(6.dp))
                        Column(Modifier.weight(1f)) {
                            Txt(f.label, 16, bold = true, maxLines = 1)
                            Txt(f.place, 13, C.Muted, maxLines = 2)
                        }
                        Txt(
                            tr("Ubah", "Rename"), 13, C.Blue, bold = true,
                            modifier = Modifier.clickable { renaming = i }.padding(10.dp),
                        )
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).clickable { Favorites.remove(ctx, i) },
                            contentAlignment = Alignment.Center,
                        ) { CloseGlyph(C.Muted, 14.dp) }
                    }
                }
            }

            if (items.size < Favorites.MAX) {
                Card {
                    Txt(
                        tr("Tambah lokasi ke-${items.size + 1}", "Add location ${items.size + 1}"),
                        15, C.Blue, bold = true,
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChipButton(tr("Cari kota", "Search"), Modifier.weight(1f)) { searching = !searching }
                        ChipButton(tr("Pilih di peta", "On map"), Modifier.weight(1f)) {
                            Favorites.mapHint = true
                            onPickOnMap()
                        }
                        ChipButton(tr("Lokasi saya", "My location"), Modifier.weight(1f)) {
                            if (LocationHelper.hasPermission(ctx)) useMyLocation()
                            else permLauncher.launch(
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                            )
                        }
                    }
                    if (searching) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            placeholder = { Text(tr("Cari kota atau tempat", "Search for a city or place")) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        results.forEach { p ->
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        addPlace(
                                            p.name,
                                            listOf(p.name, p.detail).filter { it.isNotBlank() }.joinToString(", "),
                                            p.lat, p.lon,
                                        )
                                    }
                                    .padding(vertical = 8.dp),
                            ) {
                                Txt(p.name, 14, bold = true, maxLines = 1)
                                if (p.detail.isNotBlank()) Txt(p.detail, 12, C.Muted, maxLines = 1)
                            }
                        }
                    }
                }
            }

            if (busy) Txt(tr("Memproses…", "Working…"), 12, C.Muted)
            message?.let { Txt(it, 12, C.Gold, bold = true) }
            Txt(
                tr(
                    "Sentuh kartu di Beranda untuk membuka prakiraan lengkap. Gunakan ▲ ▼ untuk mengubah urutan.",
                    "Tap a card on Home to open the full forecast. Use ▲ ▼ to change the order.",
                ),
                12, C.Muted,
            )
            PillButton(tr("Selesai", "Done"), C.Brand, Color.White, Modifier.fillMaxWidth(), onBack)
        }
    }

    if (renaming in items.indices) {
        val idx = renaming
        var draft by remember(idx) { mutableStateOf(items[idx].label) }
        AlertDialog(
            onDismissRequest = { renaming = -1 },
            title = { Text(tr("Nama lokasi", "Location name")) },
            text = {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it.take(24) },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val old = items[idx]
                    Favorites.update(ctx, idx, old.copy(label = draft.trim().ifBlank { old.label }))
                    renaming = -1
                }) { Text(tr("Simpan", "Save")) }
            },
            dismissButton = { TextButton(onClick = { renaming = -1 }) { Text(tr("Batal", "Cancel")) } },
        )
    }
}

@Composable
private fun ChipButton(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(C.Bg)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) { Txt(label, 13, C.Ink, bold = true, maxLines = 1, align = TextAlign.Center) }
}
