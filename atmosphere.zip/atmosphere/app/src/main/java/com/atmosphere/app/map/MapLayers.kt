package com.atmosphere.app.map

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.graphics.Typeface
import com.atmosphere.app.data.FireSpot
import com.atmosphere.app.data.Quake
import com.atmosphere.app.data.WeatherAlert
import com.atmosphere.app.data.WindPoint
import org.osmdroid.tileprovider.MapTileProviderBasic
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.TilesOverlay

object Tiles {
    /**
     * Basemap OpenStreetMap standar (gratis, tanpa key). CARTO Voyager sebelumnya dipakai tetapi
     * sekarang meminta API key (tile berubah jadi watermark "API KEY REQUIRED").
     * Kebijakan OSM: pemakaian wajar + User-Agent jelas (sudah diset di MainActivity) + atribusi.
     */
    val base = XYTileSource(
        "OSMStandard", 0, 19, 256, ".png",
        arrayOf("https://tile.openstreetmap.org/"),
        "© OpenStreetMap contributors",
    )
}

/**
 * Tile radar RainViewer. Tier gratis dibatasi zoom maksimum 7 (osmdroid akan
 * memperbesar tile saat peta di-zoom lebih dekat).
 * Skema warna 2 = "Universal Blue". Ubah RADAR_COLOR jika tile kosong.
 */
class RadarTileSource(private val host: String, private val path: String) :
    OnlineTileSourceBase("rv" + path.substringAfterLast('/'), 0, 7, 256, ".png", arrayOf(host)) {

    override fun getTileURLString(pMapTileIndex: Long): String {
        val z = MapTileIndex.getZoom(pMapTileIndex)
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        return "$host$path/256/$z/$x/$y/$RADAR_COLOR/1_1.png"
    }

    companion object {
        const val RADAR_COLOR = 2
    }
}

/** Mengelola satu overlay radar yang diganti tiap frame (animasi). */
class RadarLayer {
    private var overlay: TilesOverlay? = null
    private var shownPath: String? = null

    fun show(map: MapView, host: String, path: String) {
        if (shownPath == path && overlay != null) return
        detach(map)
        val ctx = map.context
        val provider = MapTileProviderBasic(ctx, RadarTileSource(host, path))
        val o = TilesOverlay(provider, ctx)
        o.loadingBackgroundColor = Color.TRANSPARENT
        o.loadingLineColor = Color.TRANSPARENT
        o.setColorFilter(ColorMatrixColorFilter(ColorMatrix().apply { setScale(1f, 1f, 1f, 0.8f) }))
        map.overlays.add(0, o)
        overlay = o
        shownPath = path
        map.invalidate()
        map.postDelayed({ map.invalidate() }, 700)
        map.postDelayed({ map.invalidate() }, 2000)
    }

    fun clear(map: MapView) {
        detach(map)
        map.invalidate()
    }

    private fun detach(map: MapView) {
        overlay?.let {
            map.overlays.remove(it)
            it.onDetach(map)
        }
        overlay = null
        shownPath = null
    }
}

fun windColor(kmh: Double): Int = when {
    kmh < 8 -> 0xFF4CC9F0
    kmh < 20 -> 0xFF2EC4B6
    kmh < 35 -> 0xFFFFB703
    kmh < 50 -> 0xFFFB5607
    else -> 0xFFE63946
}.toInt()

/** Panah arah angin (berwarna menurut kecepatan) + penanda badai petir. */
class WindOverlay : Overlay() {
    var points: List<WindPoint> = emptyList()
    var showWind = true
    var showStorm = true

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val path = Path()
    private val pt = Point()

    override fun draw(c: Canvas, map: MapView, shadow: Boolean) {
        if (shadow || points.isEmpty() || (!showWind && !showStorm)) return
        val d = map.resources.displayMetrics.density
        val pj = map.projection
        for (p in points) {
            pj.toPixels(GeoPoint(p.lat, p.lon), pt)
            if (pt.x < -60 * d || pt.y < -60 * d || pt.x > map.width + 60 * d || pt.y > map.height + 60 * d) continue
            if (showWind) drawWind(c, pt.x.toFloat(), pt.y.toFloat(), d, p)
            if (showStorm && p.code >= 95) {
                val off = if (showWind) 16f * d else 0f
                drawStorm(c, pt.x + off, pt.y - off, d)
            }
        }
    }

    /**
     * Panah ramping tanpa lingkaran latar: warna & panjang menurut kecepatan, dengan garis tepi putih
     * tipis agar terbaca di atas peta. Angka kecepatan tidak digambar (warna sudah mewakili).
     */
    private fun drawWind(c: Canvas, x: Float, y: Float, d: Float, p: WindPoint) {
        val len = (12f + (p.speed / 40.0).coerceIn(0.0, 1.0).toFloat() * 14f) * d // 12..26 dp
        val head = 6.5f * d
        val col = windColor(p.speed)
        c.save()
        c.translate(x, y)
        // dir = arah asal angin -> panah menunjuk ke arah angin bertiup
        c.rotate((p.dir + 180.0).toFloat())
        val tail = len / 2
        val tip = -len / 2
        path.reset()
        path.moveTo(0f, tip)
        path.lineTo(-head * 0.7f, tip + head)
        path.lineTo(head * 0.7f, tip + head)
        path.close()
        for (pass in 0..1) {
            val halo = pass == 0
            stroke.color = if (halo) 0xCCFFFFFF.toInt() else col
            stroke.strokeWidth = (if (halo) 5f else 2.6f) * d
            c.drawLine(0f, tail, 0f, tip + head * 0.6f, stroke)
            fill.style = if (halo) Paint.Style.FILL_AND_STROKE else Paint.Style.FILL
            fill.strokeWidth = 3f * d
            fill.strokeJoin = Paint.Join.ROUND
            fill.color = if (halo) 0xCCFFFFFF.toInt() else col
            c.drawPath(path, fill)
        }
        fill.style = Paint.Style.FILL
        c.restore()
    }

    private fun drawStorm(c: Canvas, x: Float, y: Float, d: Float) {
        val r = 12f * d
        fill.style = Paint.Style.FILL
        fill.color = 0xFF8338EC.toInt()
        c.drawCircle(x, y, r, fill)
        val s = r * 0.7f
        path.reset()
        path.moveTo(x + 0.12f * s * 2, y - 0.5f * s * 2)
        path.lineTo(x - 0.28f * s * 2, y + 0.04f * s * 2)
        path.lineTo(x - 0.02f * s * 2, y + 0.04f * s * 2)
        path.lineTo(x - 0.14f * s * 2, y + 0.5f * s * 2)
        path.lineTo(x + 0.28f * s * 2, y - 0.08f * s * 2)
        path.lineTo(x + 0.02f * s * 2, y - 0.08f * s * 2)
        path.close()
        fill.color = 0xFFFFC400.toInt()
        c.drawPath(path, fill)
    }
}

/** Pin lokasi yang dipilih (ujung pin tepat di titik yang disentuh). */
class PinOverlay : Overlay() {
    var point: GeoPoint? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val pt = Point()

    override fun draw(c: Canvas, map: MapView, shadow: Boolean) {
        val p = point ?: return
        if (shadow) return
        val d = map.resources.displayMetrics.density
        map.projection.toPixels(p, pt)
        val x = pt.x.toFloat()
        val y = pt.y.toFloat()
        val r = 13f * d
        val cy = y - r * 2.1f

        fill.style = Paint.Style.FILL
        fill.color = 0xFFFF006E.toInt()
        path.reset()
        path.moveTo(x, y)
        path.lineTo(x - r * 0.85f, cy + r * 0.5f)
        path.lineTo(x + r * 0.85f, cy + r * 0.5f)
        path.close()
        c.drawPath(path, fill)
        c.drawCircle(x, cy, r, fill)
        fill.color = Color.WHITE
        c.drawCircle(x, cy, r * 0.42f, fill)
    }
}

/** Warna gempa menurut magnitudo. */
fun quakeColor(mag: Double): Int = when {
    mag < 4.0 -> 0xFFFFB703
    mag < 5.0 -> 0xFFFB5607
    mag < 6.0 -> 0xFFE63946
    else -> 0xFF9D0208
}.toInt()

/** Poligon peringatan dini BMKG, titik api FIRMS, dan lingkaran gempa. Digambar di bawah angin/pin. */
class HazardOverlay : Overlay() {
    var alerts: List<WeatherAlert> = emptyList()
    var fires: List<FireSpot> = emptyList()
    var quakes: List<Quake> = emptyList()
    var showAlerts = false
    var showFires = false
    var showQuakes = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val path = Path()
    private val pt = Point()

    override fun draw(c: Canvas, map: MapView, shadow: Boolean) {
        if (shadow) return
        val d = map.resources.displayMetrics.density
        val pj = map.projection
        if (showAlerts) for (a in alerts) drawAlert(c, pj, a, d)
        if (showFires) for (f in fires) {
            pj.toPixels(GeoPoint(f.lat, f.lon), pt)
            if (pt.x < -20 * d || pt.y < -20 * d || pt.x > map.width + 20 * d || pt.y > map.height + 20 * d) continue
            fill.style = Paint.Style.FILL
            fill.color = Color.WHITE
            c.drawCircle(pt.x.toFloat(), pt.y.toFloat(), 5.5f * d, fill)
            fill.color = if (f.high) 0xFFE63946.toInt() else 0xFFFB5607.toInt()
            c.drawCircle(pt.x.toFloat(), pt.y.toFloat(), 4f * d, fill)
        }
        if (showQuakes) for (q in quakes) {
            pj.toPixels(GeoPoint(q.lat, q.lon), pt)
            if (pt.x < -40 * d || pt.y < -40 * d || pt.x > map.width + 40 * d || pt.y > map.height + 40 * d) continue
            val r = (9f + (q.mag - 3.0).coerceIn(0.0, 5.0).toFloat() * 3f) * d
            val x = pt.x.toFloat()
            val y = pt.y.toFloat()
            val col = quakeColor(q.mag)
            fill.style = Paint.Style.FILL
            fill.color = (col and 0x00FFFFFF) or 0x44000000
            c.drawCircle(x, y, r * 1.7f, fill)
            fill.color = col
            c.drawCircle(x, y, r, fill)
            line.color = Color.WHITE
            line.strokeWidth = 2f * d
            c.drawCircle(x, y, r, line)
            text.color = Color.WHITE
            text.textSize = 10.5f * d
            c.drawText("%.1f".format(q.mag), x, y + 3.6f * d, text)
        }
    }

    private fun drawAlert(c: Canvas, pj: org.osmdroid.views.Projection, a: WeatherAlert, d: Float) {
        val col = when (a.severity.lowercase()) {
            "extreme", "severe" -> 0xFFE63946
            "moderate" -> 0xFFFB5607
            else -> 0xFFFFB703
        }.toInt()
        for (poly in a.polygons) {
            path.reset()
            poly.forEachIndexed { i, (la, lo) ->
                pj.toPixels(GeoPoint(la, lo), pt)
                if (i == 0) path.moveTo(pt.x.toFloat(), pt.y.toFloat()) else path.lineTo(pt.x.toFloat(), pt.y.toFloat())
            }
            path.close()
            fill.style = Paint.Style.FILL
            fill.color = (col and 0x00FFFFFF) or 0x40000000
            c.drawPath(path, fill)
            line.color = col
            line.strokeWidth = 2f * d
            c.drawPath(path, line)
        }
    }
}

/** Titik biru lokasi saya + lingkaran akurasi. */
class MyLocationOverlay : Overlay() {
    var point: GeoPoint? = null
    var accuracyM: Float = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pt = Point()

    override fun draw(c: Canvas, map: MapView, shadow: Boolean) {
        val p = point ?: return
        if (shadow) return
        val d = map.resources.displayMetrics.density
        map.projection.toPixels(p, pt)
        val x = pt.x.toFloat()
        val y = pt.y.toFloat()
        val mpp = map.projection.metersToPixels(accuracyM.coerceAtMost(5000f))
        if (mpp > 12f * d) {
            fill.style = Paint.Style.FILL
            fill.color = 0x223A86FF
            c.drawCircle(x, y, mpp, fill)
        }
        fill.style = Paint.Style.FILL
        fill.color = Color.WHITE
        c.drawCircle(x, y, 10f * d, fill)
        fill.color = 0xFF3A86FF.toInt()
        c.drawCircle(x, y, 7f * d, fill)
    }
}
