package com.atmosphere.app.data

import java.time.LocalDateTime
import java.time.ZoneOffset

/** Satu jam prakiraan dari satu sumber (waktu lokal lokasi). Nilai null = sumber tidak menyediakan. */
data class SrcHour(val date: String, val hour: Int, val temp: Double?, val rain: Double?, val wind: Double?)

/** Prakiraan per jam dari satu sumber/model. */
data class SourceForecast(val name: String, val hours: List<SrcHour>)

/** Baris ringkasan satu sumber untuk tabel perbandingan. */
data class SourceView(
    val name: String,
    val temp: Double?,
    val wind: Double?,
    /** Jam hujan pertama dalam jendela, mis. "15:00"; null = tidak hujan. */
    val firstRain: String?,
    val rainMm: Double,
)

/** Rata-rata hujan antar sumber untuk satu jam. */
data class HourAgg(val date: String, val hour: Int, val meanRain: Double, val rainSources: Int)

data class Comparison(
    val total: Int,
    val rainCount: Int,
    /** Jam (0-23) perkiraan mulai hujan menurut median sumber; null jika tidak ada yang memprediksi hujan. */
    val rainHour: Int?,
    /** true jika semua sumber sepakat (semua hujan / semua tidak hujan). */
    val agree: Boolean,
    val sources: List<SourceView>,
    val tempMin: Double?,
    val tempMax: Double?,
    val hourly: List<HourAgg>,
) {
    /** Ringkasan satu kalimat. Dihitung saat dibaca agar ikut bahasa yang sedang dipilih. */
    val headline: String
        get() {
            val h = (rainHour ?: 0).toString().padStart(2, '0')
            return when {
                rainCount == 0 -> tr(
                    "Semua $total sumber setuju: tidak ada hujan ${Compare.WINDOW} jam ke depan",
                    "All $total sources agree: no rain in the next ${Compare.WINDOW} hours",
                )
                rainCount == total -> tr(
                    "Semua $total sumber setuju: hujan sekitar $h:00",
                    "All $total sources agree: rain around $h:00",
                )
                else -> tr(
                    "$rainCount dari $total sumber memprediksi hujan sekitar $h:00",
                    "$rainCount of $total sources predict rain around $h:00",
                )
            }
        }
}

object Compare {
    /** Jam dianggap hujan jika curah >= nilai ini (mm per jam). */
    const val RAIN_MM = 0.2

    /** Panjang jendela perbandingan (jam, mulai dari jam sekarang). */
    const val WINDOW = 12

    private fun two(n: Int) = n.toString().padStart(2, '0')

    /** Nomor jam absolut dari tanggal "yyyy-MM-dd" + jam, agar mudah dibandingkan antar sumber. */
    private fun idx(date: String, hour: Int): Long =
        LocalDateTime.parse("${date}T${two(hour)}:00").toEpochSecond(ZoneOffset.UTC) / 3600

    private fun hourOf(idx: Long): Int = LocalDateTime.ofEpochSecond(idx * 3600, 0, ZoneOffset.UTC).hour
    private fun dateOf(idx: Long): String = LocalDateTime.ofEpochSecond(idx * 3600, 0, ZoneOffset.UTC).toLocalDate().toString()

    fun mainSource(f: Forecast) = SourceForecast(
        "Open-Meteo",
        f.hours.map { SrcHour(it.date, it.hour, it.temp, it.rain, it.wind) },
    )

    /**
     * Gabungkan Open-Meteo (utama) dengan sumber lain. Mengembalikan null jika hanya ada satu
     * sumber yang bisa dipakai (tidak ada yang dibandingkan).
     */
    fun build(f: Forecast, extra: List<SourceForecast>): Comparison? {
        val start = idx(f.now.date, f.now.hour)
        val end = start + WINDOW - 1
        val perSource = (listOf(mainSource(f)) + extra).mapNotNull { s ->
            val byIdx = HashMap<Long, SrcHour>()
            for (h in s.hours) runCatching { byIdx[idx(h.date, h.hour)] = h }
            // Sumber tanpa data hujan sama sekali di jendela ini tidak bisa dibandingkan.
            if ((start..end).none { byIdx[it]?.rain != null }) null else s.name to byIdx
        }
        if (perSource.size < 2) return null

        val views = ArrayList<SourceView>()
        val firstIdx = ArrayList<Long>()
        for ((name, m) in perSource) {
            var first: Long? = null
            var sum = 0.0
            for (i in start..end) {
                val r = m[i]?.rain ?: continue
                sum += r
                if (first == null && r >= RAIN_MM) first = i
            }
            if (first != null) firstIdx += first
            views += SourceView(
                name = name,
                temp = m[start]?.temp,
                wind = m[start]?.wind,
                firstRain = first?.let { "${two(hourOf(it))}:00" },
                rainMm = sum,
            )
        }

        val total = views.size
        val rainCount = firstIdx.size
        val rainHour = firstIdx.sorted().getOrNull(rainCount / 2)?.let { hourOf(it) }
        val temps = views.mapNotNull { it.temp }

        val hourly = (start..end).map { i ->
            val rains = perSource.mapNotNull { it.second[i]?.rain }
            HourAgg(
                date = dateOf(i),
                hour = hourOf(i),
                meanRain = if (rains.isEmpty()) 0.0 else rains.average(),
                rainSources = rains.count { it >= RAIN_MM },
            )
        }
        return Comparison(
            total = total,
            rainCount = rainCount,
            rainHour = rainHour,
            agree = rainCount == 0 || rainCount == total,
            sources = views,
            tempMin = temps.minOrNull(),
            tempMax = temps.maxOrNull(),
            hourly = hourly,
        )
    }

    /** Seri hujan per jam untuk grafik; jika tidak ada perbandingan, pakai Open-Meteo saja. */
    fun rainSeries(f: Forecast, c: Comparison?): List<HourAgg> {
        if (c != null) return c.hourly
        val start = idx(f.now.date, f.now.hour)
        return f.hours.filter { idx(it.date, it.hour) in start until start + WINDOW }.map {
            HourAgg(it.date, it.hour, it.rain, if (it.rain >= RAIN_MM) 1 else 0)
        }
    }

    /** Satu kalimat soal hujan untuk kartu utama. */
    fun rainSentence(f: Forecast, c: Comparison?): String {
        if (c != null) {
            return if (c.rainHour == null) tr("Tidak ada hujan $WINDOW jam ke depan", "No rain in the next $WINDOW hours")
            else tr("Hujan diperkirakan sekitar ${two(c.rainHour)}:00", "Rain expected around ${two(c.rainHour)}:00")
        }
        val first = rainSeries(f, null).firstOrNull { it.rainSources > 0 }
        return if (first == null) tr("Tidak ada hujan $WINDOW jam ke depan", "No rain in the next $WINDOW hours")
        else tr("Hujan diperkirakan sekitar ${two(first.hour)}:00", "Rain expected around ${two(first.hour)}:00")
    }
}
