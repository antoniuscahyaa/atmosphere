package com.atmosphere.app.ui

import com.atmosphere.app.data.Lang
import com.atmosphere.app.data.tr
import com.atmosphere.app.data.speedUnit
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.atmosphere.app.data.AirQuality
import com.atmosphere.app.data.Comparison
import com.atmosphere.app.data.Forecast
import com.atmosphere.app.data.Marine
import com.atmosphere.app.data.Hour
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

private fun two(n: Int) = n.toString().padStart(2, '0')
private fun hm(iso: String) = if (iso.length >= 16) iso.substring(11, 16) else iso

private fun dateLabel(date: String): String = try {
    LocalDate.parse(date).format(DateTimeFormatter.ofPattern(tr("EEE, d MMM", "EEE, MMM d"), Lang.locale))
} catch (e: Exception) {
    date
}

@Composable
fun ForecastSheet(
    place: String,
    lat: Double,
    lon: Double,
    forecast: Forecast?,
    air: AirQuality?,
    marine: Marine?,
    comparison: Comparison? = null,
    loading: Boolean,
    error: String?,
    onClose: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .fillMaxWidth()
            .heightIn(max = 520.dp)
            .clip(RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp))
            .background(C.Bg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp)
            .padding(top = 10.dp, bottom = 14.dp),
    ) {
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .size(width = 40.dp, height = 4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(C.Line)
        )
        Spacer(Modifier.height(10.dp))

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt(place, 20, bold = true, maxLines = 1)
                Txt("%.3f°, %.3f°".format(lat, lon), 12, C.Muted)
            }
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(C.Chip)
                    .clickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { CloseGlyph(C.Muted, 12.dp) }
        }
        Spacer(Modifier.height(12.dp))

        when {
            forecast != null -> ForecastContent(forecast, air, marine, comparison)
            error != null -> {
                Txt(error, 14, C.Muted, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .clip(RoundedCornerShape(20.dp))
                        .background(C.Brand)
                        .clickable(onClick = onRetry)
                        .padding(horizontal = 20.dp, vertical = 10.dp)
                ) { Txt(tr("Coba lagi", "Try again"), 14, Color.White, bold = true) }
            }

            loading -> Box(Modifier.fillMaxWidth().height(140.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = C.Blue, strokeWidth = 3.dp)
            }
        }

        Spacer(Modifier.height(12.dp))
        Txt("Data: Open-Meteo (ECMWF, DWD ICON, NOAA GFS) · MET Norway · RainViewer · BMKG · NASA FIRMS · © OpenStreetMap", 10, C.Muted)
    }
}

@Composable
private fun ForecastContent(f: Forecast, air: AirQuality?, marine: Marine?, comparison: Comparison?) {
    var dayIdx by remember(f) { mutableIntStateOf(0) }
    val day = f.days.getOrNull(dayIdx) ?: f.days.first()
    val hours = remember(f, dayIdx) { f.hours.filter { it.date == day.date } }
    val now = f.now

    // Ringkasan saat ini
    Row(verticalAlignment = Alignment.CenterVertically) {
        WeatherIcon(now.code, now.isDay, 76.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Txt("${now.temp.roundToInt()}°", 52, bold = true)
            Txt(describe(now.code), 15, C.Muted)
        }
        Column(horizontalAlignment = Alignment.End) {
            Txt(tr("Terasa ${now.feels.roundToInt()}°", "Feels like ${now.feels.roundToInt()}°"), 13, C.Muted)
            Txt(tr("Maks ${day.max.roundToInt()}° · Min ${day.min.roundToInt()}°", "High ${day.max.roundToInt()}° · Low ${day.min.roundToInt()}°"), 14, bold = true)
            Txt(tr("Terbit ${hm(day.sunrise)} · Terbenam ${hm(day.sunset)}", "Sunrise ${hm(day.sunrise)} · Sunset ${hm(day.sunset)}"), 11, C.Muted)
        }
    }

    // Peringatan badai
    val storm = hours.filter { it.code >= 95 || (it.cape >= 2000 && it.rainProb >= 50) }
    if (storm.isNotEmpty()) {
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(C.Purple.copy(alpha = 0.12f))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BoltGlyph(C.Purple, 20.dp)
            Spacer(Modifier.width(8.dp))
            Txt(
                tr(
                    "Potensi badai petir ${two(storm.first().hour)}:00–${two(storm.last().hour)}:00",
                    "Possible thunderstorms ${two(storm.first().hour)}:00–${two(storm.last().hour)}:00",
                ),
                13, C.Purple, bold = true,
            )
        }
    }

    // Kecocokan antar sumber prakiraan
    if (comparison != null) {
        Spacer(Modifier.height(12.dp))
        SourceCompareCard(comparison)
    }

    // Statistik
    Spacer(Modifier.height(14.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatTile(tr("Angin", "Wind"), "${now.wind.roundToInt()} $speedUnit", tr("dari ${compass(now.windDir)}", "from ${compass(now.windDir)}"), C.Teal)
        StatTile(tr("Hembusan", "Gusts"), "${now.gust.roundToInt()} $speedUnit", tr("maks saat ini", "current max"), C.Orange)
        StatTile(tr("Lembap", "Humidity"), "${now.humidity}%", tr("kelembapan", "relative humidity"), C.Blue)
        StatTile(tr("Tekanan", "Pressure"), "${now.pressure.roundToInt()} hPa", tr("permukaan laut", "sea level"), C.Purple)
        StatTile(tr("UV maks", "Max UV"), "${day.uvMax.roundToInt()}", tr("indeks UV", "UV index"), C.Gold)
        StatTile(tr("Hujan", "Rain"), "%.1f mm".format(hours.sumOf { it.rain }), tr("total hari ini", "total today"), C.Blue)
        if (air != null) {
            val (label, col) = aqiInfo(air.aqi)
            StatTile(tr("Kualitas udara", "Air quality"), "AQI ${air.aqi}", label, col)
            StatTile("PM2.5", "%.0f µg/m³".format(air.pm25), "PM10 %.0f".format(air.pm10), col)
        }
        if (marine != null) {
            StatTile(tr("Gelombang", "Waves"), "%.1f m".format(marine.height), tr("periode %.0f dtk", "period %.0f s").format(marine.period), C.Teal)
        }
    }

    // Pemilih hari
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        f.days.forEachIndexed { i, d ->
            val sel = i == dayIdx
            Box(
                Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(if (sel) C.Brand else C.Chip)
                    .clickable { dayIdx = i }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                val label = when (i) {
                    0 -> tr("Hari ini", "Today")
                    1 -> tr("Besok", "Tomorrow")
                    else -> dateLabel(d.date)
                }
                Txt(label, 13, if (sel) Color.White else C.Ink, bold = true)
            }
        }
    }

    // Per jam
    Spacer(Modifier.height(12.dp))
    Txt(tr("Per jam · ${dateLabel(day.date)}", "Hourly · ${dateLabel(day.date)}"), 14, bold = true)
    Spacer(Modifier.height(8.dp))

    val listState = rememberLazyListState()
    val nowIdx = hours.indexOfFirst { it.date == now.date && it.hour == now.hour }
    LaunchedEffect(f, dayIdx) {
        listState.scrollToItem(if (nowIdx > 1) nowIdx - 1 else 0)
    }
    LazyRow(state = listState, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(hours) { h -> HourCard(h, h.date == now.date && h.hour == now.hour) }
    }
}

@Composable
internal fun aqiInfo(aqi: Int): Pair<String, Color> = when {
    aqi <= 50 -> tr("Baik", "Good") to Color(0xFF2EC4B6)
    aqi <= 100 -> tr("Sedang", "Moderate") to Color(0xFFD98E00)
    aqi <= 150 -> tr("Tidak sehat (sensitif)", "Unhealthy for sensitive groups") to Color(0xFFFB5607)
    aqi <= 200 -> tr("Tidak sehat", "Unhealthy") to Color(0xFFE63946)
    aqi <= 300 -> tr("Sangat tidak sehat", "Very unhealthy") to Color(0xFF8338EC)
    else -> tr("Berbahaya", "Hazardous") to Color(0xFF9D0208)
}

@Composable
internal fun StatTile(label: String, value: String, sub: String, color: Color) {
    Column(
        Modifier
            .width(104.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(12.dp)
    ) {
        Txt(label, 11, C.Muted)
        Spacer(Modifier.height(2.dp))
        Txt(value, 17, color, bold = true, maxLines = 1)
        Txt(sub, 10, C.Muted, maxLines = 1)
    }
}

@Composable
private fun HourCard(h: Hour, current: Boolean) {
    val bg = if (current) C.Brand else C.Chip
    val fg = if (current) Color.White else C.Ink
    val sub = if (current) Color.White.copy(alpha = 0.85f) else C.Muted
    Column(
        Modifier
            .width(68.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Txt("${two(h.hour)}:00", 12, sub, bold = true)
        Spacer(Modifier.height(4.dp))
        WeatherIcon(h.code, h.isDay, 38.dp)
        Spacer(Modifier.height(4.dp))
        Txt("${h.temp.roundToInt()}°", 17, fg, bold = true)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            DropGlyph(if (current) Color.White else C.Blue, 10.dp)
            Spacer(Modifier.width(3.dp))
            Txt("${h.rainProb}%", 11, if (current) Color.White else C.Blue, bold = true)
        }
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            WindArrow((h.windDir + 180.0).toFloat(), if (current) Color.White else C.Teal, 11.dp)
            Spacer(Modifier.width(3.dp))
            Txt("${h.wind.roundToInt()}", 11, sub)
        }
    }
}
