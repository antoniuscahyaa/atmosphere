package com.atmosphere.app.ui

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.unit.Velocity

/**
 * Mengatur header Beranda yang melipat saat isi digeser ke atas (gaya "exit until collapsed").
 *
 * - Header melipat dulu (bagian [heroPx] menghilang), baru isi ikut bergulir.
 * - Saat digeser ke bawah, isi kembali ke atas dulu, baru header terbuka lagi.
 * - Setelah jari dilepas di tengah jalan, header menyelesaikan gerakannya ke penuh/tertutup (snap).
 *
 * Pasang [connection] pada induk dari area yang bisa digulir.
 */
@Stable
class HeaderCollapse {
    /** Tinggi bagian yang bisa dilipat (hero cuaca). 0 = belum ada / tidak bisa dilipat. */
    var heroPx by mutableFloatStateOf(0f)

    /** Berapa piksel header sudah terlipat, 0..[heroPx]. */
    var offset by mutableFloatStateOf(0f)

    /** 0 = terbuka penuh, 1 = terlipat penuh. */
    val progress: Float
        get() = if (heroPx <= 0f) 0f else (offset / heroPx).coerceIn(0f, 1f)

    val connection = object : NestedScrollConnection {
        // Jari naik (available.y < 0): lipat header lebih dulu sebelum isi bergulir.
        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
            if (heroPx <= 0f || available.y >= 0f) return Offset.Zero
            val newOffset = (offset - available.y).coerceAtMost(heroPx)
            val used = newOffset - offset
            offset = newOffset
            return Offset(0f, -used)
        }

        // Jari turun: setelah isi sudah di paling atas, sisa gerakan dipakai untuk membuka header.
        override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
            if (heroPx <= 0f || available.y <= 0f) return Offset.Zero
            val newOffset = (offset - available.y).coerceAtLeast(0f)
            val used = offset - newOffset
            offset = newOffset
            return Offset(0f, used)
        }

        // Gerakan selesai: bila header berhenti di tengah, selesaikan ke ujung terdekat.
        override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
            snap()
            return Velocity.Zero
        }
    }

    private suspend fun snap() {
        val max = heroPx
        if (max <= 0f || offset <= 0f || offset >= max) return
        val target = if (offset > max / 2f) max else 0f
        animate(initialValue = offset, targetValue = target, animationSpec = tween(200)) { v, _ -> offset = v }
    }

    fun reset() {
        heroPx = 0f
        offset = 0f
    }
}
