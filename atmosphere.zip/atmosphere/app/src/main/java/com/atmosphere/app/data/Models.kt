package com.atmosphere.app.data

data class Place(val name: String, val detail: String, val lat: Double, val lon: Double)

/** Kondisi saat ini di lokasi (waktu lokal lokasi tersebut). */
data class Now(
    val date: String,
    val hour: Int,
    val temp: Double,
    val feels: Double,
    val humidity: Int,
    val code: Int,
    val isDay: Boolean,
    val rain: Double,
    val pressure: Double,
    val wind: Double,
    val windDir: Double,
    val gust: Double,
)

data class Hour(
    val date: String,
    val hour: Int,
    val temp: Double,
    val code: Int,
    val isDay: Boolean,
    val rainProb: Int,
    val rain: Double,
    val wind: Double,
    val windDir: Double,
    val gust: Double,
    val cape: Double,
    val uv: Double,
)

data class Day(
    val date: String,
    val max: Double,
    val min: Double,
    val sunrise: String,
    val sunset: String,
    val uvMax: Double,
)

data class Forecast(val now: Now, val days: List<Day>, val hours: List<Hour>, val utcOffset: Int = 0)

/** Satu titik di grid angin pada peta. dir = arah ASAL angin (derajat), speed km/j. */
data class WindPoint(val lat: Double, val lon: Double, val speed: Double, val dir: Double, val code: Int)

data class RadarFrame(val time: Long, val path: String)
data class RadarData(val host: String, val frames: List<RadarFrame>)

/** Gempa dari BMKG. */
data class Quake(
    val lat: Double,
    val lon: Double,
    val mag: Double,
    val depth: String,
    val region: String,
    val time: String,
    val tsunami: String,
)

/** Titik panas (hotspot) dari NASA FIRMS. */
data class FireSpot(val lat: Double, val lon: Double, val frp: Double, val high: Boolean)

/** Peringatan dini cuaca BMKG (CAP). polygons = daftar poligon, tiap poligon = daftar (lat, lon). */
data class WeatherAlert(
    val event: String,
    val headline: String,
    val area: String,
    val severity: String,
    val polygons: List<List<Pair<Double, Double>>>,
)

/** Kualitas udara per jam (indeks AQI AS) dari Open-Meteo Air Quality. */
data class AirHour(val date: String, val hour: Int, val aqi: Int, val pm25: Double)
data class AirQuality(
    val aqi: Int,
    val pm25: Double,
    val pm10: Double,
    val date: String,
    val hour: Int,
    val hours: List<AirHour>,
)

/** Gelombang laut per jam dari Open-Meteo Marine (null jika lokasi di daratan). */
data class WaveHour(val date: String, val hour: Int, val height: Double, val period: Double, val dir: Double)
data class Marine(val height: Double, val period: Double, val dir: Double, val hours: List<WaveHour>)
