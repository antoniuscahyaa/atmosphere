package com.atmosphere.app.ui

import com.atmosphere.app.data.tr
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Header biru berujung membulat dengan dua cincin transparan di pojok kanan atas (gaya DialChat). */
@Composable
fun BlueHeader(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp)
    Box(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(C.Brand)
    ) {
        // Cincin hanya hiasan: ditaruh di Box seukuran header (matchParentSize) dengan requiredSize,
        // supaya ukurannya tidak ikut menentukan tinggi header (dulu header selalu minimal 340dp).
        Box(Modifier.matchParentSize()) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 73.dp, y = (-73).dp)
                    .requiredSize(220.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.10f))
            )
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 113.dp, y = (-113).dp)
                    .requiredSize(340.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.06f))
            )
        }
        Column(
            Modifier
                .statusBarsPadding()
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 22.dp),
            content = content,
        )
    }
}

/** Tombol bulat "kaca" (putih transparan) untuk di atas header biru. */
@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    content: @Composable () -> Unit,
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

/** Judul bagian kecil berwarna aksen (gaya "section" DialChat). */
@Composable
fun SectionTitle(text: String) {
    Txt(text, 13, C.Blue, bold = true, modifier = Modifier.padding(start = 4.dp, top = 20.dp, bottom = 8.dp))
}

private class NavItem(val label: String, val icon: @Composable (Color) -> Unit)

/** Navigasi bawah: tab aktif berupa pill biru dengan ikon putih, label berwarna aksen. */
@Composable
fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        NavItem(tr("Beranda", "Home")) { c -> HomeGlyph(c, 20.dp) },
        NavItem(tr("Peta", "Map")) { c -> MapGlyph(c, 20.dp) },
        NavItem(tr("Pengaturan", "Settings")) { c -> GearGlyph(c, 20.dp) },
    )
    Column(Modifier.fillMaxWidth().background(C.Bg)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(C.Line))
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(64.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEachIndexed { i, item ->
                val on = i == selected
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                ) {
                    Box(
                        Modifier
                            .size(width = 56.dp, height = 28.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (on) C.Brand else Color.Transparent),
                        contentAlignment = Alignment.Center,
                    ) { item.icon(if (on) Color.White else C.Muted) }
                    Spacer(Modifier.height(4.dp))
                    Txt(item.label, 12, if (on) C.Blue else C.Muted, bold = on, maxLines = 1)
                }
            }
        }
    }
}
