package com.atmosphere.app.ui

import com.atmosphere.app.data.tr
import androidx.compose.ui.graphics.Color
import com.atmosphere.app.data.AirQuality
import com.atmosphere.app.data.Comparison
import com.atmosphere.app.data.Compare
import com.atmosphere.app.data.Forecast
import kotlin.math.roundToInt

data class Tip(val text: String, val color: Color)

/** Saran singkat berbasis aturan sederhana dari data (bukan hasil AI). Urut dari yang paling penting. */
fun buildTips(f: Forecast, air: AirQuality?, c: Comparison?): List<Tip> {
    val tips = ArrayList<Tip>()
    val now = f.now
    val series = Compare.rainSeries(f, c)
    val total = c?.total ?: 1
    val rainSources = c?.rainCount ?: if (series.any { it.rainSources > 0 }) 1 else 0

    // Hujan
    if (rainSources > 0) {
        val mostly = rainSources * 2 > total || (c == null)
        tips += if (mostly) Tip(tr("Bawa payung atau jas hujan.", "Bring an umbrella or raincoat."), C.Blue)
        else Tip(tr("Sumber prakiraan terbelah soal hujan, siapkan payung lipat untuk jaga-jaga.", "Forecast sources disagree on rain; keep a compact umbrella handy just in case."), C.Blue)
    }

    // Badai petir (12 jam ke depan dari jam sekarang)
    val upcoming = f.hours.filter { it.date > now.date || (it.date == now.date && it.hour >= now.hour) }.take(Compare.WINDOW)
    if (upcoming.any { it.code >= 95 || (it.cape >= 2000 && it.rainProb >= 50) }) {
        tips += Tip(tr("Potensi badai petir. Hindari area terbuka dan pohon tinggi saat petir.", "Thunderstorms possible. Avoid open areas and tall trees during lightning."), C.Purple)
    }

    // Angin
    val gust = maxOf(now.gust, upcoming.maxOfOrNull { it.gust } ?: 0.0)
    if (gust >= 50) tips += Tip(tr("Angin sangat kencang (hembusan ${gust.roundToInt()} km/j), waspada benda lepas dan pohon.", "Very strong winds (gusts ${gust.roundToInt()} km/h); watch out for loose objects and trees."), C.Orange)
    else if (gust >= 35) tips += Tip(tr("Angin cukup kencang (hembusan ${gust.roundToInt()} km/j).", "Fairly strong winds (gusts ${gust.roundToInt()} km/h)."), C.Orange)

    // UV: hanya jika masih ada siang hari di jendela ini
    val uv = upcoming.filter { it.isDay }.maxOfOrNull { it.uv } ?: 0.0
    when {
        uv >= 11 -> tips += Tip(tr("UV ekstrem. Hindari matahari langsung, pakai tabir surya dan pelindung.", "Extreme UV. Avoid direct sun; wear sunscreen and protective clothing."), C.Pink)
        uv >= 8 -> tips += Tip(tr("UV sangat tinggi, pakai tabir surya, topi, dan kurangi paparan siang hari.", "Very high UV: wear sunscreen and a hat, and limit midday exposure."), C.Pink)
        uv >= 6 -> tips += Tip(tr("UV tinggi, pakai tabir surya saat di luar.", "High UV: wear sunscreen when outdoors."), C.Gold)
        uv >= 3 -> tips += Tip(tr("UV sedang, tabir surya disarankan jika lama di luar.", "Moderate UV: sunscreen recommended if you will be outside for long."), C.Gold)
    }

    // Suhu
    when {
        now.feels >= 38 -> tips += Tip(tr("Terasa sangat panas (${now.feels.roundToInt()}°). Minum cukup air dan hindari aktivitas berat di luar.", "Feels very hot (${now.feels.roundToInt()}°). Drink plenty of water and avoid strenuous outdoor activity."), C.Orange)
        now.feels >= 34 -> tips += Tip(tr("Terasa panas (${now.feels.roundToInt()}°). Jangan lupa minum air.", "Feels hot (${now.feels.roundToInt()}°). Remember to drink water."), C.Orange)
        now.feels <= 18 -> tips += Tip(tr("Cukup dingin (${now.feels.roundToInt()}°). Bawa jaket.", "Quite cold (${now.feels.roundToInt()}°). Bring a jacket."), C.Blue)
    }

    // Kualitas udara
    if (air != null) {
        when {
            air.aqi > 150 -> tips += Tip(tr("Kualitas udara tidak sehat (AQI ${air.aqi}). Pakai masker dan batasi aktivitas di luar.", "Unhealthy air quality (AQI ${air.aqi}). Wear a mask and limit outdoor activity."), Color(0xFFE63946))
            air.aqi > 100 -> tips += Tip(tr("Udara kurang sehat bagi kelompok sensitif (AQI ${air.aqi}). Pertimbangkan masker.", "Air is unhealthy for sensitive groups (AQI ${air.aqi}). Consider a mask."), C.Orange)
            air.aqi > 50 -> tips += Tip(tr("Kualitas udara sedang (AQI ${air.aqi}). Kelompok sensitif sebaiknya berhati-hati.", "Moderate air quality (AQI ${air.aqi}). Sensitive groups should take care."), C.Gold)
        }
    }

    if (tips.isEmpty()) tips += Tip(tr("Cuaca bersahabat hari ini, selamat beraktivitas.", "Pleasant weather today. Enjoy your day."), C.Teal)
    return tips
}
