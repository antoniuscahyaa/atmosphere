package com.atmosphere.app.ui

import androidx.compose.ui.graphics.Color
import com.atmosphere.app.data.AirQuality
import com.atmosphere.app.data.Comparison
import com.atmosphere.app.data.Compare
import com.atmosphere.app.data.Forecast
import kotlin.math.roundToInt

data class Tip(val text: String, val color: Color)

/** Saran singkat berbasis aturan sederhana dari data (bukan hasil AI). Urut dari yang paling penting. */
fun buildTips(f: Forecast, air: AirQuality?, c: Comparison?): List<Tip> {
    val tips = ArrayList<Tip>()
    val now = f.now
    val series = Compare.rainSeries(f, c)
    val total = c?.total ?: 1
    val rainSources = c?.rainCount ?: if (series.any { it.rainSources > 0 }) 1 else 0

    // Hujan
    if (rainSources > 0) {
        val mostly = rainSources * 2 > total || (c == null)
        tips += if (mostly) Tip("Bawa payung atau jas hujan.", C.Blue)
        else Tip("Sumber prakiraan terbelah soal hujan, siapkan payung lipat untuk jaga-jaga.", C.Blue)
    }

    // Badai petir (12 jam ke depan dari jam sekarang)
    val upcoming = f.hours.filter { it.date > now.date || (it.date == now.date && it.hour >= now.hour) }.take(Compare.WINDOW)
    if (upcoming.any { it.code >= 95 || (it.cape >= 2000 && it.rainProb >= 50) }) {
        tips += Tip("Potensi badai petir. Hindari area terbuka dan pohon tinggi saat petir.", C.Purple)
    }

    // Angin
    val gust = maxOf(now.gust, upcoming.maxOfOrNull { it.gust } ?: 0.0)
    if (gust >= 50) tips += Tip("Angin sangat kencang (hembusan ${gust.roundToInt()} km/j), waspada benda lepas dan pohon.", C.Orange)
    else if (gust >= 35) tips += Tip("Angin cukup kencang (hembusan ${gust.roundToInt()} km/j).", C.Orange)

    // UV: hanya jika masih ada siang hari di jendela ini
    val uv = upcoming.filter { it.isDay }.maxOfOrNull { it.uv } ?: 0.0
    when {
        uv >= 11 -> tips += Tip("UV ekstrem. Hindari matahari langsung, pakai tabir surya dan pelindung.", C.Pink)
        uv >= 8 -> tips += Tip("UV sangat tinggi, pakai tabir surya, topi, dan kurangi paparan siang hari.", C.Pink)
        uv >= 6 -> tips += Tip("UV tinggi, pakai tabir surya saat di luar.", C.Gold)
        uv >= 3 -> tips += Tip("UV sedang, tabir surya disarankan jika lama di luar.", C.Gold)
    }

    // Suhu
    when {
        now.feels >= 38 -> tips += Tip("Terasa sangat panas (${now.feels.roundToInt()}°). Minum cukup air dan hindari aktivitas berat di luar.", C.Orange)
        now.feels >= 34 -> tips += Tip("Terasa panas (${now.feels.roundToInt()}°). Jangan lupa minum air.", C.Orange)
        now.feels <= 18 -> tips += Tip("Cukup dingin (${now.feels.roundToInt()}°). Bawa jaket.", C.Blue)
    }

    // Kualitas udara
    if (air != null) {
        when {
            air.aqi > 150 -> tips += Tip("Kualitas udara tidak sehat (AQI ${air.aqi}). Pakai masker dan batasi aktivitas di luar.", Color(0xFFE63946))
            air.aqi > 100 -> tips += Tip("Udara kurang sehat bagi kelompok sensitif (AQI ${air.aqi}). Pertimbangkan masker.", C.Orange)
            air.aqi > 50 -> tips += Tip("Kualitas udara sedang (AQI ${air.aqi}). Kelompok sensitif sebaiknya berhati-hati.", C.Gold)
        }
    }

    if (tips.isEmpty()) tips += Tip("Cuaca bersahabat hari ini, selamat beraktivitas.", C.Teal)
    return tips
}
