package com.atmosphere.app.ui

import com.atmosphere.app.data.Lang
import com.atmosphere.app.data.tr
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.atmosphere.app.data.LocationHelper
import com.atmosphere.app.data.UserPrefs

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(UserPrefs.name(ctx)) }
    var hasLoc by remember { mutableStateOf(LocationHelper.hasPermission(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasLoc = LocationHelper.hasPermission(ctx)
    }

    Column(
        modifier
            .fillMaxSize()
            .background(C.Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .verticalScroll(rememberScrollState())
    ) {
        BlueHeader {
            Txt(tr("Pengaturan", "Settings"), 30, Color.White, bold = true)
            Txt(tr("Tampilan, bahasa, profil, dan sumber data", "Appearance, language, profile, and data sources"), 14, Color.White.copy(alpha = 0.85f))
        }

        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            // ---- Tampilan ----
            SectionTitle(tr("Tampilan", "Appearance"))
            Card {
                Txt(tr("Tema", "Theme"), 16, bold = true)
                Txt(tr("Ikuti pengaturan sistem, atau pilih terang / gelap", "Follow the system setting, or choose light / dark"), 13, C.Muted)
                Spacer(Modifier.height(10.dp))
                OptionRow(
                    options = listOf(tr("Sistem", "System"), tr("Terang", "Light"), tr("Gelap", "Dark")),
                    selected = ThemeState.mode,
                    onSelect = {
                        ThemeState.mode = it
                        UserPrefs.setTheme(ctx, it)
                    },
                )
            }

            // ---- Bahasa ----
            Spacer(Modifier.height(10.dp))
            Card {
                // Judul dua bahasa supaya tetap terbaca jika bahasa terpilih tidak dimengerti.
                Txt("Bahasa · Language", 16, bold = true)
                Txt(
                    tr("Ikuti bahasa sistem, atau pilih sendiri", "Follow the system language, or choose one"),
                    13, C.Muted,
                )
                Spacer(Modifier.height(10.dp))
                OptionRow(
                    options = listOf(tr("Sistem", "System"), "Indonesia", "English"),
                    selected = Lang.mode,
                    onSelect = {
                        Lang.mode = it
                        UserPrefs.setLanguage(ctx, it)
                    },
                )
            }

            // ---- Profil ----
            SectionTitle(tr("Profil", "Profile"))
            NameCard(
                initial = name,
                onSave = {
                    UserPrefs.setName(ctx, it)
                    name = UserPrefs.name(ctx)
                },
                onCancel = null,
            )

            // ---- Lokasi ----
            SectionTitle(tr("Lokasi", "Location"))
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Txt(tr("Akses lokasi", "Location access"), 16, bold = true)
                        Txt(
                            if (hasLoc) tr("Aktif. Beranda memakai lokasi Anda saat ini.", "On. Home uses your current location.")
                            else tr("Belum diizinkan. Beranda butuh lokasi untuk menampilkan cuaca di sekitar Anda.", "Not allowed yet. Home needs your location to show the weather around you."),
                            13, C.Muted,
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    if (hasLoc) {
                        Txt("✓", 20, if (C.isDark) Color(0xFF47C98A) else Color(0xFF0F7A41), bold = true)
                    } else {
                        PillButton(tr("Aktifkan", "Enable"), C.Brand, Color.White) {
                            permLauncher.launch(
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                            )
                        }
                    }
                }
            }

            // ---- Sumber data ----
            SectionTitle(tr("Sumber data", "Data sources"))
            Card {
                SourceLine(tr("Prakiraan utama", "Main forecast"), "Open-Meteo")
                SourceLine(tr("Prakiraan pembanding", "Comparison forecasts"), "MET Norway, ECMWF, DWD ICON, NOAA GFS")
                SourceLine(tr("Radar hujan", "Rain radar"), "RainViewer")
                SourceLine(tr("Peringatan dini & gempa", "Early warnings & earthquakes"), "BMKG")
                SourceLine(tr("Titik api", "Fire hotspots"), "NASA FIRMS")
                SourceLine(tr("Peta", "Map"), "© OpenStreetMap")
                Spacer(Modifier.height(6.dp))
                Txt(
                    tr("Perbandingan sumber memakai jendela 12 jam ke depan. Satu jam dianggap hujan jika curahnya minimal 0,2 mm.", "Source comparison uses the next 12 hours. An hour counts as rainy if rainfall is at least 0.2 mm."),
                    12, C.Muted,
                )
            }

            // ---- Tentang ----
            SectionTitle(tr("Tentang", "About"))
            Card {
                Txt("Atmosphere", 16, bold = true)
                Txt(tr("Versi 1.0", "Version 1.0"), 13, C.Muted)
            }
        }
    }
}

/** Deretan tombol pilihan (segmented) yang dipakai untuk tema dan bahasa. */
@Composable
private fun OptionRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            val on = selected == i
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (on) C.Brand else C.Bg)
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) { Txt(label, 14, if (on) Color.White else C.Ink, bold = true) }
        }
    }
}

@Composable
private fun SourceLine(title: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Txt(title, 12, C.Muted)
        Txt(value, 14, bold = true)
    }
}
