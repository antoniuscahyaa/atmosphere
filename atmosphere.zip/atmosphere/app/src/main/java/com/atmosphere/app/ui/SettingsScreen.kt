package com.atmosphere.app.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.atmosphere.app.data.LocationHelper
import com.atmosphere.app.data.UserPrefs

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(UserPrefs.name(ctx)) }
    var hasLoc by remember { mutableStateOf(LocationHelper.hasPermission(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasLoc = LocationHelper.hasPermission(ctx)
    }

    Column(
        modifier
            .fillMaxSize()
            .background(C.Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .verticalScroll(rememberScrollState())
    ) {
        BlueHeader {
            Txt("Pengaturan", 30, Color.White, bold = true)
            Txt("Tampilan, profil, dan sumber data", 14, Color.White.copy(alpha = 0.85f))
        }

        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            // ---- Tampilan ----
            SectionTitle("Tampilan")
            Card {
                Txt("Tema", 16, bold = true)
                Txt("Ikuti pengaturan sistem, atau pilih terang / gelap", 13, C.Muted)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Sistem", "Terang", "Gelap").forEachIndexed { i, label ->
                        val on = ThemeState.mode == i
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (on) C.Brand else C.Bg)
                                .clickable {
                                    ThemeState.mode = i
                                    UserPrefs.setTheme(ctx, i)
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center,
                        ) { Txt(label, 14, if (on) Color.White else C.Ink, bold = true) }
                    }
                }
            }

            // ---- Profil ----
            SectionTitle("Profil")
            NameCard(
                initial = name,
                onSave = {
                    UserPrefs.setName(ctx, it)
                    name = UserPrefs.name(ctx)
                },
                onCancel = null,
            )

            // ---- Lokasi ----
            SectionTitle("Lokasi")
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Txt("Akses lokasi", 16, bold = true)
                        Txt(
                            if (hasLoc) "Aktif. Beranda memakai lokasi Anda saat ini."
                            else "Belum diizinkan. Beranda butuh lokasi untuk menampilkan cuaca di sekitar Anda.",
                            13, C.Muted,
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    if (hasLoc) {
                        Txt("✓", 20, if (C.isDark) Color(0xFF47C98A) else Color(0xFF0F7A41), bold = true)
                    } else {
                        PillButton("Aktifkan", C.Brand, Color.White) {
                            permLauncher.launch(
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                            )
                        }
                    }
                }
            }

            // ---- Sumber data ----
            SectionTitle("Sumber data")
            Card {
                SourceLine("Prakiraan utama", "Open-Meteo")
                SourceLine("Prakiraan pembanding", "MET Norway, ECMWF, DWD ICON, NOAA GFS")
                SourceLine("Radar hujan", "RainViewer")
                SourceLine("Peringatan dini & gempa", "BMKG")
                SourceLine("Titik api", "NASA FIRMS")
                SourceLine("Peta", "© OpenStreetMap")
                Spacer(Modifier.height(6.dp))
                Txt(
                    "Perbandingan sumber memakai jendela 12 jam ke depan. Satu jam dianggap hujan jika curahnya minimal 0,2 mm.",
                    12, C.Muted,
                )
            }

            // ---- Tentang ----
            SectionTitle("Tentang")
            Card {
                Txt("Atmosphere", 16, bold = true)
                Txt("Versi 1.0", 13, C.Muted)
            }
        }
    }
}

@Composable
private fun SourceLine(title: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Txt(title, 12, C.Muted)
        Txt(value, 14, bold = true)
    }
}
